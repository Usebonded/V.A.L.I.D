import re

with open('src/components/AudioUploaderTester.tsx', 'r') as f:
    code = f.read()

# Add imports
code = re.sub(
    r"import \{ AcousticTelemetry \} from '\.\./types';",
    "import { AcousticTelemetry, ForensicReportEntry, CallAnalysisResult } from '../types';",
    code
)

# Add prop to interface
code = re.sub(
    r"onNavigateToTab\?: \(tab: string\) => void;",
    "onNavigateToTab?: (tab: string) => void;\n  onReportGenerated?: (report: ForensicReportEntry) => void;",
    code
)

# Add prop to component
code = re.sub(
    r"onNavigateToTab,",
    "onNavigateToTab,\n  onReportGenerated,",
    code
)

# Call API after analysis
api_call_code = """      setAnalysis(result);
      
      // Trigger forensic report generation on the backend
      try {
        const res = await fetch('/api/analyze-call', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            callerName: 'Audio Upload Analysis',
            callerRole: 'External Source',
            targetRole: 'Forensic System',
            scenarioTitle: 'Manual Audio Analysis',
            transcript: ['Audio processed via local upload buffer.'],
            telemetry: currentTelemetryRef.current || {},
            cloneScore: result.syntheticProbability,
          }),
        });
        const data = await res.json();
        if (data.success && data.report && onReportGenerated) {
          onReportGenerated({
            id: 'FR-' + Math.random().toString(36).substring(2, 9).toUpperCase(),
            timestamp: Date.now(),
            source: 'Upload',
            telemetrySnapshot: currentTelemetryRef.current || {},
            analysis: data.report
          });
        }
      } catch (e) {
        console.error('AI analysis error for upload:', e);
      }"""

code = re.sub(
    r"setAnalysis\(result\);",
    api_call_code,
    code
)

# In handleFileUpload, we need currentTelemetryRef.current, but AudioUploader doesn't have it natively, let's just pass some default or create a ref.
# Actually, the analyze call needs some basic object. Let's just create a dummy if it doesn't exist.
# Or better, just pass an empty object. The backend just needs cloneScore.

with open('src/components/AudioUploaderTester.tsx', 'w') as f:
    f.write(code)
