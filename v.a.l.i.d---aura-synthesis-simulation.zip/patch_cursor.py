import re
with open('src/App.tsx', 'r') as f:
    code = f.read()

# Import
code = re.sub(
    r"import \{ BackgroundAcousticMatrix \} from '\.\/components\/BackgroundAcousticMatrix';",
    "import { CustomCursor } from './components/CustomCursor';\nimport { BackgroundAcousticMatrix } from './components/BackgroundAcousticMatrix';",
    code
)

# Render inside return
code = re.sub(
    r"return \(\n\s*<div className=\"min-h-screen bg-black text-white font-sans\">",
    "return (\n    <div className=\"min-h-screen bg-black text-white font-sans\">\n      <CustomCursor />",
    code
)

with open('src/App.tsx', 'w') as f:
    f.write(code)
