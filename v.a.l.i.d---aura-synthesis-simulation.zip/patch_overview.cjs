const fs = require('fs');
let code = fs.readFileSync('src/components/OverviewDashboard.tsx', 'utf8');

code = code.replace(/import {([^}]*)} from 'lucide-react';/, "import {$1, FileSearch} from 'lucide-react';");

const newCard = `    {
      id: 'forensic_report',
      title: 'Forensic Report History',
      badge: 'Analysis Log',
      badgeColor: 'purple',
      desc: 'Detailed breakdown of audio artifacts, acoustic anomalies, and behavioral psychology flags from uploaded or live audio.',
      icon: FileSearch,
      actionText: 'View History',
      metric: '0',
      metricLabel: 'Reports Logged',
    }`;

code = code.replace(/\{\s*id:\s*'rl_defense'[\s\S]*?metricLabel:\s*'Artifact Score',\s*\},/g, newCard + ",");

fs.writeFileSync('src/components/OverviewDashboard.tsx', code);
