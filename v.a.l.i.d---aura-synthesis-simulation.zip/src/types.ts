export interface BreathingPatternBiomarker {
  inhalationDetected: boolean;
  inhalationIntervalMs: number; // Interval between respiratory intakes (natural: 3200 - 5800ms)
  inhalationDurationMs: number; // Duration of breath sound (natural: 280 - 650ms)
  respirationEnergyRatio: number; // Ratio of breath acoustic energy to phonation
  syntheticBreathArtifact: 'ABSENT_RESPIRATION' | 'LOOPED_SYNTHETIC_INSERT' | 'UNNATURAL_INHALATION_TIMING' | 'ORGANIC_BIOLOGICAL_CYCLE';
  diaphragmaticAnomalyScore: number; // 0 - 100% (High = AI synthesized / abnormal)
  inhalationWaveform: number[]; // Short amplitude envelope of recent breath window
}

export interface MicroPauseBiomarker {
  currentPauseDurationMs: number;
  averagePauseDurationMs: number;
  pauseVariance: number; // Standard deviation of inter-word pauses (natural: >140ms; AI: <25ms)
  tokenQuantizationIndex: number; // 0 - 100% token boundary rigidity
  speechToSilenceTransitionSharpnessDbMs: number; // Abrupt vocoder cutoff rate (>1.6 dB/ms indicates synthetic gate)
  pauseCadenceHistory: number[]; // Sequence of recent pause durations in ms
  isRigidTokenBoundaries: boolean;
  anomalyFlag: boolean;
}

export interface PhaseInconsistencyBiomarker {
  instantaneousPhaseDiscontinuity: number; // 0 - 100% phase flip rate
  overlapAddCancellationScore: number; // 0 - 100% STFT phase cancellation from neural vocoders
  vocoderPhaseContinuityIndex: number; // 0 - 100% coherence (Natural is >80%, AI is <35%)
  glottalPulsePhaseDispersion: number; // Phase dispersion angle in radians
  phaseLissajousTrajectory: { x: number; y: number }[]; // 2D phase orbital trajectory
  phaseAnomalyFlag: boolean;
}

export interface ModelFingerprintMatch {
  modelName: 'ElevenLabs_Multilingual_v2' | 'Tortoise_TTS' | 'VALL_E_2' | 'Bark_Diffusion' | 'XTTS_v2' | 'Organic_Biological_Human';
  displayName: string;
  confidence: number; // 0 - 100%
  signatureMarkers: string[];
  primaryVector: string;
}

export interface NeuralBiomarkerReport {
  overallBiomarkerAnomalyScore: number; // 0 - 100%
  predictedModel: string;
  verdict: 'BIOLOGICAL_RESPIRATION_AND_PHASE' | 'SYNTHETIC_BIOMARKER_ANOMALIES' | 'CONFIRMED_NEURAL_VOICE_MODEL';
  breathingPattern: BreathingPatternBiomarker;
  microPauses: MicroPauseBiomarker;
  phaseInconsistency: PhaseInconsistencyBiomarker;
  modelFingerprints: ModelFingerprintMatch[];
  detectedBiomarkerFlags: {
    biomarkerType: 'BREATHING' | 'MICRO_PAUSE' | 'PHASE_INCONSISTENCY' | 'MODEL_FINGERPRINT';
    title: string;
    description: string;
    severity: 'critical' | 'high' | 'medium';
    metricValue: string;
  }[];
}

export interface MFCCFeatureSet {
  coefficients: number[]; // 13 MFCC coefficients (c0 to c12)
  deltas: number[]; // 13 Delta coefficients (velocity)
  deltaDeltas: number[]; // 13 Delta-Delta coefficients (acceleration)
  highOrderSmoothness: number; // 0 - 100% anomaly score (synthetic speech has over-smoothed high cepstral bins)
  cepstralVariance: number; // Inter-frame dynamic variation
  spectralFlux: number; // Rate of spectral change
  anomalyFlag: boolean;
}

export interface SpectrogramAnalysisData {
  spectralCentroidHz: number; // Center of mass of the spectrum
  spectralRolloffHz: number; // Frequency below which 85% of energy resides (e.g. 16kHz vocoder ceiling)
  spectralFlatness: number; // Wiener entropy: 0 (pure tone) to 1 (white noise)
  harmonicToNoiseRatioDb: number; // HNR in dB (natural speech > 15dB)
  vocoderCutoffFrequencyHz: number; // Detected sharp brickwall limit (e.g. 16000Hz, 22050Hz, 24000Hz)
  nyquistDitherScore: number; // 0 - 100% indicator of vocoder phase dither
  checkerboardAnomalyScore: number; // 0 - 100% indicator of transposed convolution artifacts
  spectralEnergyBands: {
    subBass: number; // < 250 Hz
    lowMids: number; // 250 - 1000 Hz
    highMids: number; // 1000 - 4000 Hz
    presence: number; // 4000 - 8000 Hz
    brilliance: number; // > 8000 Hz
  };
  anomalyFlag: boolean;
}

export interface BispectrumFeatureSet {
  bicoherenceMatrix: number[][]; // 2D Bicoherence grid (f1 vs f2)
  phaseCouplingIndex: number; // Quadratic Phase Coupling (QPC) score (0 - 100%)
  nonGaussianityScore: number; // Measure of glottal non-linearity (natural is high, synthetic is low)
  glottalPulseDecoupling: boolean; // True if phase coupling between F0 and harmonics is decoupled/missing
  bispectralPeakRatio: number; // Dominant bispectral peak to background ratio
  anomalyFlag: boolean;
}

export interface PitchVariabilityData {
  f0Hz: number; // Instantaneous fundamental frequency F0
  f0MeanHz: number; // Mean F0
  f0StdDev: number; // Pitch standard deviation (prosodic variability)
  pitchRangeSemitones: number; // Dynamic pitch range across utterance
  jitterPercent: number; // Period-to-period frequency perturbation (natural: 0.5-1.5%, synthetic: <0.2% or erratic)
  shimmerPercent: number; // Amplitude perturbation quotient (natural: 1.2-3.5%, synthetic: <0.8%)
  microProsodyContour: number[]; // F0 trajectory points over recent frames
  glottalWaveformSymmetry: number; // Glottal opening/closing quotient (0 - 1)
  unnaturalSmoothnessFlag: boolean; // Flagged if robotic flat pitch
  erraticDiscontinuityFlag: boolean; // Flagged if sudden vocoder phase flips
}

export interface DeepfakeMultiFeatureReport {
  overallSyntheticProbability: number; // 0 - 100%
  verdict: 'AUTHENTIC_BIOLOGICAL_VOICE' | 'SUSPECT_SYNTHETIC_ANOMALIES' | 'CONFIRMED_DEEPFAKE_CLONE';
  featureScores: {
    mfccAnomaly: number; // 0 - 100%
    spectrogramAnomaly: number; // 0 - 100%
    bispectrumAnomaly: number; // 0 - 100%
    pitchVariabilityAnomaly: number; // 0 - 100%
  };
  detectedArtifacts: {
    featureCategory: 'MFCC' | 'SPECTROGRAM' | 'BISPECTRUM' | 'PITCH_VARIABILITY';
    title: string;
    description: string;
    severity: 'critical' | 'high' | 'medium' | 'low';
    metricValue: string;
  }[];
}

export interface AcousticTelemetry {
  timestamp: number;
  rms: number; // 0 - 1
  peakDb: number; // -60 to 0 dB
  pitchHz: number; // Fundamental frequency F0
  pitchJitterPercent: number; // Voice jitter (natural: 0.5-1.5%, synthetic: <0.2% or erratic)
  shimmerPercent: number; // Amplitude perturbation (natural: 1-3%, synthetic: <0.8%)
  microPauseDurationMs: number; // Pause durations between syllables
  microPauseVariance: number; // Variance in pause timing
  spectralRollOffHz: number; // Frequency below which 85% of power resides
  vocoderArtifactScore: number; // 0 - 100% indicator of neural vocoder cutoff/dither
  phaseContinuityScore: number; // 0 - 100% glottal pulse phase coherence
  backgroundNoiseCoherence: number; // 0 - 100% room impulse response consistency
  syntheticProbability: number; // Overall composite score (0 - 100%)
  formants: {
    f1: number;
    f2: number;
    f3: number;
  };
  // Advanced Multi-Feature Extractions
  mfccFeatures?: MFCCFeatureSet;
  spectrogramAnalysis?: SpectrogramAnalysisData;
  bispectrumFeatures?: BispectrumFeatureSet;
  pitchVariability?: PitchVariabilityData;
  deepfakeReport?: DeepfakeMultiFeatureReport;
  biomarkers?: NeuralBiomarkerReport;
}

export interface VoiceLivenessChallenge {
  id: string;
  challengePhrase: string;
  phoneticTokens: string[];
  issuedAt: number;
  expiresAt: number;
  status: 'idle' | 'prompted' | 'listening' | 'analyzing' | 'passed' | 'failed';
  metrics: {
    cognitiveLatencyMs: number; // Natural: 400-1200ms, Clone: >1800ms or <150ms
    phoneticAlignmentScore: number; // 0 - 100% match with challenge phrase
    replayArtifactScore: number; // 0 - 100% loudspeaker replay distortion & double RIR
    dynamicAcousticEntropy: number; // 0 - 100% micro-variations
    airTurbulenceConsistency: number; // 0 - 100% natural proximity breath pressure
    overallLivenessScore: number; // 0 - 100% (High = genuine live human)
    antiSpoofingVerdict: 'GENUINE_LIVE_HUMAN' | 'REPLAY_PLAYBACK_ATTACK' | 'SYNTHETIC_GENERATIVE_STREAM' | 'INCONCLUSIVE';
    failureReasons?: string[];
  };
}

export interface VoiceProfileBiometrics {
  meanF0: number; // Hz
  f0Variance: number;
  formants: {
    f1: number;
    f2: number;
    f3: number;
  };
  mfccCentroid: number[]; // 13 MFCC coefficients
  spectralRollOffHz: number;
  harmonicToNoiseRatioDb: number;
  shimmerPercent: number;
  jitterPercent: number;
}

export interface AuthorizedVoiceProfile {
  id: string;
  name: string;
  role: string;
  department: string;
  securityClearance: 'LEVEL_4_EXECUTIVE' | 'LEVEL_3_FINANCIAL' | 'LEVEL_2_ENGINEERING' | 'LEVEL_1_STANDARD';
  enrolledAt: string;
  sampleCount: number;
  biometrics: VoiceProfileBiometrics;
  isCustomEnrolled?: boolean;
}

export interface VoiceprintMatchResult {
  targetProfile: AuthorizedVoiceProfile;
  overallMatchScore: number; // 0 - 100% Cosine Similarity
  pitchCorrelation: number; // 0 - 100%
  formantMatchScore: number; // 0 - 100%
  mfccCosineSimilarity: number; // 0 - 100%
  timbreConsistency: number; // 0 - 100%
  authenticationDecision: 'AUTHORIZED_SPEAKER' | 'SUSPECT_CLONE_IMPERSONATOR' | 'UNKNOWN_UNAUTHORIZED_VOICE';
  confidenceLevel: 'HIGH' | 'MEDIUM' | 'LOW';
  anomalyBreakdown: string[];
}

export interface VishingScenario {
  id: string;
  name: string;
  callerName: string;
  callerRole: string;
  targetRole: string;
  audioClassification: 'synthetic_clone' | 'authentic_human' | 'hybrid_spliced';
  cloneEngine?: string;
  threatLevel: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'SAFE';
  scenarioDescription: string;
  callerTranscript: string[];
  operatorTranscript: string[];
  keyAcousticFlags: string[];
  recommendedAction: string;
  sampleDurationSec: number;
}

export interface ProceduralPassphrase {
  id: string;
  token: string;
  phoneticPhrase: string;
  generatedAt: number;
  expiresInSec: number;
  challengeStatus: 'idle' | 'issued' | 'evaluating' | 'verified' | 'failed';
  expectedLatencyWindowMs: [number, number]; // [min, max] - Clones take >800ms to synthesize
  measuredLatencyMs?: number;
  acousticMatchPercent?: number;
}

export interface CallAnalysisResult {
  threatVerdict: 'CRITICAL_DEEPFAKE_VISHING' | 'SUSPICIOUS_SYNTHETIC_ACTIVITY' | 'AUTHENTIC_VERIFIED_HUMAN';
  syntheticConfidence: number; // 0 - 100
  acousticAnomalies: {
    name: string;
    description: string;
    severity: 'high' | 'medium' | 'low';
    metricValue: string;
  }[];
  linguisticPsychologicalFlags: {
    tactic: string;
    quote: string;
    risk: string;
  }[];
  mitigationProtocol: {
    step: number;
    action: string;
    status: 'completed' | 'recommended' | 'active';
  }[];
  deepReasoning: string;
}

export interface InferencePipelineMetrics {
  frameChunkSizeMs: number; // 20ms audio frame
  featureExtractLatencyMs: number; // 18-24ms DSP extraction
  modelInferenceLatencyMs: number; // 25-45ms Neural Model
  totalPipelineLatencyMs: number; // ~48-75ms (Budget is <200ms)
  latencyBudgetMaxMs: number; // 200ms ceiling
  jitterMs: number; // <2.0ms
  cpuUtilizationPercent: number; // ~4.5%
  memoryFootprintMb: number; // ~14.2 MB
  modelArchitecture: string; // "Quantized MobileNet-V3 1D-CNN + Temporal Conformer"
  modelParamSizeMb: number; // 3.4 MB
  processedFramesCount: number;
  bufferHealth: 'OPTIMAL' | 'ACCEPTABLE' | 'DEGRADED';
}

export interface ThreatIncidentAlert {
  id: string;
  timestamp: string;
  threatLevel: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  callerName: string;
  targetEmployee: string;
  channel: 'SIP_TRUNK_01' | 'WEBRTC_VOIP' | 'PSTN_GATEWAY';
  syntheticConfidence: number;
  primaryBiomarkerTrigger: string;
  actionTaken: 'AUTO_TERMINATED_SIP_BYE' | 'WARNING_BANNER_PRESENTED' | 'STEP_UP_MFA_ENFORCED' | 'SOC_ESCALATED';
  notificationRecipients: {
    channel: 'SMS' | 'SOC_WEBHOOK' | 'SIEM_SYSLOG' | 'ADMIN_PUSH';
    destination: string;
    status: 'DELIVERED' | 'DISPATCHING';
  }[];
  payloadSummary: string;
}

export interface ThreatPreventionPolicy {
  autoTerminationEnabled: boolean;
  terminationThresholdConfidence: number; // e.g. 80%
  inCallWarningOverlayEnabled: boolean;
  warningSensitivityTier: 'STRICT' | 'BALANCED' | 'PERMISSIVE';
  automatedAdminAlertsEnabled: boolean;
  targetedUserSmsAlertsEnabled: boolean;
  socWebhookUrl: string;
}

export interface CallSessionState {
  status: 'idle' | 'calling' | 'analyzing' | 'flagged' | 'authenticated' | 'intercepted';
  activeScenarioId: string | null;
  elapsedSeconds: number;
  detectionThresholdSec: number; // 3.0s
  currentTelemetry: AcousticTelemetry;
  telemetryHistory: AcousticTelemetry[];
  activePassphrase: ProceduralPassphrase | null;
  analysisReport: CallAnalysisResult | null;
  operatorNotes: string[];
  defenseShieldActive: boolean;
  whisperAlertSent: boolean;
  mfaPushSent: boolean;
}

// -------------------------------------------------------------------------------------------------
// Reinforcement Learning Voice Detection System Types
// -------------------------------------------------------------------------------------------------

export type RLActionType = 
  | 'PASS_CLEAN'
  | 'ENHANCE_SAMPLING'
  | 'PROMPT_COGNITIVE_CHALLENGE'
  | 'RAISE_SOC_THREAT_ALERT'
  | 'TRIGGER_SIP_BYE_KILLSWITCH';

export interface RLAgentStateVector {
  vocoderRollOffAnomaly: number; // [0, 1]
  phaseContinuityDisruption: number; // [0, 1]
  microPauseRigidity: number; // [0, 1]
  pitchJitterPerturbation: number; // [0, 1]
  bispectrumDecoupling: number; // [0, 1]
  temporalFrameJitter: number; // [0, 1]
  ambientRirCoherence: number; // [0, 1]
  voiceprintDeviation: number; // [0, 1]
}

export interface RLActionCandidate {
  action: RLActionType;
  label: string;
  qValue: number; // Estimated cumulative future reward
  probability: number; // Softmax policy probability
  isChosen: boolean;
}

export interface RLCatchAlert {
  id: string;
  timestamp: number;
  detectedCloneModel: string;
  syntheticConfidence: number; // 0 - 100%
  rewardEarned: number;
  actionTaken: RLActionType;
  dominantAnomalies: string[];
  latencyMs: number;
  audioSampleContext: string;
  quarantineHash: string;
}

export interface RLEpisodeRecord {
  episode: number;
  timestamp: number;
  sampleType: 'SYNTHETIC_VOICE_CLONE' | 'AUTHENTIC_HUMAN' | 'ADVERSARIAL_DIFFUSION' | 'TELEPHONY_CODEC_DEGRADED';
  sampleName: string;
  actionsTaken: RLActionType[];
  finalReward: number;
  loss: number;
  epsilon: number;
  detectionLatencyMs: number;
  wasCorrect: boolean;
  threatCaught: boolean;
}

export interface RLAgentMetrics {
  currentEpisode: number;
  totalCaughtClones: number;
  totalFalsePositives: number;
  cumulativeReward: number;
  averageRewardRecent: number;
  policyAccuracy: number; // %
  meanCatchLatencyMs: number; // e.g. 142ms
  explorationRateEpsilon: number; // e.g. 0.05
  learningRateAlpha: number; // e.g. 0.002
  discountFactorGamma: number; // e.g. 0.95
  currentPolicyEntropy: number;
  activeModelCheckpoint: string;
}


export interface ForensicReportEntry {
  id: string;
  timestamp: number;
  source: 'Upload' | 'Microphone' | 'Live Call';
  telemetrySnapshot: AcousticTelemetry;
  analysis: CallAnalysisResult;
}
