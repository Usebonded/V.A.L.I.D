/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CustomCursor } from './components/CustomCursor';
import { BackgroundAcousticMatrix } from './components/BackgroundAcousticMatrix';
import { Navbar } from './components/Navbar';
import { PageHeader } from './components/PageHeader';
import { GlobalThreatAlertOverlay } from './components/GlobalThreatAlertOverlay';
import { OverviewDashboard } from './components/OverviewDashboard';
import { LiveCallInterceptor } from './components/LiveCallInterceptor';
import { ForensicReportView } from './components/ForensicReportView';
import { ProceduralSafeguardModule } from './components/ProceduralSafeguardModule';
import { AudioUploaderTester } from './components/AudioUploaderTester';
import { ArchitectureDocsModal } from './components/ArchitectureDocsModal';
import { MicrophonePermissionModal } from './components/MicrophonePermissionModal';
import { VoiceVerdictModal } from './components/VoiceVerdictModal';
import { AcousticTelemetry, VishingScenario, ForensicReportEntry } from './types';
import { startMicrophoneCapture, startSimulatedMicrophoneCapture } from './utils/audioEngine';
import { SCENARIOS } from './data/scenarios';
import { Activity, Radio, Cpu, Layers } from 'lucide-react';

const DEFAULT_TELEMETRY: AcousticTelemetry = {
  timestamp: Date.now(),
  rms: 0.04,
  peakDb: -32,
  pitchHz: 152,
  pitchJitterPercent: 0.72,
  shimmerPercent: 1.85,
  microPauseDurationMs: 380,
  microPauseVariance: 320,
  spectralRollOffHz: 21800,
  vocoderArtifactScore: 8,
  phaseContinuityScore: 88,
  backgroundNoiseCoherence: 86,
  syntheticProbability: 6.2,
  formants: {
    f1: 480,
    f2: 1720,
    f3: 2840,
  },
};

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [reportsHistory, setReportsHistory] = useState<ForensicReportEntry[]>([]);
  const [telemetry, setTelemetry] = useState<AcousticTelemetry>(DEFAULT_TELEMETRY);
  const [isLiveMicActive, setIsLiveMicActive] = useState<boolean>(false);
  const [isSimulatingCall, setIsSimulatingCall] = useState<boolean>(false);
  const [biomarkerSubTab, setBiomarkerSubTab] = useState<'biomarkers' | 'features' | 'waterfall'>('biomarkers');
  const [showMicModal, setShowMicModal] = useState<boolean>(false);
  const [micErrorMessage, setMicErrorMessage] = useState<string | null>(null);
  const [showVerdictModal, setShowVerdictModal] = useState<boolean>(false);
  const micControllerRef = useRef<{ stop: () => void } | null>(null);

  const handleToggleMic = async () => {
    if (isLiveMicActive) {
      if (micControllerRef.current) {
        micControllerRef.current.stop();
        micControllerRef.current = null;
      }
      setIsLiveMicActive(false);
    } else {
      try {
        const controller = await startMicrophoneCapture((newTelemetry) => {
          setTelemetry(newTelemetry);
        });
        micControllerRef.current = controller;
        setIsLiveMicActive(true);
        setActiveTab('audio_upload');
      } catch (err: unknown) {
        const error = err as { message?: string };
        const msg = error.message || 'Microphone access denied or unavailable.';
        console.warn('Microphone capture error handled:', msg);
        setMicErrorMessage(msg);
        setShowMicModal(true);
      }
    }
  };

  const handleActivateSimulation = () => {
    if (micControllerRef.current) {
      micControllerRef.current.stop();
      micControllerRef.current = null;
    }
    const controller = startSimulatedMicrophoneCapture((newTelemetry) => {
      setTelemetry(newTelemetry);
    }, false, { fftSize: 2048 });
    micControllerRef.current = controller;
    setIsLiveMicActive(true);
    setShowMicModal(false);
    setActiveTab('audio_upload');
  };

  const handleSelectScenarioForCall = (scenario: VishingScenario) => {
    setActiveTab('sentinel');
  };

  const handleTestAuthenticSample = () => {
    setTelemetry({
      ...DEFAULT_TELEMETRY,
      syntheticProbability: 3.4,
      vocoderArtifactScore: 4,
      phaseContinuityScore: 92,
      pitchJitterPercent: 0.88,
      shimmerPercent: 1.95,
      spectralRollOffHz: 21800,
      microPauseVariance: 340,
      backgroundNoiseCoherence: 94,
    });
  };

  const handleTestFakeSample = () => {
    setTelemetry({
      ...DEFAULT_TELEMETRY,
      syntheticProbability: 96.8,
      vocoderArtifactScore: 94,
      phaseContinuityScore: 28,
      pitchJitterPercent: 0.06,
      shimmerPercent: 0.32,
      spectralRollOffHz: 16000,
      microPauseVariance: 8,
      backgroundNoiseCoherence: 24,
    });
  };

  return (
    <div className="relative min-h-screen bg-black text-zinc-100 font-sans selection:bg-zinc-800 selection:text-white flex flex-col justify-between">
      {/* WAVES Inspired Glowing Cursor */}
      <CustomCursor />

      {/* Background Interactive Acoustic & Dither Matrix Canvas */}
      <BackgroundAcousticMatrix 
        telemetry={telemetry} 
        threatDetected={telemetry.syntheticProbability > 65} 
      />

      {/* Global Alert Notification System (>80% Synthetic Probability Threshold) */}
      <GlobalThreatAlertOverlay 
        telemetry={telemetry}
        onNavigateToTab={(tab) => setActiveTab(tab)}
      />

      {/* Main Container */}
      <div className="relative z-10 flex flex-col flex-grow">
        {/* Top Navbar */}
        <Navbar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          isLiveMicActive={isLiveMicActive}
          onToggleMic={handleToggleMic}
          isSimulatingCall={isSimulatingCall}
          onOpenVerdictModal={() => setShowVerdictModal(true)}
          syntheticProbability={telemetry.syntheticProbability}
        />

        {/* Main Content Area (Multipage Routing Container) */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-grow w-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18, ease: 'easeOut' }}
              className="w-full"
            >
              {/* PAGE 1: OVERVIEW DASHBOARD (HOME) */}
              {activeTab === 'overview' && (
                <OverviewDashboard
                  telemetry={telemetry}
                  onNavigate={(tab) => setActiveTab(tab)}
                  onOpenVerdictModal={() => setShowVerdictModal(true)}
                  isLiveMicActive={isLiveMicActive}
                  onToggleMic={handleToggleMic}
                />
              )}

              {/* PAGE 2: REAL-TIME INGRESS INTERCEPTOR */}
              {(activeTab === 'sentinel' || activeTab === 'analysis') && (
                <div>
                  <PageHeader
                    title="Real-Time Telephony Ingress Interceptor"
                    subtitle="Sub-200ms streaming DSP inspection, 2048-bin FFT spectrum visualization, and instant automated session termination killswitch."
                    category="REAL-TIME INGRESS"
                    onNavigateHome={() => setActiveTab('overview')}
                    isLiveMicActive={isLiveMicActive}
                    onToggleMic={handleToggleMic}
                    telemetry={telemetry}
                  />
                  <LiveCallInterceptor
                    currentTelemetry={telemetry}
                    onTelemetryUpdate={setTelemetry}
                    onOpenProcedural={() => setActiveTab('procedural_guard')}
                    onOpenAudioUpload={() => setActiveTab('audio_upload')}
                    onReportGenerated={(report) => setReportsHistory(prev => [report, ...prev])}
                  />
                </div>
              )}

              {/* PAGE 3: AUDIO UPLOAD & FORENSIC DSP LAB */}
              {(activeTab === 'audio_upload' || activeTab === 'audio_lab') && (
                <div>
                  <PageHeader
                    title="Audio File Ingestion & Forensic DSP Inspector"
                    subtitle="Upload voice recordings (.wav, .mp3, .m4a, .flac) or load benchmark samples to evaluate 16kHz vocoder cliffs, glottal jitter, and deepfake probability."
                    category="OFFLINE FORENSICS"
                    onNavigateHome={() => setActiveTab('overview')}
                    isLiveMicActive={isLiveMicActive}
                    onToggleMic={handleToggleMic}
                    telemetry={telemetry}
                  />
                  <AudioUploaderTester
                    onTelemetryUpdate={setTelemetry}
                    isLiveMicActive={isLiveMicActive}
                    onToggleMic={handleToggleMic}
                    onNavigateToTab={(tab) => setActiveTab(tab)}
                    onReportGenerated={(report) => setReportsHistory(prev => [report, ...prev])}
                  />
                </div>
              )}

                            {/* PAGE 4: FORENSIC REPORT */}
              {activeTab === 'forensic_report' && (
                <div>
                  <PageHeader
                    title="Forensic Analysis Report"
                    subtitle="Detailed log of deep reasoning, acoustic anomalies, and behavioral psychology flags intercepted."
                    category="FORENSIC LOGS"
                    onNavigateHome={() => setActiveTab('overview')}
                    isLiveMicActive={isLiveMicActive}
                    onToggleMic={handleToggleMic}
                    telemetry={telemetry}
                  />
                  <div className="p-6 sm:p-10 max-w-7xl mx-auto">
                    <ForensicReportView
                      reportsHistory={reportsHistory}
                      onNavigateToTab={setActiveTab}
                    />
                  </div>
                </div>
              )}

              {/* PAGE 9: PROCEDURAL SAFEGUARDS & MFA */}
              {activeTab === 'procedural_guard' && (
                <div>
                  <PageHeader
                    title="Procedural Safeguards & Cognitive Challenges"
                    subtitle="Out-of-band verification workflows, zero-trust phrase responses, and operator escalation protocols."
                    category="DEFENSIVE PROTOCOLS"
                    onNavigateHome={() => setActiveTab('overview')}
                    isLiveMicActive={isLiveMicActive}
                    onToggleMic={handleToggleMic}
                    telemetry={telemetry}
                  />
                  <ProceduralSafeguardModule />
                </div>
              )}

              {/* PAGE 10: ARCHITECTURE & TECHNICAL BLUEPRINT */}
              {activeTab === 'architecture' && (
                <div>
                  <PageHeader
                    title="Security Architecture & DSP Whitepaper"
                    subtitle="Comprehensive technical specifications of sub-phonemic neural feature extraction, vocoder artifacts, and anti-vishing defenses."
                    category="DOCUMENTATION & RESEARCH"
                    onNavigateHome={() => setActiveTab('overview')}
                    isLiveMicActive={isLiveMicActive}
                    onToggleMic={handleToggleMic}
                    telemetry={telemetry}
                  />
                  <ArchitectureDocsModal />
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Microphone Permission Fallback Modal */}
      <MicrophonePermissionModal
        isOpen={showMicModal}
        errorMessage={micErrorMessage}
        onClose={() => setShowMicModal(false)}
        onActivateSimulation={handleActivateSimulation}
        onNavigateToAudioLab={() => {
          setShowMicModal(false);
          setActiveTab('audio_upload');
        }}
        onRetry={() => {
          setShowMicModal(false);
          handleToggleMic();
        }}
      />

      {/* Instant Authentic / Fake Voice Verdict Popup */}
      <VoiceVerdictModal
        isOpen={showVerdictModal}
        onClose={() => setShowVerdictModal(false)}
        telemetry={telemetry}
        onNavigateToTab={(tab) => {
          setShowVerdictModal(false);
          setActiveTab(tab);
        }}
        onTestAuthentic={handleTestAuthenticSample}
        onTestFake={handleTestFakeSample}
      />
    </div>
  );
}
