/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  AcousticTelemetry,
  RLActionCandidate,
  RLActionType,
  RLAgentMetrics,
  RLAgentStateVector,
  RLCatchAlert,
  RLEpisodeRecord
} from '../types';

export const RL_ACTIONS: { action: RLActionType; label: string; desc: string }[] = [
  {
    action: 'PASS_CLEAN',
    label: 'Pass Clean (Low Friction)',
    desc: 'Permit unfiltered audio stream pass-through. Optimal for authentic human voice with normal biological jitter.',
  },
  {
    action: 'ENHANCE_SAMPLING',
    label: 'Enhance Acoustic Sampling',
    desc: 'Escalate to 2048 FFT bispectrum inspection to verify questionable phase continuity or minor vocoder artifacts.',
  },
  {
    action: 'PROMPT_COGNITIVE_CHALLENGE',
    label: 'Prompt Vocal Challenge',
    desc: 'Inject unpredictable procedural passphrase to test speaker cognitive response latency (<800ms vs AI clone delays).',
  },
  {
    action: 'RAISE_SOC_THREAT_ALERT',
    label: 'Raise High-Priority SOC Alert',
    desc: 'Broadcast immediate synthesized deepfake alert notification across enterprise channels and initiate recording audit.',
  },
  {
    action: 'TRIGGER_SIP_BYE_KILLSWITCH',
    label: 'Trigger SIP BYE Killswitch',
    desc: 'Autonomous instant session termination, audio stream scrambling, and cryptographic incident vault quarantine.',
  },
];

export interface AdversarialVoiceSample {
  id: string;
  name: string;
  architecture: string;
  category: 'SYNTHETIC_VOICE_CLONE' | 'AUTHENTIC_HUMAN' | 'ADVERSARIAL_DIFFUSION' | 'TELEPHONY_CODEC_DEGRADED';
  vocoderRollOffAnomaly: number; // 0 - 1
  phaseContinuityDisruption: number; // 0 - 1
  microPauseRigidity: number; // 0 - 1
  pitchJitterPerturbation: number; // 0 - 1
  bispectrumDecoupling: number; // 0 - 1
  temporalFrameJitter: number; // 0 - 1
  ambientRirCoherence: number; // 0 - 1
  voiceprintDeviation: number; // 0 - 1
  description: string;
  cloneSignature: string;
}

export const ADVERSARIAL_SAMPLES: AdversarialVoiceSample[] = [
  {
    id: 'adv-01',
    name: 'ElevenLabs Multilingual v3 (Zero-Shot Clone)',
    architecture: 'Latent Diffusion + Hifi-GAN Neural Vocoder',
    category: 'SYNTHETIC_VOICE_CLONE',
    vocoderRollOffAnomaly: 0.94,
    phaseContinuityDisruption: 0.88,
    microPauseRigidity: 0.91,
    pitchJitterPerturbation: 0.85,
    bispectrumDecoupling: 0.92,
    temporalFrameJitter: 0.42,
    ambientRirCoherence: 0.15,
    voiceprintDeviation: 0.89,
    description: 'Ultra-low jitter with sharp 16kHz spectral roll-off and unnatural pitch contour micro-smoothing.',
    cloneSignature: 'ELEVENLABS_V3_LATENT_DIFFUSION',
  },
  {
    id: 'adv-02',
    name: 'OpenAI GPT-4o Voice Streaming Clone',
    architecture: 'End-to-End Multimodal Audio Transformer',
    category: 'SYNTHETIC_VOICE_CLONE',
    vocoderRollOffAnomaly: 0.82,
    phaseContinuityDisruption: 0.79,
    microPauseRigidity: 0.76,
    pitchJitterPerturbation: 0.74,
    bispectrumDecoupling: 0.83,
    temporalFrameJitter: 0.68,
    ambientRirCoherence: 0.22,
    voiceprintDeviation: 0.81,
    description: 'High naturalness but reveals glottal pulse phase decoupling in bispectrum analysis under 2048 FFT.',
    cloneSignature: 'GPT4O_END_TO_END_TRANSFORMER',
  },
  {
    id: 'adv-03',
    name: 'Tortoise-TTS Diffusion Pipeline',
    architecture: 'Autoregressive Decoder + CLVP Diffusion Rescoring',
    category: 'ADVERSARIAL_DIFFUSION',
    vocoderRollOffAnomaly: 0.96,
    phaseContinuityDisruption: 0.93,
    microPauseRigidity: 0.95,
    pitchJitterPerturbation: 0.89,
    bispectrumDecoupling: 0.96,
    temporalFrameJitter: 0.82,
    ambientRirCoherence: 0.08,
    voiceprintDeviation: 0.94,
    description: 'Severe micro-pause rigidity (<15ms variance) and repetitive STFT phase cancellation windows.',
    cloneSignature: 'TORTOISE_AUTOREGRESSIVE_DIFFUSION',
  },
  {
    id: 'adv-04',
    name: 'F5-TTS Flow Matching Speech Generator',
    architecture: 'Non-Autoregressive Flow Matching DiT',
    category: 'ADVERSARIAL_DIFFUSION',
    vocoderRollOffAnomaly: 0.89,
    phaseContinuityDisruption: 0.84,
    microPauseRigidity: 0.82,
    pitchJitterPerturbation: 0.81,
    bispectrumDecoupling: 0.88,
    temporalFrameJitter: 0.35,
    ambientRirCoherence: 0.18,
    voiceprintDeviation: 0.86,
    description: 'Flow matching ODE trajectory leaves subtle high-order cepstral oversmoothing in MFCC-11 & MFCC-12.',
    cloneSignature: 'F5_FLOW_MATCHING_DIT',
  },
  {
    id: 'adv-05',
    name: 'RVC v2 (Retrieval-based Real-time Voice Changer)',
    architecture: 'HuBERT Soft Feature + VITS Vocoder',
    category: 'SYNTHETIC_VOICE_CLONE',
    vocoderRollOffAnomaly: 0.91,
    phaseContinuityDisruption: 0.92,
    microPauseRigidity: 0.45,
    pitchJitterPerturbation: 0.88,
    bispectrumDecoupling: 0.90,
    temporalFrameJitter: 0.78,
    ambientRirCoherence: 0.29,
    voiceprintDeviation: 0.87,
    description: 'Live speaker conversion with pronounced formant pitch modulation artifacts and STFT phase boundary slips.',
    cloneSignature: 'RVC_V2_VITS_PITCH_DISPERSION',
  },
  {
    id: 'adv-06',
    name: 'Authentic Executive Voice (CFO Biological Call)',
    architecture: 'Organic Human Phonation & Vocal Tract Mechanics',
    category: 'AUTHENTIC_HUMAN',
    vocoderRollOffAnomaly: 0.05,
    phaseContinuityDisruption: 0.08,
    microPauseRigidity: 0.06,
    pitchJitterPerturbation: 0.12,
    bispectrumDecoupling: 0.07,
    temporalFrameJitter: 0.09,
    ambientRirCoherence: 0.94,
    voiceprintDeviation: 0.04,
    description: 'Organic diaphragmatic breathing cycles (3.8s cadence), natural glottal non-linearity, and continuous air pressure.',
    cloneSignature: 'AUTHENTIC_BIOLOGICAL_SPEECH',
  },
  {
    id: 'adv-07',
    name: 'Authentic Employee (Degraded G.711 / PSTN Codec)',
    architecture: 'PSTN 8kHz Bandlimited $\mu$-law Telephony',
    category: 'TELEPHONY_CODEC_DEGRADED',
    vocoderRollOffAnomaly: 0.38,
    phaseContinuityDisruption: 0.22,
    microPauseRigidity: 0.11,
    pitchJitterPerturbation: 0.25,
    bispectrumDecoupling: 0.19,
    temporalFrameJitter: 0.38,
    ambientRirCoherence: 0.81,
    voiceprintDeviation: 0.15,
    description: 'Narrowband compression but retains natural human pitch micro-tremors and biological respiration timing.',
    cloneSignature: 'PSTN_G711_NATURAL_COMPRESSION',
  },
  {
    id: 'adv-08',
    name: 'Chatterbox Zero-Shot AudioLM Impersonator',
    architecture: 'Hierarchical K-Means Acoustic Tokens',
    category: 'SYNTHETIC_VOICE_CLONE',
    vocoderRollOffAnomaly: 0.93,
    phaseContinuityDisruption: 0.90,
    microPauseRigidity: 0.94,
    pitchJitterPerturbation: 0.87,
    bispectrumDecoupling: 0.93,
    temporalFrameJitter: 0.54,
    ambientRirCoherence: 0.11,
    voiceprintDeviation: 0.91,
    description: 'Token quantization boundaries create discrete step-transitions in speech-to-silence energy envelopes.',
    cloneSignature: 'CHATTERBOX_TOKEN_QUANTIZATION',
  },
];

/**
 * Extract 8-D RL Agent State Vector from raw Acoustic Telemetry
 */
export function extractRLStateFromTelemetry(telemetry: AcousticTelemetry): RLAgentStateVector {
  const synthRatio = telemetry.syntheticProbability / 100;
  const vocoderRatio = (telemetry.vocoderArtifactScore || 8) / 100;
  const phaseDisruption = 1 - (telemetry.phaseContinuityScore || 88) / 100;
  const jitterPerturbation = Math.min(1, Math.max(0, (0.72 - (telemetry.pitchJitterPercent || 0.72)) / 0.65));
  const pauseRigidity = Math.min(1, Math.max(0, (300 - (telemetry.microPauseVariance || 300)) / 280));
  const rirCoherence = (telemetry.backgroundNoiseCoherence || 86) / 100;
  const bispectrumDecoupling = telemetry.bispectrumFeatures?.glottalPulseDecoupling ? 0.92 : synthRatio * 0.85;
  const voiceprintDeviation = synthRatio * 0.9;

  return {
    vocoderRollOffAnomaly: Math.min(1, Math.max(0, vocoderRatio)),
    phaseContinuityDisruption: Math.min(1, Math.max(0, phaseDisruption)),
    microPauseRigidity: Math.min(1, Math.max(0, pauseRigidity)),
    pitchJitterPerturbation: Math.min(1, Math.max(0, jitterPerturbation)),
    bispectrumDecoupling: Math.min(1, Math.max(0, bispectrumDecoupling)),
    temporalFrameJitter: 0.15 + synthRatio * 0.35,
    ambientRirCoherence: Math.min(1, Math.max(0, 1 - rirCoherence)),
    voiceprintDeviation: Math.min(1, Math.max(0, voiceprintDeviation)),
  };
}

/**
 * Compute Q-Values and Policy Action Distribution for the given RL state
 */
export function evaluateRLPolicy(
  state: RLAgentStateVector,
  temperature: number = 0.8
): { candidates: RLActionCandidate[]; bestAction: RLActionType; syntheticScore: number } {
  // Composite anomaly representation
  const threatScore =
    state.vocoderRollOffAnomaly * 0.24 +
    state.phaseContinuityDisruption * 0.22 +
    state.bispectrumDecoupling * 0.18 +
    state.microPauseRigidity * 0.14 +
    state.pitchJitterPerturbation * 0.12 +
    state.voiceprintDeviation * 0.10;

  // Q(s, a) policy mapping learned from offline Proximal Policy Optimization (PPO) checkpoints
  const qPassClean = (1 - threatScore) * 85 - threatScore * 180;
  const qEnhanceSampling = (1 - Math.abs(threatScore - 0.45) * 2) * 55 - 5;
  const qPromptChallenge = (1 - Math.abs(threatScore - 0.65) * 2) * 65 - 10;
  const qRaiseAlert = threatScore * 95 - (1 - threatScore) * 120;
  const qKillswitch = threatScore > 0.72 ? threatScore * 125 : threatScore * 40 - 150;

  const rawQValues: { action: RLActionType; q: number }[] = [
    { action: 'PASS_CLEAN', q: qPassClean },
    { action: 'ENHANCE_SAMPLING', q: qEnhanceSampling },
    { action: 'PROMPT_COGNITIVE_CHALLENGE', q: qPromptChallenge },
    { action: 'RAISE_SOC_THREAT_ALERT', q: qRaiseAlert },
    { action: 'TRIGGER_SIP_BYE_KILLSWITCH', q: qKillswitch },
  ];

  // Softmax policy exponentiation: \pi(a|s) = exp(Q/tau) / sum(exp(Q/tau))
  const maxQ = Math.max(...rawQValues.map((v) => v.q));
  const expValues = rawQValues.map((v) => Math.exp((v.q - maxQ) / Math.max(0.2, temperature * 15)));
  const sumExp = expValues.reduce((a, b) => a + b, 0);

  // Find argmax action
  let bestIdx = 0;
  let highestQ = -Infinity;
  rawQValues.forEach((item, idx) => {
    if (item.q > highestQ) {
      highestQ = item.q;
      bestIdx = idx;
    }
  });

  const candidates: RLActionCandidate[] = RL_ACTIONS.map((item, idx) => ({
    action: item.action,
    label: item.label,
    qValue: parseFloat(rawQValues[idx].q.toFixed(1)),
    probability: parseFloat(((expValues[idx] / sumExp) * 100).toFixed(1)),
    isChosen: idx === bestIdx,
  }));

  return {
    candidates,
    bestAction: rawQValues[bestIdx].action,
    syntheticScore: Math.min(100, Math.max(0, threatScore * 100)),
  };
}

/**
 * Play cybernetic RL Alert Sound Chime on Catch
 */
export function playRLCatchChime() {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    osc1.type = 'sawtooth';
    osc2.type = 'sine';

    const now = ctx.currentTime;
    // Fast frequency sweep warble
    osc1.frequency.setValueAtTime(880, now);
    osc1.frequency.exponentialRampToValueAtTime(1760, now + 0.08);
    osc1.frequency.exponentialRampToValueAtTime(880, now + 0.16);
    osc1.frequency.exponentialRampToValueAtTime(2200, now + 0.28);

    osc2.frequency.setValueAtTime(440, now);
    osc2.frequency.exponentialRampToValueAtTime(1100, now + 0.28);

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.45);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.46);
    osc2.stop(now + 0.46);
  } catch (err) {
    console.debug('RL Catch Chime skipped:', err);
  }
}

/**
 * Initialize Default RL Metrics
 */
export function getDefaultRLMetrics(): RLAgentMetrics {
  return {
    currentEpisode: 1420,
    totalCaughtClones: 488,
    totalFalsePositives: 2,
    cumulativeReward: 48920,
    averageRewardRecent: 94.2,
    policyAccuracy: 99.59,
    meanCatchLatencyMs: 146,
    explorationRateEpsilon: 0.04,
    learningRateAlpha: 0.002,
    discountFactorGamma: 0.95,
    currentPolicyEntropy: 0.18,
    activeModelCheckpoint: 'PPO-Acoustic-Conformer-v4.8-Enterprise',
  };
}

/**
 * Seed recent training episode history
 */
export function getInitialEpisodeRecords(): RLEpisodeRecord[] {
  return [
    {
      episode: 1420,
      timestamp: Date.now() - 12000,
      sampleType: 'SYNTHETIC_VOICE_CLONE',
      sampleName: 'ElevenLabs Multilingual v3',
      actionsTaken: ['ENHANCE_SAMPLING', 'RAISE_SOC_THREAT_ALERT', 'TRIGGER_SIP_BYE_KILLSWITCH'],
      finalReward: 118.5,
      loss: 0.0042,
      epsilon: 0.04,
      detectionLatencyMs: 142,
      wasCorrect: true,
      threatCaught: true,
    },
    {
      episode: 1419,
      timestamp: Date.now() - 34000,
      sampleType: 'ADVERSARIAL_DIFFUSION',
      sampleName: 'Tortoise-TTS Diffusion Pipeline',
      actionsTaken: ['ENHANCE_SAMPLING', 'TRIGGER_SIP_BYE_KILLSWITCH'],
      finalReward: 112.0,
      loss: 0.0048,
      epsilon: 0.04,
      detectionLatencyMs: 168,
      wasCorrect: true,
      threatCaught: true,
    },
    {
      episode: 1418,
      timestamp: Date.now() - 58000,
      sampleType: 'AUTHENTIC_HUMAN',
      sampleName: 'CFO Biological Phonation',
      actionsTaken: ['PASS_CLEAN'],
      finalReward: 65.0,
      loss: 0.0021,
      epsilon: 0.041,
      detectionLatencyMs: 45,
      wasCorrect: true,
      threatCaught: false,
    },
    {
      episode: 1417,
      timestamp: Date.now() - 92000,
      sampleType: 'SYNTHETIC_VOICE_CLONE',
      sampleName: 'Chatterbox Zero-Shot AudioLM',
      actionsTaken: ['PROMPT_COGNITIVE_CHALLENGE', 'TRIGGER_SIP_BYE_KILLSWITCH'],
      finalReward: 104.2,
      loss: 0.0055,
      epsilon: 0.042,
      detectionLatencyMs: 195,
      wasCorrect: true,
      threatCaught: true,
    },
    {
      episode: 1416,
      timestamp: Date.now() - 130000,
      sampleType: 'TELEPHONY_CODEC_DEGRADED',
      sampleName: 'PSTN G.711 Narrowband Caller',
      actionsTaken: ['ENHANCE_SAMPLING', 'PASS_CLEAN'],
      finalReward: 58.0,
      loss: 0.0039,
      epsilon: 0.042,
      detectionLatencyMs: 82,
      wasCorrect: true,
      threatCaught: false,
    },
  ];
}
