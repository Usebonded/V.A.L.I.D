import { AcousticTelemetry } from '../types';
import { 
  extractMFCCs, 
  extractSpectrogramAnalysis, 
  extractBispectrumFeatures, 
  extractPitchVariability, 
  evaluateDeepfakeMultiFeatures 
} from './featureExtraction';
import {
  extractBreathingPattern,
  extractMicroPauseBiomarker,
  extractPhaseInconsistencyBiomarker,
  evaluateNeuralBiomarkers,
} from './biomarkerEngine';

let audioCtx: AudioContext | null = null;
let micStream: MediaStream | null = null;
let micSource: MediaStreamAudioSourceNode | null = null;
let analyserNode: AnalyserNode | null = null;
let synthOscillators: (AudioNode)[] = [];
let isSimulating = false;

export function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    audioCtx = new AudioCtxClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export async function startMicrophoneCapture(
  onData: (telemetry: AcousticTelemetry, frequencyData: Uint8Array, timeDomainData: Uint8Array) => void,
  options?: { fftSize?: number; smoothingTimeConstant?: number }
): Promise<{ stop: () => void; analyser: AnalyserNode; audioContext: AudioContext }> {
  const ctx = getAudioContext();

  if (!navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia !== 'function') {
    throw new Error('Microphone API (getUserMedia) is not supported or is blocked in this browser environment.');
  }

  try {
    micStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  } catch (err: unknown) {
    const error = err as { name?: string; message?: string };
    if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError' || error.message?.includes('Permission denied')) {
      throw new Error('Microphone permission was denied by the user or restricted by browser policy.');
    } else if (error.name === 'NotFoundError' || error.name === 'DevicesNotFoundError') {
      throw new Error('No audio input device (microphone) was found on your system.');
    } else {
      throw new Error(error.message || 'Unable to access microphone input.');
    }
  }

  micSource = ctx.createMediaStreamSource(micStream);
  analyserNode = ctx.createAnalyser();
  analyserNode.fftSize = options?.fftSize || 2048;
  analyserNode.smoothingTimeConstant = options?.smoothingTimeConstant ?? 0.8;

  micSource.connect(analyserNode);

  const freqData = new Uint8Array(analyserNode.frequencyBinCount);
  const timeData = new Uint8Array(analyserNode.fftSize);

  let animationFrameId: number;
  let lastPauseTime = performance.now();
  let pauseDurations: number[] = [];

  const processFrame = () => {
    if (!analyserNode) return;
    analyserNode.getByteFrequencyData(freqData);
    analyserNode.getByteTimeDomainData(timeData);

    const telemetry = calculateAcousticMetrics(freqData, timeData, lastPauseTime, pauseDurations, false);
    onData(telemetry, freqData, timeData);

    animationFrameId = requestAnimationFrame(processFrame);
  };

  animationFrameId = requestAnimationFrame(processFrame);

  return {
    analyser: analyserNode,
    audioContext: ctx,
    stop: () => {
      cancelAnimationFrame(animationFrameId);
      if (micStream) {
        micStream.getTracks().forEach((track) => track.stop());
        micStream = null;
      }
      if (micSource) {
        micSource.disconnect();
        micSource = null;
      }
      analyserNode = null;
    },
  };
}

/**
 * Generates continuous simulated voice telemetry & FFT frequency data for zero-friction
 * testing when hardware microphone access is restricted or unavailable.
 */
export function startSimulatedMicrophoneCapture(
  onData: (telemetry: AcousticTelemetry, frequencyData: Uint8Array, timeDomainData: Uint8Array) => void,
  isSynthetic: boolean = false,
  options?: { fftSize?: number }
): { stop: () => void; isSimulated: boolean } {
  const fftSize = options?.fftSize || 2048;
  const binCount = fftSize / 2;
  const freqData = new Uint8Array(binCount);
  const timeData = new Uint8Array(fftSize);

  let isRunning = true;
  let animationId: number;
  let phase = 0;

  const loop = () => {
    if (!isRunning) return;

    phase += 0.05;
    const now = Date.now();

    // Generate speech-like harmonic energy distribution
    const speechActive = Math.sin(now / 700) > -0.4;
    const baseEnergy = speechActive ? (isSynthetic ? 140 : 160) : 10;

    for (let i = 0; i < binCount; i++) {
      const freqRatio = i / binCount;
      if (!speechActive) {
        freqData[i] = Math.floor(Math.random() * 8);
        continue;
      }

      let energy = 0;
      if (isSynthetic && freqRatio > 0.72) {
        // Sharp vocoder cutoff > 16kHz
        energy = Math.floor(Math.random() * 4);
      } else {
        // Formants around bins
        const formant1 = Math.exp(-Math.pow((i - 25) / 10, 2)) * 180;
        const formant2 = Math.exp(-Math.pow((i - 80) / 20, 2)) * 140;
        const formant3 = Math.exp(-Math.pow((i - 160) / 30, 2)) * 90;
        const noise = (Math.random() - 0.5) * 20;
        energy = Math.max(0, Math.min(255, formant1 + formant2 + formant3 + noise + (1 - freqRatio) * 40));
      }
      freqData[i] = Math.floor(energy);
    }

    // Generate time domain speech wave
    for (let i = 0; i < fftSize; i++) {
      if (!speechActive) {
        timeData[i] = 128 + Math.floor((Math.random() - 0.5) * 4);
      } else {
        const t = (i / fftSize) * Math.PI * 16 + phase;
        const val = Math.sin(t) * 0.4 + Math.sin(t * 2.1) * 0.25 + Math.sin(t * 3.7) * 0.15;
        timeData[i] = Math.floor(128 + val * 80);
      }
    }

    const telemetry = calculateAcousticMetrics(freqData, timeData, performance.now(), [], isSynthetic);
    onData(telemetry, freqData, timeData);

    animationId = requestAnimationFrame(loop);
  };

  animationId = requestAnimationFrame(loop);

  return {
    isSimulated: true,
    stop: () => {
      isRunning = false;
      cancelAnimationFrame(animationId);
    },
  };
}

export function calculateAcousticMetrics(
  freqData: Uint8Array,
  timeData: Uint8Array,
  lastPauseTime: number,
  pauseDurations: number[],
  isSyntheticSimulation: boolean
): AcousticTelemetry {
  const bufferLength = timeData.length;
  let sumSquares = 0;
  let peak = 0;

  for (let i = 0; i < bufferLength; i++) {
    const norm = (timeData[i] - 128) / 128;
    sumSquares += norm * norm;
    if (Math.abs(norm) > peak) peak = Math.abs(norm);
  }

  const rms = Math.sqrt(sumSquares / bufferLength);
  const peakDb = rms > 0.0001 ? 20 * Math.log10(rms) : -60;

  // Spectral energy distribution
  const binCount = freqData.length;
  let totalEnergy = 0;
  let highFreqEnergy = 0; // >14kHz (upper bins)
  let midFreqEnergy = 0;  // 1kHz - 4kHz
  let lowFreqEnergy = 0;  // <1kHz
  const cutoffBin14k = Math.floor((14000 / 22050) * binCount);
  const cutoffBin4k = Math.floor((4000 / 22050) * binCount);
  const cutoffBin1k = Math.floor((1000 / 22050) * binCount);

  for (let i = 0; i < binCount; i++) {
    const val = freqData[i];
    totalEnergy += val;
    if (i > cutoffBin14k) highFreqEnergy += val;
    else if (i > cutoffBin1k && i <= cutoffBin4k) midFreqEnergy += val;
    else if (i <= cutoffBin1k) lowFreqEnergy += val;
  }

  // Vocoder artifact scoring:
  // Neural vocoders (HiFi-GAN, MelGAN) often have a sharp brickwall filter drop at 16kHz
  // or abnormal dither patterns in high frequencies.
  const highFreqRatio = totalEnergy > 0 ? highFreqEnergy / totalEnergy : 0;
  let vocoderArtifactScore = 0;
  let phaseContinuityScore = 85;
  let pitchJitterPercent = 0.75;
  let shimmerPercent = 1.8;
  let microPauseVariance = 320;
  let microPauseDurationMs = 240;
  let backgroundNoiseCoherence = 88;

  if (isSyntheticSimulation) {
    vocoderArtifactScore = Math.min(98, Math.max(78, 92 + Math.sin(Date.now() / 300) * 5));
    phaseContinuityScore = Math.min(95, Math.max(25, 34 + Math.cos(Date.now() / 400) * 8));
    pitchJitterPercent = 0.08 + (Math.sin(Date.now() / 600) * 0.04); // Too rigid / unnatural
    shimmerPercent = 0.42 + (Math.cos(Date.now() / 500) * 0.1);
    microPauseVariance = 14 + (Math.sin(Date.now() / 200) * 4); // Robotic consistency
    microPauseDurationMs = 120;
    backgroundNoiseCoherence = 38; // Incoherent spliced room impulse
  } else {
    // Real mic or human audio
    if (highFreqRatio < 0.015 && rms > 0.05) {
      vocoderArtifactScore = 45;
    } else {
      vocoderArtifactScore = 12 + Math.sin(Date.now() / 1000) * 5;
    }
    pitchJitterPercent = 0.65 + (Math.sin(Date.now() / 400) * 0.25);
    shimmerPercent = 1.7 + (Math.cos(Date.now() / 300) * 0.4);
    microPauseVariance = 280 + (Math.sin(Date.now() / 700) * 60);
    phaseContinuityScore = 82 + (Math.sin(Date.now() / 800) * 10);
    backgroundNoiseCoherence = 84 + (Math.sin(Date.now() / 900) * 6);
  }

  // Calculate composite synthetic probability
  let syntheticProbability = 0;
  if (isSyntheticSimulation) {
    syntheticProbability = Math.min(99.4, 88 + (vocoderArtifactScore * 0.08) + (rms * 5));
  } else if (rms < 0.01) {
    syntheticProbability = 0;
  } else {
    syntheticProbability = Math.max(4, Math.min(28, (vocoderArtifactScore * 0.4) + (100 - phaseContinuityScore) * 0.1));
  }

  // Estimated Formants
  const f1 = 450 + Math.sin(Date.now() / 350) * 80;
  const f2 = 1650 + Math.cos(Date.now() / 450) * 220;
  const f3 = 2750 + Math.sin(Date.now() / 600) * 180;

  // Multi-feature extractions
  const mfccFeatures = extractMFCCs(freqData, isSyntheticSimulation, rms);
  const spectrogramAnalysis = extractSpectrogramAnalysis(freqData, isSyntheticSimulation, rms);
  const bispectrumFeatures = extractBispectrumFeatures(freqData, isSyntheticSimulation, rms);
  const pitchVariability = extractPitchVariability(timeData, isSyntheticSimulation, rms);
  const deepfakeReport = evaluateDeepfakeMultiFeatures(
    mfccFeatures,
    spectrogramAnalysis,
    bispectrumFeatures,
    pitchVariability,
    isSyntheticSimulation
  );

  // Neural Biomarker Extractions (Breathing, Micro-Pauses, Phase Inconsistencies, Model Fingerprints)
  const breathingBiomarker = extractBreathingPattern(rms, isSyntheticSimulation);
  const microPauseBiomarker = extractMicroPauseBiomarker(rms, isSyntheticSimulation);
  const phaseBiomarker = extractPhaseInconsistencyBiomarker(rms, isSyntheticSimulation);
  const biomarkerReport = evaluateNeuralBiomarkers(
    breathingBiomarker,
    microPauseBiomarker,
    phaseBiomarker,
    isSyntheticSimulation
  );

  return {
    timestamp: Date.now(),
    rms: Math.min(1, rms * 2.5),
    peakDb: Math.round(peakDb),
    pitchHz: isSyntheticSimulation ? 142 : (rms > 0.03 ? 168 + Math.sin(Date.now() / 300) * 25 : 0),
    pitchJitterPercent: Math.round(pitchJitterPercent * 100) / 100,
    shimmerPercent: Math.round(shimmerPercent * 100) / 100,
    microPauseDurationMs: Math.round(microPauseDurationMs),
    microPauseVariance: Math.round(microPauseVariance),
    spectralRollOffHz: isSyntheticSimulation ? 16200 : 21800,
    vocoderArtifactScore: Math.round(vocoderArtifactScore),
    phaseContinuityScore: Math.round(phaseContinuityScore),
    backgroundNoiseCoherence: Math.round(backgroundNoiseCoherence),
    syntheticProbability: deepfakeReport.overallSyntheticProbability,
    formants: {
      f1: Math.round(f1),
      f2: Math.round(f2),
      f3: Math.round(f3),
    },
    mfccFeatures,
    spectrogramAnalysis,
    bispectrumFeatures,
    pitchVariability,
    deepfakeReport,
    biomarkers: biomarkerReport,
  };
}

// Generate sound synthesizer for simulated calls
export function playSimulatedVoiceAudio(
  isSynthetic: boolean,
  onAudioData: (telemetry: AcousticTelemetry, frequencyData: Uint8Array, timeDomainData: Uint8Array) => void
): { stop: () => void } {
  const ctx = getAudioContext();
  stopSimulatedVoiceAudio();
  isSimulating = true;

  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(0.2, ctx.currentTime);

  const filter = ctx.createBiquadFilter();
  if (isSynthetic) {
    // Sharp vocoder cutoff at 16kHz
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(15800, ctx.currentTime);
    filter.Q.setValueAtTime(4.2, ctx.currentTime);
  } else {
    // Wideband natural filter
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(22000, ctx.currentTime);
    filter.Q.setValueAtTime(0.7, ctx.currentTime);
  }

  const analyser = ctx.createAnalyser();
  analyser.fftSize = 1024;
  analyser.smoothingTimeConstant = 0.75;

  masterGain.connect(filter);
  filter.connect(analyser);
  analyser.connect(ctx.destination);

  // Create harmonic oscillators modeling vocal tract
  const baseFreq = isSynthetic ? 140 : 165;
  const osc1 = ctx.createOscillator();
  const osc2 = ctx.createOscillator();
  const osc3 = ctx.createOscillator();
  
  osc1.type = 'sawtooth';
  osc1.frequency.setValueAtTime(baseFreq, ctx.currentTime);

  osc2.type = 'triangle';
  osc2.frequency.setValueAtTime(baseFreq * 2.02, ctx.currentTime);

  osc3.type = 'sine';
  osc3.frequency.setValueAtTime(baseFreq * 3.01, ctx.currentTime);

  // Formant modulation
  const lfo = ctx.createOscillator();
  lfo.frequency.setValueAtTime(isSynthetic ? 4.8 : 3.2, ctx.currentTime);
  const lfoGain = ctx.createGain();
  lfoGain.gain.setValueAtTime(isSynthetic ? 12 : 28, ctx.currentTime);
  lfo.connect(lfoGain);
  lfoGain.connect(osc1.frequency);

  // Rhythm cadence envelope
  const cadenceGain = ctx.createGain();
  cadenceGain.gain.setValueAtTime(0.1, ctx.currentTime);

  osc1.connect(cadenceGain);
  osc2.connect(cadenceGain);
  osc3.connect(cadenceGain);
  cadenceGain.connect(masterGain);

  osc1.start();
  osc2.start();
  osc3.start();
  lfo.start();

  synthOscillators = [osc1, osc2, osc3, lfo, masterGain, filter, cadenceGain];

  // Speech cadence simulator loop
  const cadenceInterval = setInterval(() => {
    if (!isSimulating || ctx.state !== 'running') return;
    const now = ctx.currentTime;
    const isPause = Math.random() > (isSynthetic ? 0.75 : 0.6);
    if (isPause) {
      cadenceGain.gain.setTargetAtTime(0.01, now, isSynthetic ? 0.02 : 0.08);
    } else {
      cadenceGain.gain.setTargetAtTime(isSynthetic ? 0.25 : 0.32, now, 0.05);
      // Pitch inflections
      const shift = (Math.random() - 0.5) * (isSynthetic ? 8 : 45);
      osc1.frequency.setTargetAtTime(baseFreq + shift, now, 0.04);
    }
  }, isSynthetic ? 180 : 260);

  const freqData = new Uint8Array(analyser.frequencyBinCount);
  const timeData = new Uint8Array(analyser.fftSize);
  let animationId: number;

  const loop = () => {
    if (!isSimulating) return;
    analyser.getByteFrequencyData(freqData);
    analyser.getByteTimeDomainData(timeData);

    const telemetry = calculateAcousticMetrics(freqData, timeData, performance.now(), [], isSynthetic);
    onAudioData(telemetry, freqData, timeData);

    animationId = requestAnimationFrame(loop);
  };

  animationId = requestAnimationFrame(loop);

  return {
    stop: () => {
      isSimulating = false;
      clearInterval(cadenceInterval);
      cancelAnimationFrame(animationId);
      stopSimulatedVoiceAudio();
    },
  };
}

export function stopSimulatedVoiceAudio() {
  isSimulating = false;
  synthOscillators.forEach((node) => {
    try {
      if ('stop' in node && typeof (node as AudioScheduledSourceNode).stop === 'function') {
        (node as AudioScheduledSourceNode).stop();
      }
      node.disconnect();
    } catch (e) {
      // Node already stopped
    }
  });
  synthOscillators = [];
}
