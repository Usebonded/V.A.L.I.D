import {
  InferencePipelineMetrics,
  ThreatIncidentAlert,
  ThreatPreventionPolicy,
} from '../types';

export const DEFAULT_THREAT_POLICY: ThreatPreventionPolicy = {
  autoTerminationEnabled: true,
  terminationThresholdConfidence: 80,
  inCallWarningOverlayEnabled: true,
  warningSensitivityTier: 'STRICT',
  automatedAdminAlertsEnabled: true,
  targetedUserSmsAlertsEnabled: true,
  socWebhookUrl: 'https://soc.enterprise-defense.internal/api/v1/telephony/alerts',
};

export const INITIAL_INCIDENT_ALERTS: ThreatIncidentAlert[] = [
  {
    id: 'inc-9082-alert',
    timestamp: '2026-08-26 11:42:08 UTC',
    threatLevel: 'CRITICAL',
    callerName: 'Alexander Hayes (Cloned Persona)',
    targetEmployee: 'Marcus Vance (Senior Treasury Analyst)',
    channel: 'SIP_TRUNK_01',
    syntheticConfidence: 94.2,
    primaryBiomarkerTrigger: 'Instantaneous Phase Discontinuity (88%) & Absent Diaphragmatic Cycles',
    actionTaken: 'AUTO_TERMINATED_SIP_BYE',
    notificationRecipients: [
      { channel: 'SMS', destination: '+1 (555) 019-2834 (Target Analyst)', status: 'DELIVERED' },
      { channel: 'SOC_WEBHOOK', destination: 'Splunk SIEM / SecOps Cluster #4', status: 'DELIVERED' },
      { channel: 'ADMIN_PUSH', destination: 'CISO Emergency Channel', status: 'DELIVERED' },
    ],
    payloadSummary: 'Unauthorized wire transfer diversion attempt of $4.8M to offshore shell entity.',
  },
  {
    id: 'inc-9081-alert',
    timestamp: '2026-08-26 09:15:32 UTC',
    threatLevel: 'HIGH',
    callerName: 'Elena Rostova (AI Voice Clone)',
    targetEmployee: 'David Chen (VP Cloud Infrastructure)',
    channel: 'WEBRTC_VOIP',
    syntheticConfidence: 86.5,
    primaryBiomarkerTrigger: '16.0 kHz Brickwall Cutoff & Token Quantization Rigidity (79%)',
    actionTaken: 'STEP_UP_MFA_ENFORCED',
    notificationRecipients: [
      { channel: 'SMS', destination: '+1 (555) 014-9921 (Target VP)', status: 'DELIVERED' },
      { channel: 'SOC_WEBHOOK', destination: 'Enterprise EDR Syslog', status: 'DELIVERED' },
    ],
    payloadSummary: 'Credential bypass & emergency production Okta MFA token re-issuance request.',
  },
];

/**
 * 1. Low-Latency Pipeline Metric Generator (<200 ms budget)
 */
export function getLiveInferenceMetrics(
  isStreaming: boolean,
  elapsedSec: number
): InferencePipelineMetrics {
  const frameChunkSizeMs = 20; // 20ms standard audio slice
  
  if (!isStreaming) {
    return {
      frameChunkSizeMs,
      featureExtractLatencyMs: 0,
      modelInferenceLatencyMs: 0,
      totalPipelineLatencyMs: 0,
      latencyBudgetMaxMs: 200,
      jitterMs: 0.8,
      cpuUtilizationPercent: 1.2,
      memoryFootprintMb: 14.2,
      modelArchitecture: 'Quantized MobileNet-V3 1D-CNN + Temporal Conformer',
      modelParamSizeMb: 3.4,
      processedFramesCount: 0,
      bufferHealth: 'OPTIMAL',
    };
  }

  // Micro-fluctuations in DSP & Neural inference execution
  const jitterOsc = Math.sin(Date.now() / 400) * 2.5;
  const featureExtractLatencyMs = Math.round(18 + Math.sin(Date.now() / 600) * 3);
  const modelInferenceLatencyMs = Math.round(32 + Math.cos(Date.now() / 500) * 4);
  const totalPipelineLatencyMs = featureExtractLatencyMs + modelInferenceLatencyMs + Math.round(jitterOsc > 0 ? jitterOsc : 0);
  const jitterMs = Math.round((1.2 + Math.abs(Math.sin(Date.now() / 300)) * 0.8) * 10) / 10;
  const cpuUtilizationPercent = Math.round((4.2 + Math.abs(Math.sin(Date.now() / 800)) * 1.6) * 10) / 10;
  const processedFramesCount = Math.floor(elapsedSec * 50); // 50 frames/sec (20ms frames)

  return {
    frameChunkSizeMs,
    featureExtractLatencyMs,
    modelInferenceLatencyMs,
    totalPipelineLatencyMs,
    latencyBudgetMaxMs: 200,
    jitterMs,
    cpuUtilizationPercent,
    memoryFootprintMb: 14.2,
    modelArchitecture: 'Quantized MobileNet-V3 1D-CNN + Temporal Conformer',
    modelParamSizeMb: 3.4,
    processedFramesCount,
    bufferHealth: totalPipelineLatencyMs < 120 ? 'OPTIMAL' : totalPipelineLatencyMs < 180 ? 'ACCEPTABLE' : 'DEGRADED',
  };
}

/**
 * 2. Dispatch Automated Threat Alert to Targeted Employee and Enterprise SOC
 */
export function dispatchThreatAlert(
  callerName: string,
  targetEmployee: string,
  syntheticConfidence: number,
  primaryBiomarkerTrigger: string,
  actionTaken: ThreatIncidentAlert['actionTaken']
): ThreatIncidentAlert {
  const threatLevel: ThreatIncidentAlert['threatLevel'] =
    syntheticConfidence >= 80 ? 'CRITICAL' : syntheticConfidence >= 55 ? 'HIGH' : 'MEDIUM';

  return {
    id: `inc-${Math.floor(1000 + Math.random() * 9000)}-alert`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC',
    threatLevel,
    callerName,
    targetEmployee,
    channel: 'SIP_TRUNK_01',
    syntheticConfidence: Math.round(syntheticConfidence * 10) / 10,
    primaryBiomarkerTrigger,
    actionTaken,
    notificationRecipients: [
      { channel: 'SMS', destination: '+1 (555) 018-7712 (Target Employee)', status: 'DELIVERED' },
      { channel: 'SOC_WEBHOOK', destination: 'Enterprise SIEM / Splunk Ingestion', status: 'DELIVERED' },
      { channel: 'ADMIN_PUSH', destination: 'SecOps Critical Response Webhook', status: 'DELIVERED' },
    ],
    payloadSummary: `AI synthetic voice impersonation intercepted. Voice confidence ${syntheticConfidence}%. Immediate ${actionTaken.replace(/_/g, ' ')} executed.`,
  };
}

/**
 * 3. Generate Simulated Raw SIP BYE Disconnect Packet
 */
export function generateSipByePacket(callId: string, reason: string): string {
  return `BYE sip:operator@enterprise.internal:5060 SIP/2.0
Via: SIP/2.0/UDP 10.240.1.18:5060;branch=z9hG4bK-77a8b
Max-Forwards: 70
From: <sip:valid-sentinel@security.internal>;tag=99128a
To: <sip:caller@pstn-gateway.internal>;tag=44129x
Call-ID: ${callId || 'c48a-9921-bc77'}
CSeq: 102 BYE
Reason: Q.850;cause=16;text="SECURITY_KILLSWITCH_${reason.toUpperCase().replace(/\s+/g, '_')}"
X-VALID-Threat-Verdict: CRITICAL_DEEPFAKE_VISHING
Content-Length: 0`;
}
