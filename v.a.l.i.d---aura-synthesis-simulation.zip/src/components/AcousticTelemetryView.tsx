import React, { useEffect, useRef } from 'react';
import { Activity, Radio, Cpu, Layers, BarChart3, AlertCircle, CheckCircle2, Shield } from 'lucide-react';
import { AcousticTelemetry } from '../types';

interface AcousticTelemetryViewProps {
  telemetry: AcousticTelemetry;
  isSimulating: boolean;
}

export const AcousticTelemetryView: React.FC<AcousticTelemetryViewProps> = ({
  telemetry,
  isSimulating,
}) => {
  const spectrogramCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const waterfallHistoryRef = useRef<number[][]>([]);

  // Update waterfall spectrogram
  useEffect(() => {
    const canvas = spectrogramCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = (canvas.width = canvas.parentElement?.clientWidth || 700);
    const height = (canvas.height = 180);

    // Generate a slice of frequencies based on current telemetry
    const slice: number[] = [];
    const numBins = 64;
    const isSynthetic = telemetry.syntheticProbability > 65;

    for (let i = 0; i < numBins; i++) {
      const freqHz = (i / numBins) * 22050;
      let power = 0;

      // Model formants
      if (Math.abs(freqHz - telemetry.formants.f1) < 150) power += 0.8;
      if (Math.abs(freqHz - telemetry.formants.f2) < 250) power += 0.6;
      if (Math.abs(freqHz - telemetry.formants.f3) < 350) power += 0.4;

      // Model vocoder cutoff if synthetic
      if (isSynthetic && freqHz > 15800) {
        power *= 0.05; // sharp cutoff
      } else {
        power += (Math.random() * 0.15 * telemetry.rms);
      }

      slice.push(Math.min(1, Math.max(0, power * (telemetry.rms > 0.02 ? 1 : 0.05))));
    }

    waterfallHistoryRef.current.unshift(slice);
    if (waterfallHistoryRef.current.length > width / 4) {
      waterfallHistoryRef.current.pop();
    }

    // Render waterfall
    ctx.fillStyle = '#09090b';
    ctx.fillRect(0, 0, width, height);

    // Draw spectrogram rows
    const history = waterfallHistoryRef.current;
    const columnWidth = 4;

    for (let col = 0; col < history.length; col++) {
      const currentSlice = history[col];
      const x = width - col * columnWidth;
      const binHeight = height / numBins;

      for (let row = 0; row < numBins; row++) {
        const val = currentSlice[row];
        const y = height - (row + 1) * binHeight;

        if (isSynthetic) {
          // Threat Spectrogram color palette (Crimson to Orange to Black)
          const r = Math.floor(val * 255);
          const g = Math.floor(val * val * 90);
          const b = Math.floor(val * val * 40);
          ctx.fillStyle = `rgb(${r},${g},${b})`;
        } else {
          // Clean Monochrome/Cyan Organic Spectrogram
          const brightness = Math.floor(val * 255);
          ctx.fillStyle = `rgb(${brightness},${brightness},${Math.floor(brightness * 1.1)})`;
        }

        ctx.fillRect(x, y, columnWidth, binHeight + 0.5);
      }
    }

    // Overlay 16kHz vocoder threshold boundary line
    const cutoffY = height - (16000 / 22050) * height;
    ctx.strokeStyle = isSynthetic ? 'rgba(239, 68, 68, 0.7)' : 'rgba(161, 161, 170, 0.3)';
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(0, cutoffY);
    ctx.lineTo(width, cutoffY);
    ctx.stroke();
    ctx.setLineDash([]);
  }, [telemetry]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Activity className="w-4 h-4 text-white" />
              <span className="text-xs font-mono text-[#A1A1AA] uppercase tracking-widest">
                Digital Signal Processing Matrix
              </span>
            </div>
            <h2 className="text-2xl font-sans font-medium text-white tracking-tight">
              Acoustic Signal & Vocoder Telemetry
            </h2>
            <p className="text-xs text-[#A1A1AA] max-w-2xl mt-1 font-sans">
              Real-time spectral waterfall, Nyquist floor dither inspection, and micro-pause cadence distribution.
            </p>
          </div>

          <div className="hidden sm:flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-2xl text-xs font-mono bg-white/5 border border-white/10 text-white uppercase tracking-wider">
              <Radio className="w-3.5 h-3.5 text-cyan-400" />
              WIDEBAND PCM 22.05 kHz
            </span>
          </div>
        </div>
      </div>

      {/* Main Waterfall Spectrogram */}
      <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-white" />
            <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider">
              Time-Frequency Spectral Waterfall (0 Hz – 22.05 kHz)
            </span>
          </div>
          <span className="text-[10px] font-mono text-[#A1A1AA] uppercase">
            Dashed Line = 16.0 kHz Neural Vocoder Compression Threshold
          </span>
        </div>

        <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-black">
          <canvas ref={spectrogramCanvasRef} className="w-full h-[180px] block" />
          <div className="absolute left-2 top-2 text-[9px] font-mono text-[#A1A1AA] bg-black/90 px-2 py-0.5 rounded-2xl border border-white/10 uppercase">
            High Frequencies (Nyquist Upper Bound 22kHz)
          </div>
          <div className="absolute left-2 bottom-2 text-[9px] font-mono text-[#A1A1AA] bg-black/90 px-2 py-0.5 rounded-2xl border border-white/10 uppercase">
            Fundamental & Formants F0-F1 (0 - 1kHz)
          </div>
        </div>
      </div>

      {/* 4 Deep Dive Forensic Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Pillar 1: Micro-Pause & Respiratory Cadence */}
        <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-white" />
              1. Respiratory Micro-Pause Variance
            </span>
            <span className={`px-2 py-0.5 rounded-2xl text-[10px] font-mono uppercase tracking-wider ${
              telemetry.microPauseVariance < 30 ? 'bg-red-950 text-red-300 border border-red-800' : 'bg-neutral-900/60 backdrop-blur-xl text-white border border-white/10'
            }`}>
              {telemetry.microPauseVariance}ms (Delta)
            </span>
          </div>
          <p className="text-xs text-[#A1A1AA] leading-relaxed font-sans">
            Attackers generating speech via 3-second audio clones concatenate neural tokens without biological lungs. Genuine speech possesses diaphragmatic breath decay intervals of 300–650ms. Synthetic models output quantized, unnatural inter-word gaps under 25ms.
          </p>
          <div className="p-2.5 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 font-mono text-[11px] text-[#A1A1AA] flex items-center justify-between uppercase">
            <span>Biological Diaphragm Variance:</span>
            <span className="text-cyan-400 font-bold">&gt; 250ms</span>
          </div>
        </div>

        {/* Pillar 2: Vocoder High-Frequency Cutoff */}
        <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5 text-white" />
              2. Vocoder High-Frequency Cutoff & Dither
            </span>
            <span className={`px-2 py-0.5 rounded-2xl text-[10px] font-mono uppercase tracking-wider ${
              telemetry.vocoderArtifactScore > 50 ? 'bg-red-950 text-red-300 border border-red-800' : 'bg-neutral-900/60 backdrop-blur-xl text-white border border-white/10'
            }`}>
              Score: {telemetry.vocoderArtifactScore}/100
            </span>
          </div>
          <p className="text-xs text-[#A1A1AA] leading-relaxed font-sans">
            Neural vocoders (e.g. HiFi-GAN, MelGAN, WaveGlow, Encodec) typically downsample or band-limit training mel-spectrograms to 16kHz or 24kHz. This creates a hard harmonic cutoff and phase dither anomalies at the upper Nyquist boundary.
          </p>
          <div className="p-2.5 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 font-mono text-[11px] text-[#A1A1AA] flex items-center justify-between uppercase">
            <span>Spectral Rolloff Ceiling:</span>
            <span className="text-white font-bold">{telemetry.spectralRollOffHz} Hz</span>
          </div>
        </div>

        {/* Pillar 3: Formant Resonances & Vocal Tract */}
        <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
              <BarChart3 className="w-3.5 h-3.5 text-white" />
              3. Formants (F1, F2, F3) & Glottal Symmetry
            </span>
            <span className="px-2 py-0.5 rounded-2xl text-[10px] font-mono bg-neutral-900/60 backdrop-blur-xl text-white border border-white/10">
              F0: {telemetry.pitchHz} Hz
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 py-1">
            <div className="p-2.5 bg-neutral-900/60 backdrop-blur-xl rounded-2xl border border-white/10 text-center">
              <span className="text-[10px] font-mono text-[#A1A1AA] block uppercase">F1 (Vowel Height)</span>
              <span className="text-xs font-mono font-bold text-white">{telemetry.formants.f1} Hz</span>
            </div>
            <div className="p-2.5 bg-neutral-900/60 backdrop-blur-xl rounded-2xl border border-white/10 text-center">
              <span className="text-[10px] font-mono text-[#A1A1AA] block uppercase">F2 (Frontness)</span>
              <span className="text-xs font-mono font-bold text-white">{telemetry.formants.f2} Hz</span>
            </div>
            <div className="p-2.5 bg-neutral-900/60 backdrop-blur-xl rounded-2xl border border-white/10 text-center">
              <span className="text-[10px] font-mono text-[#A1A1AA] block uppercase">F3 (Speaker Identity)</span>
              <span className="text-xs font-mono font-bold text-white">{telemetry.formants.f3} Hz</span>
            </div>
          </div>
          <p className="text-xs text-[#A1A1AA] leading-relaxed font-sans">
            Natural glottal jitter ranges from 0.5%–1.5%. Cloned audio often exhibits unnatural mathematical smoothness (jitter &lt; 0.2%) or sudden erratic phase dislocations.
          </p>
        </div>

        {/* Pillar 4: Room Impulse Response & Noise Floor */}
        <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-white" />
              4. Acoustic Room Impulse (RIR) Coherence
            </span>
            <span className="px-2 py-0.5 rounded-2xl text-[10px] font-mono bg-neutral-900/60 backdrop-blur-xl text-white border border-white/10">
              {telemetry.backgroundNoiseCoherence}% Coherence
            </span>
          </div>
          <p className="text-xs text-[#A1A1AA] leading-relaxed font-sans">
            Attackers often paste artificial ambient background noise (airport sounds, street traffic) over a pristine synthetic vocoder stream. V.A.L.I.D separates the noise floor and tests whether acoustic reverberation matches the caller's vocal reflections.
          </p>
          <div className="p-2.5 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 font-mono text-[11px] text-[#A1A1AA] flex items-center justify-between uppercase">
            <span>Room Reflection Phase Tracking:</span>
            <span className="text-cyan-400 font-bold">{telemetry.phaseContinuityScore}% Intact</span>
          </div>
        </div>

      </div>
    </div>
  );
};
