import React, { useState, useEffect, useRef } from 'react';
import { 
  ShieldAlert, ShieldCheck, Play, Square, PhoneOff, PhoneCall,
  Volume2, VolumeX, AlertTriangle, KeyRound, Sparkles, RefreshCw, 
  Send, Radio, CheckCircle2, ChevronRight, Lock, Bell, Terminal, Fingerprint, Activity, Zap, Mic, MicOff
} from 'lucide-react';
import { SCENARIOS } from '../data/scenarios';
import { AcousticTelemetry, CallAnalysisResult, ProceduralPassphrase, VishingScenario, ForensicReportEntry } from '../types';
import { playSimulatedVoiceAudio, stopSimulatedVoiceAudio, startMicrophoneCapture, startSimulatedMicrophoneCapture } from '../utils/audioEngine';
import { FrequencyDomainVisualizer } from './FrequencyDomainVisualizer';

interface LiveCallInterceptorProps {
  currentTelemetry: AcousticTelemetry;
  onTelemetryUpdate: (telemetry: AcousticTelemetry) => void;
  onOpenProcedural: () => void;
  onOpenBiometrics?: () => void;
  onOpenMonitoring?: () => void;
  onOpenAudioUpload?: () => void;
  isLiveMicActive?: boolean;
  onToggleMic?: () => void;
  onReportGenerated?: (report: ForensicReportEntry) => void;
}

export const LiveCallInterceptor: React.FC<LiveCallInterceptorProps> = ({
  currentTelemetry,
  onTelemetryUpdate,
  onOpenProcedural,
  onOpenBiometrics,
  onOpenMonitoring,
  onOpenAudioUpload,
  isLiveMicActive: externalMicActive,
  onToggleMic: externalToggleMic,
  onReportGenerated,
}) => {
  const [selectedScenario, setSelectedScenario] = useState<VishingScenario>(SCENARIOS[0]);
  const [callState, setCallState] = useState<'idle' | 'calling' | 'analyzing' | 'flagged' | 'mitigated'>('idle');
  const [elapsedSec, setElapsedSec] = useState<number>(0);
  const [isAudioMuted, setIsAudioMuted] = useState<boolean>(false);
  const [analysisReport, setAnalysisReport] = useState<CallAnalysisResult | null>(null);
  const [isAnalyzingAI, setIsAnalyzingAI] = useState<boolean>(false);
  const [activePassphrase, setActivePassphrase] = useState<ProceduralPassphrase | null>(null);
  const [whisperAlertSent, setWhisperAlertSent] = useState<boolean>(false);
  const [mfaPushSent, setMfaPushSent] = useState<boolean>(false);
  const [operatorNotes, setOperatorNotes] = useState<string[]>([]);
  const [transcriptProgress, setTranscriptProgress] = useState<number>(0);

  // Live FFT and Time-Domain Signal Buffers for Real-Time Canvas Visualizer
  const [liveFreqData, setLiveFreqData] = useState<Uint8Array | null>(null);
  const [liveTimeData, setLiveTimeData] = useState<Uint8Array | null>(null);

  // Internal microphone controller for Sentinel view
  const [isInternalMicActive, setIsInternalMicActive] = useState<boolean>(false);
  const localMicControllerRef = useRef<{ stop: () => void } | null>(null);
  const audioSimRef = useRef<{ stop: () => void } | null>(null);

  const isLiveMicActive = externalMicActive !== undefined ? externalMicActive : isInternalMicActive;

  const handleToggleLiveMic = async () => {
    if (externalToggleMic) {
      externalToggleMic();
      return;
    }

    if (isInternalMicActive) {
      if (localMicControllerRef.current) {
        localMicControllerRef.current.stop();
        localMicControllerRef.current = null;
      }
      setIsInternalMicActive(false);
      setCallState('idle');
      setOperatorNotes((prev) => [
        `[MIC DISCONNECTED] Active microphone stream stopped. Ingress returned to standby.`,
        ...prev,
      ]);
    } else {
      // Disconnect simulation if running
      if (audioSimRef.current) {
        audioSimRef.current.stop();
        audioSimRef.current = null;
        stopSimulatedVoiceAudio();
      }

      try {
        const controller = await startMicrophoneCapture((telemetry, freqData, timeData) => {
          onTelemetryUpdate(telemetry);
          setLiveFreqData(freqData);
          setLiveTimeData(timeData);
        }, { fftSize: 2048, smoothingTimeConstant: 0.8 });

        localMicControllerRef.current = controller;
        setIsInternalMicActive(true);
        setCallState('analyzing');
        setOperatorNotes((prev) => [
          `[MIC INGRESS ACTIVE] Real-time microphone input streaming (2048 FFT / 44.1kHz). Observing active speech waveform...`,
          ...prev,
        ]);
      } catch (err: unknown) {
        const error = err as { message?: string };
        console.warn('Physical mic access failed, switching to live speech simulation:', error);
        
        // Automatic graceful fallback to realistic simulated live stream
        const simController = startSimulatedMicrophoneCapture((telemetry, freqData, timeData) => {
          onTelemetryUpdate(telemetry);
          setLiveFreqData(freqData);
          setLiveTimeData(timeData);
        }, false, { fftSize: 2048 });

        localMicControllerRef.current = simController;
        setIsInternalMicActive(true);
        setCallState('analyzing');
        setOperatorNotes((prev) => [
          `[MIC PERMISSION RESTRICTED] Fallback to active speech simulation stream. Live DSP & spectrum models online.`,
          `[NOTE] ${error.message || 'Microphone access denied.'} To use physical mic, allow mic permissions in browser.`,
          ...prev,
        ]);
      }
    }
  };

  // Clean up audio on unmount
  useEffect(() => {
    return () => {
      if (audioSimRef.current) {
        audioSimRef.current.stop();
      }
      if (localMicControllerRef.current) {
        localMicControllerRef.current.stop();
      }
      stopSimulatedVoiceAudio();
    };
  }, []);

  // Call timer and state progression
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (callState === 'calling' || callState === 'analyzing' || callState === 'flagged') {
      interval = setInterval(() => {
        setElapsedSec((prev) => {
          const next = Math.round((prev + 0.2) * 10) / 10;

          // Transcript line progression
          if (next >= 1.5 && transcriptProgress === 0) setTranscriptProgress(1);
          if (next >= 4.0 && transcriptProgress === 1) setTranscriptProgress(2);
          if (next >= 7.5 && transcriptProgress === 2) setTranscriptProgress(3);

          // Trigger Flagged state at the 3.0-second threshold if synthetic
          if (next >= 3.0 && selectedScenario.audioClassification !== 'authentic_human' && callState === 'analyzing' && !isLiveMicActive) {
            setCallState('flagged');
            setOperatorNotes((prev) => [
              `[0:03.0s] 3-SECOND INGRESS WINDOW BREACHED: Acoustic signal flagged as ${selectedScenario.cloneEngine || 'Synthetic Neural Vocoder'}.`,
              ...prev,
            ]);
            // Auto run AI analysis
            triggerAIAnalysis();
          } else if (next >= 3.0 && selectedScenario.audioClassification === 'authentic_human' && callState === 'analyzing' && !isLiveMicActive) {
            setCallState('calling');
            setOperatorNotes((prev) => [
              `[0:03.0s] 3-SECOND INGRESS WINDOW: Acoustic signal verified authentic. Zero anomalous vocoder artifacts detected.`,
              ...prev,
            ]);
          }

          if (!isLiveMicActive && next >= selectedScenario.sampleDurationSec) {
            // Call completed
            handleEndCall('Completed audio sample stream');
          }
          return next;
        });
      }, 200);
    }
    return () => clearInterval(interval);
  }, [callState, selectedScenario, transcriptProgress, isLiveMicActive]);

  const handleStartCall = () => {
    if (isInternalMicActive && localMicControllerRef.current) {
      localMicControllerRef.current.stop();
      localMicControllerRef.current = null;
      setIsInternalMicActive(false);
    }

    // Reset call session
    setElapsedSec(0);
    setTranscriptProgress(0);
    setWhisperAlertSent(false);
    setMfaPushSent(false);
    setAnalysisReport(null);
    setActivePassphrase(null);
    setOperatorNotes([
      `[0:00.0s] Telephony Ingress connection established with ${selectedScenario.callerName}.`,
      `[0:00.5s] Initializing V.A.L.I.D real-time acoustic signal pipeline (2048 FFT / Micro-Pause Cadence Analysis)...`,
    ]);

    setCallState('analyzing');

    const isSynthetic = selectedScenario.audioClassification !== 'authentic_human';

    audioSimRef.current = playSimulatedVoiceAudio(isSynthetic, (telemetry, freqData, timeData) => {
      onTelemetryUpdate(telemetry);
      setLiveFreqData(freqData);
      setLiveTimeData(timeData);
    });
  };

  const handleEndCall = (reason?: string) => {
    if (audioSimRef.current) {
      audioSimRef.current.stop();
      audioSimRef.current = null;
    }
    if (localMicControllerRef.current) {
      localMicControllerRef.current.stop();
      localMicControllerRef.current = null;
      setIsInternalMicActive(false);
    }
    stopSimulatedVoiceAudio();
    setCallState('idle');
    if (reason) {
      setOperatorNotes((prev) => [`[${elapsedSec.toFixed(1)}s] Call Terminated: ${reason}`, ...prev]);
    }
  };

  const handleMitigateThreat = () => {
    setCallState('mitigated');
    if (audioSimRef.current) {
      audioSimRef.current.stop();
      audioSimRef.current = null;
    }
    if (localMicControllerRef.current) {
      localMicControllerRef.current.stop();
      localMicControllerRef.current = null;
      setIsInternalMicActive(false);
    }
    stopSimulatedVoiceAudio();
    setOperatorNotes((prev) => [
      `[${elapsedSec.toFixed(1)}s] KILLSWITCH ENGAGED: Ingress audio scrambled, call quarantined into encrypted evidence vault.`,
      ...prev,
    ]);
  };

  const handleSendWhisperAlert = () => {
    setWhisperAlertSent(true);
    setOperatorNotes((prev) => [
      `[${elapsedSec.toFixed(1)}s] OPERATOR WHISPER ALERT INJECTED: "Warning: Impersonation risk detected. Do not authorize wire/credentials without verbal token."`,
      ...prev,
    ]);
  };

  const handleSendMfaPush = () => {
    setMfaPushSent(true);
    setOperatorNotes((prev) => [
      `[${elapsedSec.toFixed(1)}s] OUT-OF-BAND MFA PUSH: Hardware authentication challenge transmitted to verified device.`,
      ...prev,
    ]);
  };

  const handleIssuePassphrase = async () => {
    try {
      const res = await fetch('/api/generate-passphrase', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        const passphrase: ProceduralPassphrase = {
          id: data.id,
          token: data.token,
          phoneticPhrase: data.phoneticPhrase,
          generatedAt: data.generatedAt,
          expiresInSec: data.expiresInSec,
          challengeStatus: 'issued',
          expectedLatencyWindowMs: data.expectedLatencyWindowMs,
        };
        setActivePassphrase(passphrase);
        setOperatorNotes((prev) => [
          `[${elapsedSec.toFixed(1)}s] PROCEDURAL CHALLENGE ISSUED: Caller requested to repeat "${data.phoneticPhrase}". Tracking latency window...`,
          ...prev,
        ]);

        // Simulate caller answering challenge after latency
        setTimeout(() => {
          const isSynthetic = selectedScenario.audioClassification !== 'authentic_human';
          if (isSynthetic) {
            // Clones suffer high latency (>1200ms) or fail phonetic articulation
            setActivePassphrase((p) => (p ? { ...p, challengeStatus: 'failed', measuredLatencyMs: 1480, acousticMatchPercent: 32 } : null));
            setOperatorNotes((prev) => [
              `[CHALLENGE FAILED] Generation latency exceeded threshold (1,480ms vs 650ms human baseline). Phonetic distortion on plosive consonants.`,
              ...prev,
            ]);
          } else {
            setActivePassphrase((p) => (p ? { ...p, challengeStatus: 'verified', measuredLatencyMs: 480, acousticMatchPercent: 98 } : null));
            setOperatorNotes((prev) => [
              `[CHALLENGE VERIFIED] Response latency 480ms within organic human cognitive window. Zero-knowledge verification succeeded.`,
              ...prev,
            ]);
          }
        }, 2200);
      }
    } catch (e) {
      console.error('Failed to issue passphrase', e);
    }
  };

  const triggerAIAnalysis = async () => {
    setIsAnalyzingAI(true);
    try {
      const res = await fetch('/api/analyze-call', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          callerName: selectedScenario.callerName,
          callerRole: selectedScenario.callerRole,
          targetRole: selectedScenario.targetRole,
          scenarioTitle: selectedScenario.name,
          transcript: selectedScenario.callerTranscript,
          telemetry: currentTelemetry,
          cloneScore: currentTelemetry.syntheticProbability || 94,
        }),
      });
            const data = await res.json();
      if (data.success && data.report) {
        setAnalysisReport(data.report);
        if (onReportGenerated) {
          onReportGenerated({
            id: 'FR-' + Math.random().toString(36).substring(2, 9).toUpperCase(),
            timestamp: Date.now(),
            source: 'Live Call',
            telemetrySnapshot: currentTelemetry,
            analysis: data.report
          });
        }
      }
    } catch (e) {
      console.error('AI analysis error:', e);
    } finally {
      setIsAnalyzingAI(false);
    }
  };

  const isThreat = callState === 'flagged' || currentTelemetry.syntheticProbability > 65;

  return (
    <div className="space-y-6">
      {/* Scenario Selection Header */}
      <div className="p-4 sm:p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono text-[#A1A1AA] uppercase tracking-widest">
                Adversarial Scenario
              </span>
              <span className={`px-2 py-0.5 rounded-2xl text-[10px] font-mono font-semibold uppercase tracking-wider ${
                selectedScenario.audioClassification === 'authentic_human'
                  ? 'bg-white/5 text-emerald-400 border border-emerald-800/80'
                  : 'bg-white/5 text-red-400 border border-red-800/80'
              }`}>
                {selectedScenario.audioClassification === 'authentic_human' ? 'AUTHENTIC BASELINE' : 'SYNTHETIC CLONE ATTACK'}
              </span>
            </div>
            <h2 className="text-2xl font-sans font-medium text-white tracking-tight">
              {selectedScenario.name}
            </h2>
            <p className="text-xs text-[#A1A1AA] font-sans mt-0.5">
              Target: <span className="text-white">{selectedScenario.targetRole}</span> • Caller: <span className="text-white">{selectedScenario.callerName}</span>
            </p>
          </div>

          {/* Scenario Selector Dropdown/Tabs */}
          <div className="flex flex-wrap items-center gap-2">
            {SCENARIOS.map((sc) => (
              <button
                key={sc.id}
                id={`select-scenario-${sc.id}`}
                disabled={callState === 'analyzing' || callState === 'flagged'}
                onClick={() => {
                  handleEndCall();
                  setSelectedScenario(sc);
                }}
                className={`px-3.5 py-1.5 rounded-2xl text-xs font-mono uppercase tracking-wider transition-all border ${
                  selectedScenario.id === sc.id
                    ? 'bg-white text-black border-white font-bold'
                    : 'bg-white/5 text-[#A1A1AA] hover:text-white border-white/10'
                } ${callState !== 'idle' ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {sc.name.split(' ')[0]} {sc.name.split(' ')[1] || ''}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Terminal Grid: Left Call Control & Telemetry / Right Operator HUD */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left 7 Cols: Telephony Terminal & Real-Time Waveform */}
        <div className="lg:col-span-7 space-y-4">
          {/* Active Call Window */}
          <div className={`p-6 rounded-2xl border transition-all duration-300 ${
            isThreat 
              ? 'bg-white/5/90 border-red-800 shadow-lg shadow-red-950/20'
              : 'bg-neutral-900/60 backdrop-blur-xl border-white/10'
          }`}>
            
            {/* Status Bar */}
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className={`w-2.5 h-2.5 rounded-full ${
                  callState === 'idle'
                    ? 'bg-zinc-600'
                    : callState === 'analyzing'
                    ? 'bg-amber-400 animate-ping'
                    : callState === 'flagged'
                    ? 'bg-red-500 animate-pulse'
                    : 'bg-cyan-400'
                }`} />
                <div>
                  <span className="text-xs font-mono font-semibold text-white tracking-widest uppercase">
                    {callState === 'idle' && 'TELEPHONY INGRESS IDLE'}
                    {callState === 'calling' && 'CHANNEL ACTIVE — VERIFIED HUMAN'}
                    {callState === 'analyzing' && '3.0s ACOUSTIC SCAN IN PROGRESS...'}
                    {callState === 'flagged' && 'CRITICAL: SYNTHETIC VOICE CLONE INTERCEPTED'}
                    {callState === 'mitigated' && 'CALL QUARANTINED — THREAT MITIGATED'}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-3 font-mono text-xs text-[#A1A1AA]">
                <span>TIMER: <strong className="text-white">{elapsedSec.toFixed(1)}s</strong> / {selectedScenario.sampleDurationSec}s</span>
              </div>
            </div>

            {/* 3-Second Detection Benchmark Progress */}
            <div className="mb-4">
              <div className="flex items-center justify-between text-[11px] font-mono text-[#A1A1AA] mb-1.5 uppercase">
                <span className="flex items-center gap-1.5">
                  <span>3.0s Cloning Intercept Window:</span>
                  <strong className={elapsedSec >= 3.0 ? 'text-emerald-400' : 'text-amber-300'}>
                    {Math.min(100, Math.round((elapsedSec / 3.0) * 100))}% Evaluated
                  </strong>
                </span>
                <span className="text-[10px] text-[#A1A1AA]">Threshold: 3,000ms</span>
              </div>
              <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden border border-white/10">
                <div 
                  className={`h-full transition-all duration-150 ${
                    elapsedSec >= 3.0 
                      ? (isThreat ? 'bg-red-500' : 'bg-cyan-400')
                      : 'bg-amber-400'
                  }`}
                  style={{ width: `${Math.min(100, (elapsedSec / 3.0) * 100)}%` }}
                />
              </div>
            </div>

            {/* Dynamic In-Call Warning Overlay when synthetic threat intercepted */}
            {isThreat && callState === 'flagged' && (
              <div className="mb-4 p-4 rounded-2xl bg-red-950/90 border-2 border-red-600 text-red-100 font-mono text-xs space-y-2 shadow-xl animate-pulse">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <ShieldAlert className="w-5 h-5 text-red-400 shrink-0" />
                    <div>
                      <span className="font-bold text-white uppercase tracking-wider block">
                        DYNAMIC IN-CALL WARNING OVERLAY • CRITICAL THREAT DETECTED
                      </span>
                      <span className="text-[11px] text-red-200">
                        Neural clone voice pattern identified. Do not disclose credentials or authenticate wire instructions.
                      </span>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 bg-red-600 text-white font-bold uppercase rounded-xl text-[10px] shrink-0">
                    IMMEDIATE MITIGATION
                  </span>
                </div>
              </div>
            )}

            {/* Low-Latency Inference Stream Ribbon (<200ms Budget) */}
            <div className="mb-4 px-3 py-2 bg-black rounded-2xl border border-white/10 flex flex-wrap items-center justify-between text-[11px] font-mono text-[#A1A1AA] gap-2">
              <div className="flex items-center gap-2">
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-white font-semibold uppercase">Low-Latency Stream Pipeline:</span>
                <span className="text-cyan-400 font-bold">
                  {callState === 'idle' ? '0' : Math.round(52 + Math.sin(elapsedSec * 2) * 8)} ms
                </span>
                <span className="text-[10px]">(&lt;200ms Budget)</span>
              </div>
              <div className="flex items-center gap-3 text-[10px]">
                <span>Chunk: <strong className="text-white">20ms</strong></span>
                <span>Jitter: <strong className="text-cyan-400">1.2ms</strong></span>
                <span>Buffer Health: <strong className="text-cyan-400">OPTIMAL</strong></span>
              </div>
            </div>

            {/* Real-Time Frequency-Domain Canvas Visualizer (Live Active Mic Waveform & Ingress Stream) */}
            <div className="mb-4">
              <FrequencyDomainVisualizer
                telemetry={currentTelemetry}
                frequencyData={liveFreqData}
                timeDomainData={liveTimeData}
                isThreat={isThreat}
                isLiveMicActive={isLiveMicActive}
                onToggleLiveMic={handleToggleLiveMic}
                isSimulatingCall={callState === 'calling' || callState === 'analyzing' || callState === 'flagged'}
                audioSourceLabel={isLiveMicActive ? 'Active Local Microphone' : selectedScenario.name}
              />
            </div>

            {/* Live Caller Transcript Feed */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2 mb-4">
              <div className="flex items-center justify-between text-[11px] font-mono text-[#A1A1AA] pb-1.5 border-b border-white/10">
                <span className="uppercase tracking-wider">Incoming Telephony Transcript</span>
                <span className="text-white font-mono">Speaker: {selectedScenario.callerName}</span>
              </div>

              {callState === 'idle' ? (
                <p className="text-xs font-mono text-[#A1A1AA] italic py-3 text-center">
                  Press "Initiate Ingress Call" to start real-time acoustic signal interception...
                </p>
              ) : (
                <div className="space-y-1.5">
                  {selectedScenario.callerTranscript.map((line, idx) => (
                    <div
                      key={idx}
                      className={`text-xs font-sans p-2 rounded-2xl transition-all duration-300 ${
                        idx < transcriptProgress
                          ? isThreat
                            ? 'bg-red-950/40 text-red-200 border-l-2 border-red-500'
                            : 'bg-black/60 text-white border-l-2 border-white'
                          : 'opacity-25 text-[#A1A1AA]'
                      }`}
                    >
                      <span className="font-mono text-[10px] text-[#A1A1AA] mr-2">
                        [0:0{(idx * 2.5 + 1.2).toFixed(1)}s]
                      </span>
                      {line}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Ingress Call Action Controls */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="flex items-center gap-2">
                {callState === 'idle' && !isLiveMicActive ? (
                  <button
                    id="start-call-btn"
                    onClick={handleStartCall}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-white text-black font-mono text-xs font-bold uppercase tracking-wider hover:bg-[#E4E4E7] transition-all shadow-sm"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>Initiate Ingress Call</span>
                  </button>
                ) : callState !== 'idle' && !isLiveMicActive ? (
                  <button
                    id="stop-call-btn"
                    onClick={() => handleEndCall('Operator manually disconnected')}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white/5 hover:bg-[#27272A] text-white font-mono text-xs uppercase tracking-wider transition-all border border-white/10"
                  >
                    <PhoneOff className="w-3.5 h-3.5" />
                    <span>End Call</span>
                  </button>
                ) : null}

                {/* Live Microphone Input Toggle Button */}
                <button
                  id="toggle-sentinel-mic-btn"
                  onClick={handleToggleLiveMic}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-mono text-xs uppercase tracking-wider transition-all border ${
                    isLiveMicActive
                      ? 'bg-emerald-600 hover:bg-emerald-500 text-white font-bold border-emerald-400 shadow-md shadow-emerald-950/40 animate-pulse'
                      : 'bg-white/5 hover:bg-[#27272A] text-[#A1A1AA] hover:text-white border-white/10'
                  }`}
                  title={isLiveMicActive ? 'Stop Active Microphone Analysis' : 'Stream Active Microphone Audio to FFT Spectrum Visualizer'}
                >
                  {isLiveMicActive ? <Mic className="w-3.5 h-3.5 text-white" /> : <MicOff className="w-3.5 h-3.5" />}
                  <span>{isLiveMicActive ? 'Stop Active Mic' : 'Analyze Live Mic'}</span>
                </button>

                {onOpenAudioUpload && (
                  <button
                    id="sentinel-open-audio-upload-btn"
                    onClick={onOpenAudioUpload}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-2xl font-mono text-xs uppercase tracking-wider transition-all border bg-white/5 hover:bg-[#27272A] text-[#A1A1AA] hover:text-cyan-400 border-white/10"
                    title="Upload Custom Audio File (.wav, .mp3) for Forensic FFT & Deepfake Detection"
                  >
                    <Radio className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Upload Audio</span>
                  </button>
                )}

                {callState === 'flagged' && (
                  <button
                    id="killswitch-btn"
                    onClick={handleMitigateThreat}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-mono text-xs font-bold uppercase tracking-widest transition-all shadow-md animate-pulse"
                  >
                    <ShieldAlert className="w-3.5 h-3.5" />
                    <span>Engage Killswitch</span>
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  id="whisper-alert-btn"
                  disabled={callState === 'idle'}
                  onClick={handleSendWhisperAlert}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-mono uppercase tracking-tight transition-all border ${
                    whisperAlertSent
                      ? 'bg-amber-950 text-amber-200 border-amber-600'
                      : 'bg-white/5 text-[#A1A1AA] hover:text-white border-white/10'
                  } ${callState === 'idle' ? 'opacity-40 cursor-not-allowed' : ''}`}
                >
                  <Bell className="w-3 h-3 text-amber-400" />
                  <span>{whisperAlertSent ? 'Whisper Sent' : 'Whisper Alert'}</span>
                </button>

                <button
                  id="mfa-push-btn"
                  disabled={callState === 'idle'}
                  onClick={handleSendMfaPush}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-mono uppercase tracking-tight transition-all border ${
                    mfaPushSent
                      ? 'bg-emerald-950 text-emerald-200 border-emerald-600'
                      : 'bg-white/5 text-[#A1A1AA] hover:text-white border-white/10'
                  } ${callState === 'idle' ? 'opacity-40 cursor-not-allowed' : ''}`}
                >
                  <Lock className="w-3 h-3 text-emerald-400" />
                  <span>{mfaPushSent ? 'MFA Challenged' : 'Push MFA'}</span>
                </button>

                <button
                  id="procedural-challenge-btn"
                  disabled={callState === 'idle'}
                  onClick={handleIssuePassphrase}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-mono uppercase tracking-tight bg-white/5 text-[#A1A1AA] hover:text-white border border-white/10 ${
                    callState === 'idle' ? 'opacity-40 cursor-not-allowed' : ''
                  }`}
                >
                  <KeyRound className="w-3 h-3 text-white" />
                  <span>Verbal Challenge</span>
                </button>

                {onOpenBiometrics && (
                  <button
                    id="biometric-liveness-btn"
                    onClick={onOpenBiometrics}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-mono uppercase tracking-tight bg-white text-black font-bold border border-white hover:bg-neutral-200 transition-all"
                  >
                    <Fingerprint className="w-3 h-3" />
                    <span>Liveness & Voiceprint</span>
                  </button>
                )}

                {onOpenMonitoring && (
                  <button
                    id="stream-monitoring-btn"
                    onClick={onOpenMonitoring}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-mono uppercase tracking-tight bg-white/5 text-white hover:bg-[#27272A] border border-white/10 transition-all"
                  >
                    <Activity className="w-3 h-3 text-cyan-400" />
                    <span>Stream & Alerts</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Real-Time Acoustic Telemetry Strip (4 Geometric Cards) */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
              <span className="text-[10px] font-mono text-[#A1A1AA] uppercase block mb-1">
                Synthetic Probability
              </span>
              <div className="flex items-baseline gap-1.5">
                <span className={`text-2xl font-medium tracking-tighter ${
                  currentTelemetry.syntheticProbability > 65
                    ? 'text-red-500'
                    : currentTelemetry.syntheticProbability > 30
                    ? 'text-amber-400'
                    : 'text-cyan-400'
                }`}>
                  {currentTelemetry.syntheticProbability}%
                </span>
              </div>
              <div className="w-full h-1.5 bg-[#27272A] rounded-full mt-2 overflow-hidden">
                <div 
                  className={`h-full ${
                    currentTelemetry.syntheticProbability > 65
                      ? 'bg-red-500'
                      : currentTelemetry.syntheticProbability > 30
                      ? 'bg-amber-400'
                      : 'bg-cyan-400'
                  }`}
                  style={{ width: `${currentTelemetry.syntheticProbability}%` }}
                />
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
              <span className="text-[10px] font-mono text-[#A1A1AA] uppercase mb-1 block">
                Micro-Pause Variance
              </span>
              <span className="text-2xl font-medium tracking-tighter text-white">
                {currentTelemetry.microPauseVariance}ms
              </span>
              <span className="text-[10px] font-mono text-[#A1A1AA] block mt-1 uppercase">
                {currentTelemetry.microPauseVariance < 30 ? 'Robotic <30ms' : 'Organic Jitter'}
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
              <span className="text-[10px] font-mono text-[#A1A1AA] uppercase mb-1 block">
                Vocoder Dither Score
              </span>
              <span className={`text-2xl font-medium tracking-tighter ${
                currentTelemetry.vocoderArtifactScore > 50 ? 'text-red-500' : 'text-white'
              }`}>
                {currentTelemetry.vocoderArtifactScore}/100
              </span>
              <span className="text-[10px] font-mono text-[#A1A1AA] block mt-1 uppercase">
                {currentTelemetry.vocoderArtifactScore > 50 ? 'Cutoff Flagged' : 'Coherent'}
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
              <span className="text-[10px] font-mono text-[#A1A1AA] uppercase mb-1 block">
                Pitch Jitter & F0
              </span>
              <span className="text-2xl font-medium tracking-tighter text-white">
                {currentTelemetry.pitchJitterPercent}%
              </span>
              <span className="text-[10px] font-mono text-[#A1A1AA] block mt-1 uppercase">
                F0: {currentTelemetry.pitchHz} Hz
              </span>
            </div>
          </div>

          {/* Neural Biomarker Real-time Bar */}
          {currentTelemetry.biomarkers && (
            <div className="p-3.5 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs font-mono">
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-bold text-[#A1A1AA] flex items-center gap-1">
                  <Radio className="w-3 h-3 text-white" />
                  Neural Biomarkers:
                </span>
                <span className={currentTelemetry.biomarkers.overallBiomarkerAnomalyScore > 60 ? 'text-red-400 font-bold' : 'text-cyan-400 font-bold'}>
                  {currentTelemetry.biomarkers.predictedModel}
                </span>
              </div>

              <div className="flex items-center gap-4 text-[11px] text-[#A1A1AA]">
                <span>
                  Respiration:{' '}
                  <strong className={currentTelemetry.biomarkers.breathingPattern.diaphragmaticAnomalyScore > 60 ? 'text-red-400' : 'text-white'}>
                    {currentTelemetry.biomarkers.breathingPattern.diaphragmaticAnomalyScore}%
                  </strong>
                </span>
                <span>
                  Pause Rigidity:{' '}
                  <strong className={currentTelemetry.biomarkers.microPauses.tokenQuantizationIndex > 60 ? 'text-red-400' : 'text-white'}>
                    {currentTelemetry.biomarkers.microPauses.tokenQuantizationIndex}%
                  </strong>
                </span>
                <span>
                  Phase Flip:{' '}
                  <strong className={currentTelemetry.biomarkers.phaseInconsistency.instantaneousPhaseDiscontinuity > 60 ? 'text-red-400' : 'text-white'}>
                    {currentTelemetry.biomarkers.phaseInconsistency.instantaneousPhaseDiscontinuity}%
                  </strong>
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Right 5 Cols: Multi-Layered Defense HUD & AI Forensics */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Active Passphrase Challenge Banner (if triggered) */}
          {activePassphrase && (
            <div className="p-4 rounded-2xl bg-white/5 border border-amber-700 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-amber-400 uppercase font-semibold flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5" />
                  Procedural Verbal Passphrase Issued
                </span>
                <span className={`px-2 py-0.5 rounded-2xl text-[10px] font-mono uppercase tracking-wider ${
                  activePassphrase.challengeStatus === 'verified'
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    : activePassphrase.challengeStatus === 'failed'
                    ? 'bg-red-950 text-red-300 border border-red-800'
                    : 'bg-amber-950 text-amber-300 border border-amber-800 animate-pulse'
                }`}>
                  {activePassphrase.challengeStatus.toUpperCase()}
                </span>
              </div>

              <div className="p-3 bg-black rounded-2xl border border-white/10 text-center">
                <span className="text-[10px] font-mono text-[#A1A1AA] block uppercase mb-0.5">
                  Challenge Token
                </span>
                <span className="text-base font-mono font-bold tracking-widest text-white">
                  "{activePassphrase.phoneticPhrase}"
                </span>
              </div>

              <div className="flex items-center justify-between text-[11px] font-mono text-[#A1A1AA]">
                <span>Latency Window: {activePassphrase.expectedLatencyWindowMs[0]}-{activePassphrase.expectedLatencyWindowMs[1]}ms</span>
                {activePassphrase.measuredLatencyMs && (
                  <span className={activePassphrase.measuredLatencyMs > 1000 ? 'text-red-400' : 'text-emerald-400'}>
                    Measured: {activePassphrase.measuredLatencyMs}ms
                  </span>
                )}
              </div>
            </div>
          )}

          {/* AI Forensic Reasoning & Threat Analysis Card */}
          <div className="p-5 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-white" />
                <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider">
                  Gemini Threat Forensic Analysis
                </span>
              </div>

              <button
                id="refresh-ai-btn"
                disabled={isAnalyzingAI}
                onClick={triggerAIAnalysis}
                className="p-1 rounded-2xl text-[#A1A1AA] hover:text-white transition-colors"
                title="Re-run Forensic Analysis"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isAnalyzingAI ? 'animate-spin' : ''}`} />
              </button>
            </div>

            {isAnalyzingAI ? (
              <div className="py-6 flex flex-col items-center justify-center gap-2 text-[#A1A1AA]">
                <RefreshCw className="w-5 h-5 animate-spin text-white" />
                <span className="text-xs font-mono">Synthesizing acoustic anomalies & vishing psychology...</span>
              </div>
            ) : analysisReport ? (
              <div className="space-y-3 text-xs">
                {/* Verdict Badge */}
                <div className={`p-3 rounded-2xl border flex items-center justify-between ${
                  analysisReport.threatVerdict === 'CRITICAL_DEEPFAKE_VISHING'
                    ? 'bg-red-950/60 border-red-800 text-red-200'
                    : 'bg-emerald-950/60 border-emerald-800 text-emerald-200'
                }`}>
                  <span className="font-mono font-bold tracking-wider uppercase">
                    {analysisReport.threatVerdict.replace(/_/g, ' ')}
                  </span>
                  <span className="font-mono font-bold">
                    {analysisReport.syntheticConfidence}% Confidence
                  </span>
                </div>

                {/* Deep Reasoning */}
                <p className="text-[#A1A1AA] font-sans leading-relaxed text-xs">
                  {analysisReport.deepReasoning}
                </p>

                {/* Acoustic Anomalies Checklist */}
                <div>
                  <span className="text-[10px] font-mono text-[#A1A1AA] uppercase tracking-wider block mb-1.5">
                    Key Acoustic Anomaly Flags
                  </span>
                  <div className="space-y-1.5">
                    {analysisReport.acousticAnomalies.map((anom, idx) => (
                      <div key={idx} className="p-2.5 rounded-2xl bg-white/5 border border-white/10 flex items-start gap-2">
                        <AlertTriangle className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${
                          anom.severity === 'high' ? 'text-red-400' : 'text-amber-400'
                        }`} />
                        <div>
                          <span className="font-mono text-white font-medium block">{anom.name}</span>
                          <p className="text-[#A1A1AA] text-[11px]">{anom.description}</p>
                          <span className="text-[10px] font-mono text-zinc-400 mt-0.5 block">{anom.metricValue}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Mitigation Steps */}
                <div>
                  <span className="text-[10px] font-mono text-[#A1A1AA] uppercase tracking-wider block mb-1.5">
                    Enforced Mitigation Protocol
                  </span>
                  <div className="space-y-1.5">
                    {analysisReport.mitigationProtocol.map((step, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-zinc-200 bg-white/5 p-2 rounded-2xl border border-white/10">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>Step {step.step}: {step.action}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="py-6 text-center text-[#A1A1AA] text-xs font-mono">
                Ingress call telemetry will stream here automatically once call is initiated.
              </div>
            )}
          </div>

          {/* Real-time Operator Console Audit Trail */}
          <div className="p-4 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-2">
            <div className="flex items-center gap-2 pb-2 border-b border-white/10 text-xs font-mono text-[#A1A1AA]">
              <Terminal className="w-3.5 h-3.5 text-white" />
              <span className="uppercase tracking-wider">Security Log & Audit Stream</span>
            </div>
            <div className="h-32 overflow-y-auto font-mono text-[11px] text-[#A1A1AA] space-y-1 pr-1">
              {operatorNotes.length === 0 ? (
                <div className="italic text-zinc-500">Awaiting audio session...</div>
              ) : (
                operatorNotes.map((note, idx) => (
                  <div key={idx} className="leading-tight">
                    {note.includes('CRITICAL') || note.includes('FAILED') || note.includes('BREACHED') ? (
                      <span className="text-red-400 font-semibold">{note}</span>
                    ) : note.includes('VERIFIED') || note.includes('MFA') ? (
                      <span className="text-emerald-400 font-semibold">{note}</span>
                    ) : (
                      <span>{note}</span>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
