import React, { useState } from 'react';
import { FileSearch, Clock, ShieldAlert, ShieldCheck, Download, AlertTriangle, ArrowRight, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ForensicReportEntry } from '../types';

interface ForensicReportViewProps {
  reportsHistory: ForensicReportEntry[];
  onNavigateToTab?: (tab: string) => void;
}

export const ForensicReportView: React.FC<ForensicReportViewProps> = ({
  reportsHistory,
  onNavigateToTab
}) => {
  const [selectedReportId, setSelectedReportId] = useState<string | null>(
    reportsHistory.length > 0 ? reportsHistory[0].id : null
  );

  const selectedReport = reportsHistory.find(r => r.id === selectedReportId) || null;

  return (
    <div className="flex flex-col gap-6 animate-in fade-in zoom-in-95 duration-300">
      <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2 mb-2">
            <FileSearch className="w-6 h-6 text-cyan-400" />
            <span>Forensic Analysis History</span>
          </h2>
          <p className="text-sm font-mono text-[#A1A1AA] max-w-2xl">
            Detailed breakdown of audio artifacts, acoustic anomalies, and behavioral psychology flags generated from the live microphone or uploaded audio buffers.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[600px]">
        {/* Left Column: History List */}
        <div className="lg:col-span-4 flex flex-col gap-3">
          <h3 className="font-mono text-[11px] text-[#A1A1AA] uppercase tracking-wider mb-2">Analysis Log</h3>
          
          <div className="flex flex-col gap-2 overflow-y-auto max-h-[700px] pr-2 custom-scrollbar">
            {reportsHistory.length === 0 ? (
              <div className="p-8 border border-dashed border-white/10 rounded-2xl flex flex-col items-center justify-center text-center gap-3 bg-white/5">
                <FileSearch className="w-8 h-8 text-zinc-500" />
                <span className="font-mono text-xs text-zinc-400">No reports generated yet.</span>
                <span className="text-[10px] text-zinc-500">Run an analysis in the Audio Lab to see it here.</span>
              </div>
            ) : (
              reportsHistory.map((report) => {
                const isSelected = report.id === selectedReportId;
                const isThreat = report.analysis.threatVerdict !== 'AUTHENTIC_VERIFIED_HUMAN';
                
                return (
                  <button
                    key={report.id}
                    onClick={() => setSelectedReportId(report.id)}
                    className={`text-left p-4 rounded-2xl border transition-all ${
                      isSelected 
                        ? 'bg-white/10 border-white/30 shadow-md' 
                        : 'bg-white/5 border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <span className="font-mono text-[10px] text-[#A1A1AA] flex items-center gap-1.5">
                        <Clock className="w-3 h-3" />
                        {new Date(report.timestamp).toLocaleTimeString()}
                      </span>
                      <span className="text-[9px] font-mono uppercase bg-white/10 px-1.5 py-0.5 rounded-sm">
                        {report.source}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-2 mb-1">
                      {isThreat ? (
                        <ShieldAlert className="w-4 h-4 text-red-500 flex-shrink-0" />
                      ) : (
                        <ShieldCheck className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                      )}
                      <span className="font-bold text-sm text-white truncate">
                        {report.analysis.threatVerdict.replace(/_/g, ' ')}
                      </span>
                    </div>
                    
                    <div className="flex justify-between items-end mt-3">
                      <span className={`text-xs font-mono font-bold ${isThreat ? 'text-red-400' : 'text-cyan-400'}`}>
                        {report.analysis.syntheticConfidence}% Confidence
                      </span>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Details */}
        <div className="lg:col-span-8 flex flex-col">
          <h3 className="font-mono text-[11px] text-[#A1A1AA] uppercase tracking-wider mb-4">Detailed Report</h3>
          
          {!selectedReport ? (
             <div className="flex-1 p-8 border border-white/10 rounded-2xl flex flex-col items-center justify-center text-center gap-4 bg-black">
                <FileSearch className="w-12 h-12 text-zinc-700" />
                <span className="font-mono text-sm text-zinc-500">Select a report from the log to view details.</span>
             </div>
          ) : (
            <div className="flex-1 bg-black border border-white/10 rounded-2xl overflow-hidden flex flex-col">
               <div className="p-6 border-b border-white/10 bg-white/5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <div className="font-mono text-[10px] text-[#A1A1AA] mb-1">
                      REPORT ID: {selectedReport.id}
                    </div>
                    <div className="flex items-center gap-3">
                       {selectedReport.analysis.threatVerdict === 'AUTHENTIC_VERIFIED_HUMAN' ? (
                          <ShieldCheck className="w-6 h-6 text-cyan-400" />
                       ) : (
                          <ShieldAlert className="w-6 h-6 text-red-500" />
                       )}
                       <h2 className="text-xl font-bold text-white">
                         {selectedReport.analysis.threatVerdict.replace(/_/g, ' ')}
                       </h2>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono text-[10px] text-[#A1A1AA] mb-1 uppercase">Synthetic Confidence</div>
                    <div className={`text-2xl font-mono font-bold ${
                      selectedReport.analysis.threatVerdict === 'AUTHENTIC_VERIFIED_HUMAN' ? 'text-cyan-400' : 'text-red-500'
                    }`}>
                      {selectedReport.analysis.syntheticConfidence}%
                    </div>
                  </div>
               </div>
               
               <div className="p-6 overflow-y-auto custom-scrollbar flex flex-col gap-8">
                  {/* Deep Reasoning */}
                  <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                    <h4 className="text-xs font-mono font-bold text-white uppercase mb-2">Deep Reasoning</h4>
                    <p className="text-sm text-[#A1A1AA] font-sans leading-relaxed">
                      {selectedReport.analysis.deepReasoning}
                    </p>
                  </div>

                  {/* Acoustic Anomalies */}
                  <div>
                    <h4 className="text-xs font-mono font-bold text-white uppercase mb-3 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-500" />
                      Acoustic Anomalies ({selectedReport.analysis.acousticAnomalies.length})
                    </h4>
                    <div className="flex flex-col gap-3">
                      {selectedReport.analysis.acousticAnomalies.map((anom, idx) => (
                         <div key={idx} className="p-4 bg-white/5 border border-white/10 rounded-xl flex flex-col gap-2">
                            <div className="flex justify-between items-start">
                              <span className="font-bold text-white text-sm">{anom.name}</span>
                              <span className={`text-[9px] font-mono uppercase px-2 py-0.5 rounded-sm ${
                                anom.severity === 'high' ? 'bg-red-500/20 text-red-400' : 
                                anom.severity === 'medium' ? 'bg-amber-500/20 text-amber-400' : 
                                'bg-cyan-500/20 text-cyan-400'
                              }`}>
                                {anom.severity} Severity
                              </span>
                            </div>
                            <p className="text-xs text-[#A1A1AA]">{anom.description}</p>
                            <div className="text-[10px] font-mono text-zinc-400 border-t border-white/5 pt-2 mt-1">
                              Metric: <strong className="text-zinc-200">{anom.metricValue}</strong>
                            </div>
                         </div>
                      ))}
                    </div>
                  </div>

                  {/* Linguistic Flags */}
                  <div>
                    <h4 className="text-xs font-mono font-bold text-white uppercase mb-3 flex items-center gap-2">
                      <FileSearch className="w-4 h-4 text-purple-400" />
                      Linguistic & Psychological Flags ({selectedReport.analysis.linguisticPsychologicalFlags.length})
                    </h4>
                    <div className="flex flex-col gap-3">
                      {selectedReport.analysis.linguisticPsychologicalFlags.map((flag, idx) => (
                         <div key={idx} className="p-4 bg-white/5 border border-white/10 rounded-xl flex flex-col gap-2">
                            <span className="font-bold text-white text-sm">{flag.tactic}</span>
                            <div className="pl-3 border-l-2 border-purple-500/50 text-xs text-zinc-300 italic my-1">
                              "{flag.quote}"
                            </div>
                            <p className="text-xs text-[#A1A1AA]">{flag.risk}</p>
                         </div>
                      ))}
                    </div>
                  </div>
                  
               </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
