import React from 'react';
import { ShieldCheck, ShieldAlert, Cpu, KeyRound, Radio, Lock, Zap, BookOpen, AlertTriangle } from 'lucide-react';

export const ArchitectureDocsModal: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10">
        <div className="flex items-center gap-2 mb-1">
          <BookOpen className="w-4 h-4 text-white" />
          <span className="text-xs font-mono text-[#A1A1AA] uppercase tracking-widest">
            Technical Blueprint & Security Architecture
          </span>
        </div>
        <h2 className="text-2xl font-sans font-medium text-white tracking-tight">
          V.A.L.I.D Multi-Layered Defense Architecture
        </h2>
        <p className="text-xs text-[#A1A1AA] max-w-2xl mt-1 font-sans">
          Comprehensive breakdown of acoustic digital signal processing, micro-pause cadence analysis, and procedural verbal passphrases.
        </p>
      </div>

      {/* Core Concept Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* The 3-Second Vulnerability Window */}
        <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-3">
          <div className="flex items-center gap-2 text-amber-400 font-mono text-xs font-semibold uppercase tracking-wider">
            <AlertTriangle className="w-4 h-4" />
            <span>The 3-Second Vulnerability Window</span>
          </div>
          <h3 className="text-lg font-sans font-medium text-white tracking-tight">
            Why Traditional Biometrics Fail Against Zero-Shot TTS
          </h3>
          <p className="text-xs text-[#A1A1AA] font-sans leading-relaxed">
            Modern diffusion and neural codec models (e.g. VALL-E 2, XTTS-v2, ElevenLabs) extract speaker timbre embeddings from as little as 3.0 seconds of clear audio harvested from public podcasts, earnings calls, or voicemail greetings. 
            Because voiceprints can be cloned instantaneously, passive matching of pitch or timbre alone is fundamentally insecure.
          </p>
          <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10 text-xs font-mono text-white">
            <strong className="text-amber-400 uppercase tracking-wider">Defense Directive:</strong> Telephony ingress must evaluate sub-phonemic acoustic artifacts within the initial 3,000ms window before the attacker establishes social engineering compliance.
          </div>
        </div>

        {/* Acoustic DSP Vectors */}
        <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-3">
          <div className="flex items-center gap-2 text-cyan-400 font-mono text-xs font-semibold uppercase tracking-wider">
            <Cpu className="w-4 h-4" />
            <span>Digital Signal Processing (DSP) Vectors</span>
          </div>
          <h3 className="text-lg font-sans font-medium text-white tracking-tight">
            Micro-Pauses & Vocoder Spectral Rolloff
          </h3>
          <p className="text-xs text-[#A1A1AA] font-sans leading-relaxed">
            V.A.L.I.D analyzes three distinct acoustic physics layers:
          </p>
          <ul className="text-xs text-[#A1A1AA] font-sans space-y-1.5 list-disc list-inside">
            <li><strong className="text-white">Micro-Pause Cadence:</strong> Human speech has diaphragmatic breath intervals (300-650ms variance); clones output rigid 10-25ms token gaps.</li>
            <li><strong className="text-white">Vocoder Dither:</strong> Downsampled training audio creates brickwall frequency cutoffs at 16.0 kHz with phase distortion.</li>
            <li><strong className="text-white">Room Impulse Coherence:</strong> Verifies acoustic reverberation consistency between the speaker and background noise floor.</li>
          </ul>
        </div>

        {/* Procedural Safeguards */}
        <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-3">
          <div className="flex items-center gap-2 text-white font-mono text-xs font-semibold uppercase tracking-wider">
            <KeyRound className="w-4 h-4" />
            <span>Procedural Verbal Verification</span>
          </div>
          <h3 className="text-lg font-sans font-medium text-white tracking-tight">
            Zero-Knowledge Cognitive Latency Traps
          </h3>
          <p className="text-xs text-[#A1A1AA] font-sans leading-relaxed">
            When technical suspicion triggers, the operator issues a dynamic, ephemeral phonetic passphrase (e.g. "COBALT-ORION-749"). 
            An authentic human repeats the phrase within 350–750ms. A generative AI clone requires speech-to-text transcription, LLM context synthesis, and neural audio rendering—incurring a fatal &gt;1,200ms latency penalty that immediately trips the security alarm.
          </p>
        </div>

        {/* Biometric & Liveness Verification (Anti-Spoofing) */}
        <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-3">
          <div className="flex items-center gap-2 text-white font-mono text-xs font-semibold uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            <span>Biometric Liveness & Voiceprint Matching</span>
          </div>
          <h3 className="text-lg font-sans font-medium text-white tracking-tight">
            Dynamic Anti-Spoofing & Speaker Authentication
          </h3>
          <p className="text-xs text-[#A1A1AA] font-sans leading-relaxed">
            Combines dynamic acoustic challenge-response with multi-vector speaker authentication:
          </p>
          <ul className="text-xs text-[#A1A1AA] font-sans space-y-1.5 list-disc list-inside">
            <li><strong className="text-white">Loudspeaker Replay Defense:</strong> Identifies secondary transducer frequency resonance peaks (1.8–3.2 kHz) and double Room Impulse Response (RIR) convolution decay.</li>
            <li><strong className="text-white">Air Pressure Turbulence:</strong> Measures near-mouth aerodynamic turbulence pressure on microphone capsules (absent during audio line injection).</li>
            <li><strong className="text-white">Multi-Vector Voiceprint Comparison:</strong> Computes 13-D MFCC timbre cosine similarity, vocal tract formant triad (F1, F2, F3) geometry dispersion, and F0 pitch distribution against authorized executive baselines.</li>
          </ul>
        </div>

        {/* Low-Latency Inference Architecture (<200 ms) */}
        <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-3">
          <div className="flex items-center gap-2 text-white font-mono text-xs font-semibold uppercase tracking-wider">
            <Zap className="w-4 h-4 text-cyan-400" />
            <span>Low-Latency Real-Time Inference (&lt;200 ms Budget)</span>
          </div>
          <h3 className="text-lg font-sans font-medium text-white tracking-tight">
            Stream Frame Chunking & Quantized Edge Inference
          </h3>
          <p className="text-xs text-[#A1A1AA] font-sans leading-relaxed">
            Continuous VoIP stream processing designed with an ultra-tight &lt;200ms real-time budget to intercept imposter calls without introducing call latency or jitter:
          </p>
          <ul className="text-xs text-[#A1A1AA] font-sans space-y-1.5 list-disc list-inside">
            <li><strong className="text-white">20ms Audio Frame Slicing:</strong> Processes streaming audio in 20ms chunks (50 fps) through a zero-latency circular ring buffer.</li>
            <li><strong className="text-white">Sub-100ms Total Latency:</strong> DSP feature extraction (18–24 ms) + INT8 Quantized Conformer forward pass (25–45 ms) = 48–75 ms total end-to-end latency.</li>
            <li><strong className="text-white">Lightweight Model Footprint:</strong> 3.4 MB parameter size utilizing WebAssembly SIMD and ONNX Runtime edge execution with &lt;5% CPU utilization.</li>
          </ul>
        </div>

        {/* Automated Threat Prevention & Alerting */}
        <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-3">
          <div className="flex items-center gap-2 text-white font-mono text-xs font-semibold uppercase tracking-wider">
            <ShieldAlert className="w-4 h-4 text-red-500" />
            <span>Automated Threat Prevention & Alert Dispatcher</span>
          </div>
          <h3 className="text-lg font-sans font-medium text-white tracking-tight">
            Active Session Termination & Multi-Channel Incident Alerts
          </h3>
          <p className="text-xs text-[#A1A1AA] font-sans leading-relaxed">
            Autonomous threat containment triggered instantaneously when synthetic confidence breaches policy thresholds:
          </p>
          <ul className="text-xs text-[#A1A1AA] font-sans space-y-1.5 list-disc list-inside">
            <li><strong className="text-white">Telephony SIP BYE Killswitch:</strong> Automatically injects RFC 3261 `BYE` disconnect packets and severs carrier RTP trunks upon clone confirmation.</li>
            <li><strong className="text-white">Dynamic In-Call Heads-Up Overlays:</strong> Renders 3-tier visual banners directly on the operator terminal with real-time risk status and countermeasure guidance.</li>
            <li><strong className="text-white">Automated Alert Dispatch:</strong> Sends instant SMS warnings directly to targeted employees and dispatches JSON telemetry webhooks to enterprise SIEM/SOC clusters.</li>
          </ul>
        </div>

        {/* Telephony Killswitch & Out-of-Band Auth */}
        <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-3">
          <div className="flex items-center gap-2 text-white font-mono text-xs font-semibold uppercase tracking-wider">
            <Lock className="w-4 h-4" />
            <span>Active Mitigation & Out-of-Band Auth</span>
          </div>
          <h3 className="text-lg font-sans font-medium text-white tracking-tight">
            Whisper Alerts & Dual-Control Hardware Verification
          </h3>
          <p className="text-xs text-[#A1A1AA] font-sans leading-relaxed">
            Upon confirmation of synthetic voice cloning:
          </p>
          <ul className="text-xs text-[#A1A1AA] font-sans space-y-1.5 list-disc list-inside">
            <li>In-ear whisper audio alerts the operator immediately.</li>
            <li>FIDO2 / YubiKey hardware push challenge is dispatched to the legitimate executive.</li>
            <li>Ingress audio scrambler terminates the attacker's line while logging cryptographic forensic evidence.</li>
          </ul>
        </div>

      </div>
    </div>
  );
};
