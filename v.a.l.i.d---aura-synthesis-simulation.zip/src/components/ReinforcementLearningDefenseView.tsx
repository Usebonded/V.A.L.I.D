import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Brain,
  Zap,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Play,
  Pause,
  RotateCcw,
  Sliders,
  TrendingUp,
  Cpu,
  Layers,
  Activity,
  CheckCircle2,
  XCircle,
  Radio,
  Sparkles,
  Volume2,
  VolumeX,
  Lock,
  ArrowRight,
  Database,
  Terminal
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import {
  AcousticTelemetry,
  RLActionCandidate,
  RLActionType,
  RLAgentMetrics,
  RLAgentStateVector,
  RLCatchAlert,
  RLEpisodeRecord
} from '../types';
import {
  ADVERSARIAL_SAMPLES,
  AdversarialVoiceSample,
  evaluateRLPolicy,
  extractRLStateFromTelemetry,
  getDefaultRLMetrics,
  getInitialEpisodeRecords,
  playRLCatchChime,
  RL_ACTIONS
} from '../utils/rlEngine';

interface ReinforcementLearningDefenseViewProps {
  telemetry: AcousticTelemetry;
  isLiveActive?: boolean;
  onNavigateToTab?: (tab: string) => void;
}

export const ReinforcementLearningDefenseView: React.FC<ReinforcementLearningDefenseViewProps> = ({
  telemetry,
  isLiveActive = false,
  onNavigateToTab,
}) => {
  // RL Agent Hyperparameters and Metrics
  const [metrics, setMetrics] = useState<RLAgentMetrics>(getDefaultRLMetrics());
  const [episodes, setEpisodes] = useState<RLEpisodeRecord[]>(getInitialEpisodeRecords());
  const [activeSample, setActiveSample] = useState<AdversarialVoiceSample>(ADVERSARIAL_SAMPLES[0]);
  const [isAutoTraining, setIsAutoTraining] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [temperature, setTemperature] = useState<number>(0.8);
  const [selectedCheckpoint, setSelectedCheckpoint] = useState<string>('PPO-Acoustic-Conformer-v4.8-Enterprise');

  // Active Catch Alert Notification State
  const [activeAlert, setActiveAlert] = useState<RLCatchAlert | null>({
    id: 'RL-CATCH-9842',
    timestamp: Date.now() - 5000,
    detectedCloneModel: 'ElevenLabs Multilingual v3 (Zero-Shot Clone)',
    syntheticConfidence: 96.4,
    rewardEarned: 118.5,
    actionTaken: 'TRIGGER_SIP_BYE_KILLSWITCH',
    dominantAnomalies: [
      '16kHz Vocoder Spectral Cliff (>94%)',
      'STFT Phase Discontinuity (>88%)',
      'Micro-Pause Variance Collapse (<12ms)',
    ],
    latencyMs: 142,
    audioSampleContext: 'Ingress Telephony Stream / Session #AURA-9822',
    quarantineHash: 'SHA256: 7f8a91c8430b62e49c836d5012a9d84e',
  });

  const [lastRewardDelta, setLastRewardDelta] = useState<number>(118.5);

  // Dynamic RL State derived from either the active adversarial sample or live telemetry
  const currentState: RLAgentStateVector = useMemo(() => {
    if (isLiveActive) {
      return extractRLStateFromTelemetry(telemetry);
    }
    return {
      vocoderRollOffAnomaly: activeSample.vocoderRollOffAnomaly,
      phaseContinuityDisruption: activeSample.phaseContinuityDisruption,
      microPauseRigidity: activeSample.microPauseRigidity,
      pitchJitterPerturbation: activeSample.pitchJitterPerturbation,
      bispectrumDecoupling: activeSample.bispectrumDecoupling,
      temporalFrameJitter: activeSample.temporalFrameJitter,
      ambientRirCoherence: activeSample.ambientRirCoherence,
      voiceprintDeviation: activeSample.voiceprintDeviation,
    };
  }, [isLiveActive, telemetry, activeSample]);

  // Evaluated Policy Actions and Q-values
  const policyEvaluation = useMemo(() => {
    return evaluateRLPolicy(currentState, temperature);
  }, [currentState, temperature]);

  // Canvas Ref for Reward Curve & Loss Convergence Graph
  const chartCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Step the RL Environment with given sample or active state
  const stepEnvironment = (sample: AdversarialVoiceSample) => {
    const sampleState: RLAgentStateVector = {
      vocoderRollOffAnomaly: sample.vocoderRollOffAnomaly,
      phaseContinuityDisruption: sample.phaseContinuityDisruption,
      microPauseRigidity: sample.microPauseRigidity,
      pitchJitterPerturbation: sample.pitchJitterPerturbation,
      bispectrumDecoupling: sample.bispectrumDecoupling,
      temporalFrameJitter: sample.temporalFrameJitter,
      ambientRirCoherence: sample.ambientRirCoherence,
      voiceprintDeviation: sample.voiceprintDeviation,
    };

    const evalResult = evaluateRLPolicy(sampleState, temperature);
    const chosenAction = evalResult.bestAction;
    const isSynthetic = sample.category === 'SYNTHETIC_VOICE_CLONE' || sample.category === 'ADVERSARIAL_DIFFUSION';

    let reward = 0;
    let wasCorrect = false;
    let threatCaught = false;

    if (isSynthetic) {
      if (chosenAction === 'TRIGGER_SIP_BYE_KILLSWITCH' || chosenAction === 'RAISE_SOC_THREAT_ALERT') {
        reward = 100 + Math.random() * 25 - (evalResult.syntheticScore > 90 ? 0 : 10);
        wasCorrect = true;
        threatCaught = true;
      } else if (chosenAction === 'PROMPT_COGNITIVE_CHALLENGE' || chosenAction === 'ENHANCE_SAMPLING') {
        reward = 35 + Math.random() * 15;
        wasCorrect = true;
        threatCaught = true;
      } else {
        // Passed a synthetic clone!
        reward = -220;
        wasCorrect = false;
      }
    } else {
      // Authentic Human or Degraded PSTN
      if (chosenAction === 'PASS_CLEAN' || chosenAction === 'ENHANCE_SAMPLING') {
        reward = 60 + Math.random() * 15;
        wasCorrect = true;
      } else {
        // False Alarm!
        reward = -180;
        wasCorrect = false;
      }
    }

    reward = parseFloat(reward.toFixed(1));
    const latency = Math.floor(110 + Math.random() * 85);
    const loss = parseFloat((0.003 + Math.random() * 0.0035).toFixed(4));
    const newEpisodeNum = metrics.currentEpisode + 1;

    const newRecord: RLEpisodeRecord = {
      episode: newEpisodeNum,
      timestamp: Date.now(),
      sampleType: sample.category,
      sampleName: sample.name,
      actionsTaken: chosenAction === 'PASS_CLEAN' ? ['PASS_CLEAN'] : ['ENHANCE_SAMPLING', chosenAction],
      finalReward: reward,
      loss,
      epsilon: Math.max(0.01, metrics.explorationRateEpsilon * 0.998),
      detectionLatencyMs: latency,
      wasCorrect,
      threatCaught,
    };

    setLastRewardDelta(reward);

    // Update Metrics
    setMetrics((prev) => {
      const newTotalCaught = threatCaught ? prev.totalCaughtClones + 1 : prev.totalCaughtClones;
      const newFalsePositives = !isSynthetic && !wasCorrect ? prev.totalFalsePositives + 1 : prev.totalFalsePositives;
      const totalSteps = prev.currentEpisode + 1;
      const newAccuracy = parseFloat((((newTotalCaught + (totalSteps - newFalsePositives)) / (totalSteps * 2)) * 100).toFixed(2));
      return {
        ...prev,
        currentEpisode: newEpisodeNum,
        totalCaughtClones: newTotalCaught,
        totalFalsePositives: newFalsePositives,
        cumulativeReward: Math.round(prev.cumulativeReward + reward),
        averageRewardRecent: parseFloat(((prev.averageRewardRecent * 0.9) + (reward * 0.1)).toFixed(1)),
        policyAccuracy: Math.min(99.9, Math.max(90, newAccuracy)),
        meanCatchLatencyMs: Math.round(prev.meanCatchLatencyMs * 0.85 + latency * 0.15),
        explorationRateEpsilon: parseFloat(newRecord.epsilon.toFixed(3)),
      };
    });

    setEpisodes((prev) => [newRecord, ...prev.slice(0, 19)]);

    // Trigger Catch Alert if Threat Caught
    if (threatCaught) {
      const dominantAnomalies: string[] = [];
      if (sample.vocoderRollOffAnomaly > 0.6) dominantAnomalies.push(`16kHz Spectral Roll-Off (${(sample.vocoderRollOffAnomaly * 100).toFixed(0)}%)`);
      if (sample.phaseContinuityDisruption > 0.6) dominantAnomalies.push(`STFT Phase Discontinuity (${(sample.phaseContinuityDisruption * 100).toFixed(0)}%)`);
      if (sample.microPauseRigidity > 0.6) dominantAnomalies.push(`Micro-Pause Variance Collapse (${(sample.microPauseRigidity * 100).toFixed(0)}%)`);
      if (sample.bispectrumDecoupling > 0.6) dominantAnomalies.push(`Bispectrum Glottal Decoupling (${(sample.bispectrumDecoupling * 100).toFixed(0)}%)`);

      const catchAlert: RLCatchAlert = {
        id: `RL-CATCH-${Math.floor(1000 + Math.random() * 9000)}`,
        timestamp: Date.now(),
        detectedCloneModel: sample.name,
        syntheticConfidence: parseFloat(evalResult.syntheticScore.toFixed(1)),
        rewardEarned: reward,
        actionTaken: chosenAction,
        dominantAnomalies: dominantAnomalies.length > 0 ? dominantAnomalies : ['Latent Vocoder Phase Slip', 'Cepstral Oversmoothing'],
        latencyMs: latency,
        audioSampleContext: `Evaluated in Episode #${newEpisodeNum} (${sample.architecture})`,
        quarantineHash: `SHA256: ${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}`,
      };

      setActiveAlert(catchAlert);
      if (soundEnabled) {
        playRLCatchChime();
      }
    }
  };

  // Continuous Auto-Training Loop
  useEffect(() => {
    if (!isAutoTraining) return;

    const interval = setInterval(() => {
      // Pick random adversarial sample with weighted distribution towards zero-day clones
      const randomIdx = Math.floor(Math.random() * ADVERSARIAL_SAMPLES.length);
      const sample = ADVERSARIAL_SAMPLES[randomIdx];
      setActiveSample(sample);
      stepEnvironment(sample);
    }, 1400);

    return () => clearInterval(interval);
  }, [isAutoTraining, metrics.currentEpisode, soundEnabled, temperature]);

  // Render Live Reward Trajectory Canvas
  useEffect(() => {
    const canvas = chartCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const width = (canvas.width = (canvas.parentElement?.clientWidth || 480) * dpr);
    const height = (canvas.height = 140 * dpr);

    ctx.scale(dpr, dpr);
    const displayWidth = width / dpr;
    const displayHeight = height / dpr;

    // Background
    ctx.fillStyle = '#050505';
    ctx.fillRect(0, 0, displayWidth, displayHeight);

    // Subtle Grid
    ctx.strokeStyle = '#18181B';
    ctx.lineWidth = 1;
    for (let x = 30; x < displayWidth; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, displayHeight);
      ctx.stroke();
    }
    for (let y = 20; y < displayHeight; y += 25) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(displayWidth, y);
      ctx.stroke();
    }

    // Zero-reward baseline
    const zeroY = displayHeight * 0.72;
    ctx.strokeStyle = '#27272A';
    ctx.setLineDash([2, 2]);
    ctx.beginPath();
    ctx.moveTo(0, zeroY);
    ctx.lineTo(displayWidth, zeroY);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.fillStyle = '#52525B';
    ctx.font = '8px monospace';
    ctx.fillText('0 REWARD', 4, zeroY - 3);
    ctx.fillText('+120', 4, 14);
    ctx.fillText('-200', 4, displayHeight - 4);

    // Plot recent episode rewards
    if (episodes.length > 1) {
      const reversed = [...episodes].reverse();
      const stepX = displayWidth / Math.max(1, reversed.length - 1);

      // Reward Area Gradient
      const grad = ctx.createLinearGradient(0, 0, 0, displayHeight);
      grad.addColorStop(0, 'rgba(0, 255, 65, 0.25)');
      grad.addColorStop(0.7, 'rgba(0, 255, 65, 0.02)');
      grad.addColorStop(1, 'rgba(239, 68, 68, 0.15)');

      ctx.beginPath();
      reversed.forEach((rec, idx) => {
        const x = idx * stepX;
        // Normalize reward: +120 -> top (10), -200 -> bottom (displayHeight - 10)
        const normY = zeroY - (rec.finalReward / 150) * (zeroY - 14);
        const y = Math.max(8, Math.min(displayHeight - 8, normY));
        if (idx === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });

      ctx.strokeStyle = '#00FF41';
      ctx.lineWidth = 2;
      ctx.shadowColor = 'rgba(0, 255, 65, 0.4)';
      ctx.shadowBlur = 4;
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Draw points
      reversed.forEach((rec, idx) => {
        const x = idx * stepX;
        const normY = zeroY - (rec.finalReward / 150) * (zeroY - 14);
        const y = Math.max(8, Math.min(displayHeight - 8, normY));

        ctx.fillStyle = rec.wasCorrect ? '#00FF41' : '#EF4444';
        ctx.beginPath();
        ctx.arc(x, y, 3, 0, Math.PI * 2);
        ctx.fill();
      });
    }
  }, [episodes]);

  return (
    <div id="reinforcement-learning-defense-view" className="flex flex-col gap-6 font-sans">
      {/* ----------------------------------------------------------------------------------------- */}
      {/* RL Section Header */}
      {/* ----------------------------------------------------------------------------------------- */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 bg-neutral-950 border border-white/10 rounded-2xl">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-white/5 border border-white/10 rounded-2xl text-cyan-400">
            <Brain className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="text-xl font-bold text-white tracking-tight">
                Reinforcement Learning Acoustic Defense (RLAF)
              </h2>
              <span className="px-2 py-0.5 rounded-2xl bg-emerald-950/80 border border-emerald-800 text-emerald-400 text-[10px] font-mono font-bold uppercase">
                Active Policy: PPO-Conformer
              </span>
            </div>
            <p className="text-sm text-[#A1A1AA] mt-1">
              Autonomous deep reinforcement learning agent trained via Proximal Policy Optimization to detect zero-day voice clones in sub-200ms windows.
            </p>
          </div>
        </div>

        {/* Global Toolbar Controls */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Sound alert chime toggle */}
          <button
            id="rl-toggle-sound-btn"
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`flex items-center gap-2 px-3 py-2 rounded-2xl border text-xs font-mono uppercase transition-colors ${
              soundEnabled
                ? 'bg-white/5 text-cyan-400 border-cyan-400/40'
                : 'bg-black text-[#71717A] border-white/10'
            }`}
            title="Toggle cybernetic acoustic alert chime on clone catches"
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            <span>{soundEnabled ? 'Chime ON' : 'Chime Muted'}</span>
          </button>

          {/* Continuous Training Simulator */}
          <button
            id="rl-auto-train-btn"
            onClick={() => setIsAutoTraining(!isAutoTraining)}
            className={`flex items-center gap-2 px-4 py-2 rounded-2xl font-mono text-xs uppercase font-bold tracking-wider transition-all border ${
              isAutoTraining
                ? 'bg-amber-600 hover:bg-amber-500 text-black border-amber-400 animate-pulse'
                : 'bg-[#FFFFFF] hover:bg-[#E4E4E7] text-black border-white'
            }`}
          >
            {isAutoTraining ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
            <span>{isAutoTraining ? 'Pause Training' : 'Run Online Training'}</span>
          </button>
        </div>
      </div>

      {/* ----------------------------------------------------------------------------------------- */}
      {/* HIGH PRIORITY CATCH ALERT NOTIFICATION MODAL / STRIP */}
      {/* ----------------------------------------------------------------------------------------- */}
      <AnimatePresence>
        {activeAlert && (
          <motion.div
            initial={{ opacity: 0, y: -12, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -12, scale: 0.98 }}
            className="p-5 rounded-2xl bg-gradient-to-r from-red-950/90 via-black to-red-950/90 border-2 border-red-600 shadow-2xl shadow-red-950/50 flex flex-col gap-4 relative overflow-hidden"
          >
            {/* Top Scanning Line */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-red-500 animate-pulse" />

            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div className="p-2.5 rounded-2xl bg-red-900/60 border border-red-500 text-red-300 mt-0.5">
                  <ShieldAlert className="w-6 h-6 animate-bounce" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-xs font-bold uppercase tracking-widest text-red-400 bg-red-950 px-2 py-0.5 rounded-2xl border border-red-800">
                      THREAT CAUGHT BY RL POLICY • {activeAlert.id}
                    </span>
                    <span className="font-mono text-xs text-zinc-400">
                      Latency: <strong className="text-white">{activeAlert.latencyMs}ms</strong>
                    </span>
                    <span className="font-mono text-xs text-zinc-400">
                      Reward: <strong className="text-cyan-400">+{activeAlert.rewardEarned} pts</strong>
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white mt-1">
                    AI-Generated Voice Impersonator Caught: <span className="text-red-300">{activeAlert.detectedCloneModel}</span>
                  </h3>
                  <p className="text-xs text-zinc-300 mt-0.5 font-mono">
                    {activeAlert.audioSampleContext} • Action Executed: <span className="text-white font-bold">{activeAlert.actionTaken}</span>
                  </p>
                </div>
              </div>

              {/* Action Controls */}
              <div className="flex items-center gap-2">
                <button
                  id="rl-dismiss-alert-btn"
                  onClick={() => setActiveAlert(null)}
                  className="px-3 py-1.5 rounded-2xl bg-black/60 hover:bg-black border border-red-800 hover:border-red-600 text-zinc-300 hover:text-white font-mono text-xs uppercase transition-colors"
                >
                  Dismiss Banner
                </button>
                {onNavigateToTab && (
                  <button
                    id="rl-view-sentinel-btn"
                    onClick={() => onNavigateToTab('sentinel')}
                    className="flex items-center gap-1.5 px-4 py-1.5 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-mono text-xs font-bold uppercase tracking-wider transition-colors shadow-md"
                  >
                    <span>View Call Stream</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* Forensic Attribution Details */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 border-t border-red-900/60 font-mono text-xs">
              <div className="p-2.5 rounded-2xl bg-black/70 border border-red-900/50">
                <span className="text-[#71717A] uppercase text-[10px] block mb-1">Dominant Anomaly Vectors:</span>
                <ul className="list-disc list-inside space-y-0.5 text-zinc-200">
                  {activeAlert.dominantAnomalies.map((anom, idx) => (
                    <li key={idx} className="text-[11px] text-red-300">{anom}</li>
                  ))}
                </ul>
              </div>

              <div className="p-2.5 rounded-2xl bg-black/70 border border-red-900/50 flex flex-col justify-between">
                <div>
                  <span className="text-[#71717A] uppercase text-[10px] block mb-1">Autonomous Intervention:</span>
                  <div className="flex items-center gap-1.5 text-white font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                    <span>SIP BYE Ingress Scrambled</span>
                  </div>
                  <div className="text-[10px] text-zinc-400 mt-1">Evidence locked to SOC Incident Queue</div>
                </div>
              </div>

              <div className="p-2.5 rounded-2xl bg-black/70 border border-red-900/50 flex flex-col justify-between">
                <div>
                  <span className="text-[#71717A] uppercase text-[10px] block mb-1">Cryptographic Evidence Vault:</span>
                  <div className="text-[10px] text-zinc-300 truncate">{activeAlert.quarantineHash}</div>
                </div>
                <div className="flex items-center gap-1 text-[10px] text-cyan-400">
                  <Lock className="w-3 h-3" />
                  <span>256-Bit TLS Mutual Auth Encrypted</span>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ----------------------------------------------------------------------------------------- */}
      {/* Top 4 KPI Metrics Cards */}
      {/* ----------------------------------------------------------------------------------------- */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-neutral-900/60 backdrop-blur-xl border border-white/10 rounded-2xl flex flex-col justify-between">
          <div className="flex items-center justify-between font-mono text-xs text-[#A1A1AA] uppercase">
            <span>Caught AI Clones</span>
            <ShieldAlert className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-3xl font-bold text-white mt-2 font-mono">
            {metrics.totalCaughtClones}
          </div>
          <div className="text-[10px] font-mono text-[#71717A] mt-1 flex items-center gap-1">
            <span className="text-cyan-400">+{lastRewardDelta > 0 ? lastRewardDelta : 0}</span> reward points last episode
          </div>
        </div>

        <div className="p-4 bg-neutral-900/60 backdrop-blur-xl border border-white/10 rounded-2xl flex flex-col justify-between">
          <div className="flex items-center justify-between font-mono text-xs text-[#A1A1AA] uppercase">
            <span>Policy Accuracy</span>
            <Activity className="w-4 h-4 text-white" />
          </div>
          <div className="text-3xl font-bold text-white mt-2 font-mono">
            {metrics.policyAccuracy}%
          </div>
          <div className="text-[10px] font-mono text-[#71717A] mt-1">
            False Positive Rate: <span className="text-white font-bold">{((metrics.totalFalsePositives / Math.max(1, metrics.currentEpisode)) * 100).toFixed(2)}%</span>
          </div>
        </div>

        <div className="p-4 bg-neutral-900/60 backdrop-blur-xl border border-white/10 rounded-2xl flex flex-col justify-between">
          <div className="flex items-center justify-between font-mono text-xs text-[#A1A1AA] uppercase">
            <span>Mean Catch Latency</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-3xl font-bold text-white mt-2 font-mono">
            {metrics.meanCatchLatencyMs} ms
          </div>
          <div className="text-[10px] font-mono text-[#71717A] mt-1">
            Ceiling Budget: <span className="text-zinc-300 font-bold">&lt; 200 ms</span>
          </div>
        </div>

        <div className="p-4 bg-neutral-900/60 backdrop-blur-xl border border-white/10 rounded-2xl flex flex-col justify-between">
          <div className="flex items-center justify-between font-mono text-xs text-[#A1A1AA] uppercase">
            <span>Exploration Rate (ε)</span>
            <TrendingUp className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-3xl font-bold text-white mt-2 font-mono">
            {metrics.explorationRateEpsilon}
          </div>
          <div className="text-[10px] font-mono text-[#71717A] mt-1">
            Reward Moving Avg: <span className="text-cyan-400 font-bold">+{metrics.averageRewardRecent}</span>
          </div>
        </div>
      </div>

      {/* ----------------------------------------------------------------------------------------- */}
      {/* Main Grid: Policy Network Decisions & State Space Vector */}
      {/* ----------------------------------------------------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): Deep Q-Network Policy Action Space */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          {/* Action Q-Value Distribution Card */}
          <div className="p-5 bg-neutral-900/60 backdrop-blur-xl border border-white/10 rounded-2xl flex flex-col gap-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Brain className="w-4 h-4 text-cyan-400" />
                <h3 className="font-mono text-xs font-bold uppercase tracking-wider text-white">
                  Actor-Critic Policy Action Space ($Q(s, a)$ & $\pi(a|s)$)
                </h3>
              </div>
              <span className="font-mono text-[10px] text-[#A1A1AA]">
                Selected Action: <strong className="text-white">{policyEvaluation.bestAction}</strong>
              </span>
            </div>

            <div className="space-y-3">
              {policyEvaluation.candidates.map((cand) => (
                <div
                  key={cand.action}
                  className={`p-3 rounded-2xl border transition-all ${
                    cand.isChosen
                      ? 'bg-white/5 border-cyan-400 shadow-md shadow-emerald-950/20'
                      : 'bg-black/60 border-white/10 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center justify-between font-mono text-xs">
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${cand.isChosen ? 'bg-cyan-400 animate-ping' : 'bg-zinc-700'}`} />
                      <span className={`font-bold ${cand.isChosen ? 'text-white' : 'text-[#A1A1AA]'}`}>
                        {cand.label}
                      </span>
                      {cand.isChosen && (
                        <span className="px-1.5 py-0.2 rounded-xl bg-cyan-400 text-black font-bold text-[9px] uppercase">
                          OPTIMAL POLICY
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-[11px] text-[#71717A]">
                        Q-Val: <strong className={cand.qValue > 0 ? 'text-cyan-400' : 'text-red-400'}>{cand.qValue > 0 ? `+${cand.qValue}` : cand.qValue}</strong>
                      </span>
                      <span className="text-[11px] font-bold text-white min-w-[44px] text-right">
                        {cand.probability}%
                      </span>
                    </div>
                  </div>

                  {/* Softmax Probability Bar */}
                  <div className="h-1.5 bg-black rounded-full overflow-hidden mt-2 border border-white/10">
                    <div
                      className={`h-full transition-all duration-300 ${
                        cand.isChosen
                          ? cand.action.includes('ALERT') || cand.action.includes('KILLSWITCH')
                            ? 'bg-red-500'
                            : 'bg-cyan-400'
                          : 'bg-zinc-600'
                      }`}
                      style={{ width: `${cand.probability}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Policy Parameters Footer */}
            <div className="pt-2 border-t border-white/10 flex flex-wrap items-center justify-between text-[11px] font-mono text-[#A1A1AA] gap-2">
              <div>
                <span>Reward Formula: </span>
                <span className="text-zinc-300">R = +100·TP - 200·FP - 1.5·Latency</span>
              </div>
              <div>
                <span>Softmax Temp (τ): </span>
                <span className="text-white font-bold">{temperature}</span>
              </div>
            </div>
          </div>

          {/* Reward Curve & Loss Convergence Graph */}
          <div className="p-5 bg-neutral-900/60 backdrop-blur-xl border border-white/10 rounded-2xl flex flex-col gap-3">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-cyan-400" />
                <h3 className="font-mono text-xs font-bold uppercase tracking-wider text-white">
                  Episodic Reward Trajectory & Policy Convergence
                </h3>
              </div>
              <span className="font-mono text-[10px] text-[#A1A1AA]">
                Episode #{metrics.currentEpisode}
              </span>
            </div>

            <div className="relative w-full h-[140px] bg-black rounded-2xl border border-white/10 overflow-hidden">
              <canvas ref={chartCanvasRef} className="w-full h-full block" />
            </div>

            <div className="flex items-center justify-between text-[11px] font-mono text-[#A1A1AA]">
              <span>Green: True Positive Clones (+100 to +125 pts)</span>
              <span>Red: False Alarms (-180 to -220 pts)</span>
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): 8-D RL State Vector Observation & Adversarial Selector */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          {/* Adversarial Voice Clone Attack Selector */}
          <div className="p-5 bg-neutral-900/60 backdrop-blur-xl border border-white/10 rounded-2xl flex flex-col gap-3">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Radio className="w-4 h-4 text-amber-400" />
                <h3 className="font-mono text-xs font-bold uppercase tracking-wider text-white">
                  Adversarial Voice Generator Sandbox
                </h3>
              </div>
              <span className="font-mono text-[10px] text-[#A1A1AA]">
                {ADVERSARIAL_SAMPLES.length} Voice Models
              </span>
            </div>

            <div className="space-y-1.5 max-h-[220px] overflow-y-auto pr-1">
              {ADVERSARIAL_SAMPLES.map((sample) => {
                const isSelected = activeSample.id === sample.id;
                const isSynthetic = sample.category === 'SYNTHETIC_VOICE_CLONE' || sample.category === 'ADVERSARIAL_DIFFUSION';

                return (
                  <button
                    key={sample.id}
                    id={`adv-sample-btn-${sample.id}`}
                    onClick={() => {
                      setActiveSample(sample);
                      stepEnvironment(sample);
                    }}
                    className={`w-full text-left p-2.5 rounded-2xl border text-xs font-mono transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-white/5 border-white text-white font-bold'
                        : 'bg-black/50 border-white/10 text-[#A1A1AA] hover:text-white hover:border-zinc-700'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${isSynthetic ? 'bg-red-500' : 'bg-cyan-400'}`} />
                      <span className="truncate">{sample.name}</span>
                    </div>

                    <span className={`text-[9px] uppercase px-1.5 py-0.5 rounded-xl shrink-0 ${
                      isSynthetic ? 'bg-red-950 text-red-300 border border-red-800' : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    }`}>
                      {isSynthetic ? 'AI Clone' : 'Human'}
                    </span>
                  </button>
                );
              })}
            </div>

            <button
              id="rl-step-eval-btn"
              onClick={() => stepEnvironment(activeSample)}
              className="w-full mt-2 py-2.5 bg-white text-black font-mono font-bold text-xs uppercase tracking-wider rounded-2xl hover:bg-[#E4E4E7] transition-all flex items-center justify-center gap-2 shadow-sm"
            >
              <Zap className="w-3.5 h-3.5 fill-current" />
              <span>Feed Audio & Evaluate Policy Step</span>
            </button>
          </div>

          {/* 8-D RL State Vector Visualizer */}
          <div className="p-5 bg-neutral-900/60 backdrop-blur-xl border border-white/10 rounded-2xl flex flex-col gap-3">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                <h3 className="font-mono text-xs font-bold uppercase tracking-wider text-white">
                  8-Dimensional RL State Vector ($s \in [0, 1]^8$)
                </h3>
              </div>
              <span className="font-mono text-[10px] text-[#A1A1AA]">
                {isLiveActive ? 'Live Ingress' : activeSample.name}
              </span>
            </div>

            <div className="space-y-2.5 font-mono text-xs">
              {[
                { label: 's1: Vocoder Roll-Off Anomaly (>16kHz)', val: currentState.vocoderRollOffAnomaly },
                { label: 's2: Phase Continuity Disruption', val: currentState.phaseContinuityDisruption },
                { label: 's3: Micro-Pause Variance Collapse', val: currentState.microPauseRigidity },
                { label: 's4: Pitch Jitter / Shimmer Perturbation', val: currentState.pitchJitterPerturbation },
                { label: 's5: Bispectrum Glottal Decoupling', val: currentState.bispectrumDecoupling },
                { label: 's6: Temporal Frame Jitter Latency', val: currentState.temporalFrameJitter },
                { label: 's7: Ambient RIR Room Incoherence', val: currentState.ambientRirCoherence },
                { label: 's8: Biometric Voiceprint Deviation', val: currentState.voiceprintDeviation },
              ].map((item, idx) => (
                <div key={idx} className="flex flex-col gap-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#A1A1AA]">{item.label}</span>
                    <span className={`font-bold ${item.val > 0.6 ? 'text-red-400' : 'text-zinc-300'}`}>
                      {(item.val * 100).toFixed(1)}%
                    </span>
                  </div>
                  <div className="h-1.5 bg-black rounded-full overflow-hidden border border-white/10">
                    <div
                      className={`h-full transition-all duration-200 ${
                        item.val > 0.7 ? 'bg-red-500' : item.val > 0.4 ? 'bg-amber-400' : 'bg-cyan-400'
                      }`}
                      style={{ width: `${item.val * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ----------------------------------------------------------------------------------------- */}
      {/* Recent Training Episode Logs Table */}
      {/* ----------------------------------------------------------------------------------------- */}
      <div className="p-5 bg-neutral-900/60 backdrop-blur-xl border border-white/10 rounded-2xl flex flex-col gap-3">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-cyan-400" />
            <h3 className="font-mono text-xs font-bold uppercase tracking-wider text-white">
              Recent RL Training Episode Logs & Autonomous Interventions
            </h3>
          </div>
          <span className="font-mono text-[10px] text-[#A1A1AA]">
            Showing Last {episodes.length} Episodes
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-white/10 text-[#71717A] text-[10px] uppercase">
                <th className="py-2 px-3">Episode</th>
                <th className="py-2 px-3">Sample Name / Generator</th>
                <th className="py-2 px-3">Category</th>
                <th className="py-2 px-3">Action Executed</th>
                <th className="py-2 px-3">Latency</th>
                <th className="py-2 px-3">Reward</th>
                <th className="py-2 px-3">Decision</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#18181B]">
              {episodes.map((ep) => (
                <tr key={ep.episode} className="hover:bg-white/5/50 transition-colors">
                  <td className="py-2.5 px-3 text-white font-bold">#{ep.episode}</td>
                  <td className="py-2.5 px-3 text-zinc-300 max-w-[220px] truncate">{ep.sampleName}</td>
                  <td className="py-2.5 px-3">
                    <span className={`text-[9px] uppercase px-2 py-0.5 rounded-xl ${
                      ep.sampleType.includes('SYNTHETIC') || ep.sampleType.includes('DIFFUSION')
                        ? 'bg-red-950 text-red-300 border border-red-800'
                        : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    }`}>
                      {ep.sampleType.replace(/_/g, ' ')}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-zinc-300">
                    <span className="font-bold text-white">
                      {ep.actionsTaken[ep.actionsTaken.length - 1]}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-zinc-400">{ep.detectionLatencyMs} ms</td>
                  <td className="py-2.5 px-3">
                    <span className={`font-bold ${ep.finalReward > 0 ? 'text-cyan-400' : 'text-red-400'}`}>
                      {ep.finalReward > 0 ? `+${ep.finalReward}` : ep.finalReward}
                    </span>
                  </td>
                  <td className="py-2.5 px-3">
                    {ep.wasCorrect ? (
                      <span className="flex items-center gap-1 text-cyan-400 font-bold text-[10px]">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>CORRECT</span>
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-red-400 font-bold text-[10px]">
                        <XCircle className="w-3.5 h-3.5" />
                        <span>FALSE ALARM</span>
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
