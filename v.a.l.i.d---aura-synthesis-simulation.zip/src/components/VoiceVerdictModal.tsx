/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  CheckCircle2,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  X,
  ArrowRight,
  Activity,
  Zap,
  Sparkles,
  Radio,
  FileAudio,
  Volume2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AcousticTelemetry } from '../types';

interface VoiceVerdictModalProps {
  isOpen: boolean;
  onClose: () => void;
  telemetry: AcousticTelemetry;
  onNavigateToTab?: (tab: string) => void;
  onTestAuthentic?: () => void;
  onTestFake?: () => void;
}

export const VoiceVerdictModal: React.FC<VoiceVerdictModalProps> = ({
  isOpen,
  onClose,
  telemetry,
  onNavigateToTab,
  onTestAuthentic,
  onTestFake,
}) => {
  if (!isOpen) return null;

  const isFake = telemetry.syntheticProbability > 50;
  const confidenceScore = isFake
    ? telemetry.syntheticProbability
    : 100 - telemetry.syntheticProbability;

  return (
    <div
      id="voice-verdict-popup-backdrop"
      className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.92, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.92, y: 15 }}
        transition={{ duration: 0.22, ease: 'easeOut' }}
        className={`w-full max-w-xl bg-neutral-900/60 backdrop-blur-xl border-2 rounded-2xl shadow-2xl overflow-hidden relative font-sans ${
          isFake ? 'border-red-600' : 'border-cyan-400'
        }`}
      >
        {/* Glow ambient background header */}
        <div
          className={`absolute top-0 left-0 right-0 h-32 pointer-events-none opacity-20 ${
            isFake
              ? 'bg-gradient-to-b from-red-600 to-transparent'
              : 'bg-gradient-to-b from-[#00FF41] to-transparent'
          }`}
        />

        {/* Close button */}
        <button
          id="close-verdict-popup-btn"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-[#71717A] hover:text-white rounded-2xl hover:bg-white/5 transition-colors z-10"
          title="Close Verdict"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6 sm:p-8 flex flex-col gap-6 relative z-10">
          {/* Header & Main Verdict Badge */}
          <div className="flex items-start gap-4">
            <div
              className={`p-3.5 rounded-2xl border shrink-0 ${
                isFake
                  ? 'bg-red-950/80 border-red-700 text-red-400'
                  : 'bg-emerald-950/80 border-emerald-700 text-cyan-400'
              }`}
            >
              {isFake ? (
                <ShieldAlert className="w-8 h-8 animate-pulse text-red-500" />
              ) : (
                <ShieldCheck className="w-8 h-8 text-cyan-400" />
              )}
            </div>

            <div>
              <div className="flex items-center gap-2 mb-1">
                <span
                  className={`text-[10px] font-mono font-bold uppercase tracking-widest px-2 py-0.5 rounded-xl border ${
                    isFake
                      ? 'bg-red-950 text-red-300 border-red-800'
                      : 'bg-emerald-950 text-emerald-300 border-emerald-800'
                  }`}
                >
                  {isFake ? 'SYNTHETIC CLONE DETECTED' : 'BIOLOGICAL SPEECH VERIFIED'}
                </span>
                <span className="text-[10px] font-mono text-[#71717A]">
                  DSP // SUB-200MS VERDICT
                </span>
              </div>

              <h2
                id="voice-verdict-status-title"
                className={`text-2xl sm:text-3xl font-black font-mono tracking-tight ${
                  isFake ? 'text-red-400' : 'text-cyan-400'
                }`}
              >
                {isFake ? 'VERDICT: FAKE (AI CLONE)' : 'VERDICT: AUTHENTIC (HUMAN)'}
              </h2>

              <p className="text-xs text-[#A1A1AA] mt-1 leading-relaxed">
                {isFake
                  ? 'High-confidence neural vocoder synthesis artifacts, abrupt spectral roll-off, and unnatural phase dispersion detected in the voice stream.'
                  : 'Natural glottal pulse jitter, organic respiratory micro-pauses, and continuous harmonic phase across full spectrum bandwidth.'}
              </p>
            </div>
          </div>

          {/* Core Metrics Scoreboard */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="p-3 bg-[#121214] border border-white/10 rounded-2xl">
              <span className="text-[9px] font-mono text-[#71717A] uppercase block">
                {isFake ? 'Fake Probability' : 'Authentic Match'}
              </span>
              <div
                className={`text-xl font-bold font-mono ${
                  isFake ? 'text-red-400' : 'text-cyan-400'
                }`}
              >
                {confidenceScore.toFixed(1)}%
              </div>
              <span className="text-[9px] font-mono text-[#71717A]">
                {isFake ? 'High Risk' : 'Pass AA'}
              </span>
            </div>

            <div className="p-3 bg-[#121214] border border-white/10 rounded-2xl">
              <span className="text-[9px] font-mono text-[#71717A] uppercase block">
                Vocoder Roll-Off
              </span>
              <div className="text-xl font-bold font-mono text-white">
                {(telemetry.spectralRollOffHz / 1000).toFixed(1)}k
                <span className="text-xs font-normal text-[#A1A1AA] ml-0.5">Hz</span>
              </div>
              <span className="text-[9px] font-mono text-[#71717A]">
                {isFake ? '16kHz Cutoff' : 'Full Bandwidth'}
              </span>
            </div>

            <div className="p-3 bg-[#121214] border border-white/10 rounded-2xl">
              <span className="text-[9px] font-mono text-[#71717A] uppercase block">
                Glottal Jitter
              </span>
              <div className="text-xl font-bold font-mono text-white">
                {telemetry.pitchJitterPercent.toFixed(2)}%
              </div>
              <span className="text-[9px] font-mono text-[#71717A]">
                {isFake ? 'Unnatural Floor' : 'Biological'}
              </span>
            </div>

            <div className="p-3 bg-[#121214] border border-white/10 rounded-2xl">
              <span className="text-[9px] font-mono text-[#71717A] uppercase block">
                Phase Coherence
              </span>
              <div className="text-xl font-bold font-mono text-white">
                {telemetry.phaseContinuityScore}/100
              </div>
              <span className="text-[9px] font-mono text-[#71717A]">
                {isFake ? 'Phase Shift' : 'Continuous'}
              </span>
            </div>
          </div>

          {/* Directive / Advisory Box */}
          <div
            className={`p-3.5 rounded-2xl border text-xs leading-relaxed font-sans ${
              isFake
                ? 'bg-red-950/40 border-red-800 text-red-200'
                : 'bg-emerald-950/40 border-emerald-800 text-emerald-200'
            }`}
          >
            <span className="font-mono font-bold uppercase block mb-0.5 text-white">
              {isFake ? 'DEFENSE ACTION REQUIRED:' : 'IDENTITY CONFIRMATION:'}
            </span>
            {isFake ? (
              <p>
                <strong>Zero-Trust Alert:</strong> This audio exhibits synthetic voice clone characteristics. Reject verbal authorizations, do not disclose MFA tokens, and trigger secondary out-of-band identity verification.
              </p>
            ) : (
              <p>
                <strong>Organic Voice Cleared:</strong> Acoustic resonance and sub-band harmonic dynamics conform to biological human vocal tract kinematics. Safe to proceed with normal operational protocol.
              </p>
            )}
          </div>

          {/* Quick Demo Switchers & Actions */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-white/10">
            <div className="flex items-center gap-2 w-full sm:w-auto">
              {onTestAuthentic && (
                <button
                  id="test-authentic-sample-btn"
                  onClick={onTestAuthentic}
                  className={`px-3 py-2 text-xs font-mono font-bold uppercase rounded-2xl border transition-all flex items-center gap-1.5 ${
                    !isFake
                      ? 'bg-cyan-400 text-black border-cyan-400'
                      : 'bg-white/5 hover:bg-[#27272A] text-zinc-300 border-white/10'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Sample Authentic</span>
                </button>
              )}

              {onTestFake && (
                <button
                  id="test-fake-sample-btn"
                  onClick={onTestFake}
                  className={`px-3 py-2 text-xs font-mono font-bold uppercase rounded-2xl border transition-all flex items-center gap-1.5 ${
                    isFake
                      ? 'bg-red-600 text-white border-red-500'
                      : 'bg-white/5 hover:bg-[#27272A] text-zinc-300 border-white/10'
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Sample Fake</span>
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              {onNavigateToTab && (
                <button
                  onClick={() => {
                    onClose();
                    onNavigateToTab(isFake ? 'forensic_report' : 'forensic_report');
                  }}
                  className="px-4 py-2 bg-white/5 hover:bg-[#27272A] text-white border border-white/10 hover:border-zinc-500 font-mono text-xs uppercase tracking-wider rounded-2xl transition-colors flex items-center gap-1"
                >
                  <span>{isFake ? 'View RL Defense' : 'Deep Biomarkers'}</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              )}

              <button
                onClick={onClose}
                className="px-5 py-2 bg-white text-black hover:bg-zinc-200 font-mono text-xs font-bold uppercase tracking-wider rounded-2xl transition-colors"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
