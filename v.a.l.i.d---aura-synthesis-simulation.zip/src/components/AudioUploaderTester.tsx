/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  Upload,
  Play,
  Pause,
  RotateCcw,
  Mic,
  MicOff,
  FileAudio,
  ShieldAlert,
  ShieldCheck,
  Zap,
  Activity,
  BarChart2,
  Sparkles,
  Volume2,
  VolumeX,
  ArrowRight,
  Download,
  AlertTriangle,
  Radio,
  FileText,
  Layers,
  Cpu
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AcousticTelemetry, ForensicReportEntry, CallAnalysisResult } from '../types';
import { calculateAcousticMetrics, getAudioContext } from '../utils/audioEngine';
import { analyzeAudioBuffer, DecodedAudioAnalysis, generateSyntheticTestAudioBuffer } from '../utils/audioDecoder';
import { FrequencyDomainVisualizer } from './FrequencyDomainVisualizer';

interface AudioUploaderTesterProps {
  onTelemetryUpdate: (telemetry: AcousticTelemetry) => void;
  isLiveMicActive: boolean;
  onToggleMic: () => void;
  onNavigateToTab?: (tab: string) => void;
  onReportGenerated?: (report: ForensicReportEntry) => void;
}

export const AudioUploaderTester: React.FC<AudioUploaderTesterProps> = ({
  onTelemetryUpdate,
  isLiveMicActive,
  onToggleMic,
  onNavigateToTab,
  onReportGenerated,
}) => {
  const [analysis, setAnalysis] = useState<DecodedAudioAnalysis | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackProgress, setPlaybackProgress] = useState<number>(0);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Live Web Audio Nodes during Playback
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const analyserNodeRef = useRef<AnalyserNode | null>(null);
  const playbackStartTimeRef = useRef<number>(0);
  const playbackOffsetRef = useRef<number>(0);
  const animationFrameRef = useRef<number | null>(null);

  // Live FFT and Time-Domain data buffers for visualizer
  const [liveFreqData, setLiveFreqData] = useState<Uint8Array>(new Uint8Array(1024));
  const [liveTimeData, setLiveTimeData] = useState<Uint8Array>(new Uint8Array(2048));

  // Initialize with a default synthetic demo sample on initial mount if none loaded
  useEffect(() => {
    loadPresetSample('ELEVENLABS_V3');
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopPlayback();
    };
  }, []);

  const stopPlayback = () => {
    if (sourceNodeRef.current) {
      try {
        sourceNodeRef.current.stop();
        sourceNodeRef.current.disconnect();
      } catch (err) {
        console.debug('Source stop error:', err);
      }
      sourceNodeRef.current = null;
    }
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    setIsPlaying(false);
    setPlaybackProgress(0);
  };

  const processAudioFile = async (file: File) => {
    setIsProcessing(true);
    setErrorMessage(null);
    stopPlayback();

    try {
      const arrayBuffer = await file.arrayBuffer();
      const ctx = getAudioContext();
      const decodedBuffer = await ctx.decodeAudioData(arrayBuffer);

      const result = analyzeAudioBuffer(decodedBuffer, file.name, file.size);
            setAnalysis(result);
      
      // Trigger forensic report generation on the backend
      try {
        const res = await fetch('/api/analyze-call', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            callerName: 'Audio Upload Analysis',
            callerRole: 'External Source',
            targetRole: 'Forensic System',
            scenarioTitle: 'Manual Audio Analysis',
            transcript: ['Audio processed via local upload buffer.'],
            telemetry: currentTelemetryRef.current || {},
            cloneScore: result.syntheticProbability,
          }),
        });
        const data = await res.json();
        if (data.success && data.report && onReportGenerated) {
          onReportGenerated({
            id: 'FR-' + Math.random().toString(36).substring(2, 9).toUpperCase(),
            timestamp: Date.now(),
            source: 'Upload',
            telemetrySnapshot: currentTelemetryRef.current || {},
            analysis: data.report
          });
        }
      } catch (e) {
        console.error('AI analysis error for upload:', e);
      }
      onTelemetryUpdate(result.telemetry);
    } catch (err: unknown) {
      console.error('Audio file decode error:', err);
      setErrorMessage(
        'Failed to decode audio file. Ensure the file is a valid audio format (.wav, .mp3, .ogg, .m4a, .flac).'
      );
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processAudioFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('audio/')) {
      processAudioFile(file);
    } else if (file) {
      // Try processing even if MIME type is generic audio container
      processAudioFile(file);
    }
  };

  const loadPresetSample = async (type: 'ELEVENLABS_V3' | 'HUMAN_AUTHENTIC' | 'GPT4O_VOICE' | 'PSTN_NARROWBAND') => {
    stopPlayback();
    setIsProcessing(true);
    setErrorMessage(null);

    try {
      const ctx = getAudioContext();
      const buffer = generateSyntheticTestAudioBuffer(type, ctx);

      let name = 'ElevenLabs_v3_ZeroShot_Clone.wav';
      if (type === 'HUMAN_AUTHENTIC') name = 'Executive_Authentic_Voice.wav';
      if (type === 'GPT4O_VOICE') name = 'GPT4o_Streaming_Impersonation.wav';
      if (type === 'PSTN_NARROWBAND') name = 'PSTN_Narrowband_G711.wav';

      const result = analyzeAudioBuffer(buffer, name, Math.floor(buffer.length * 2));
            setAnalysis(result);
      
      // Trigger forensic report generation on the backend
      try {
        const res = await fetch('/api/analyze-call', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            callerName: 'Audio Upload Analysis',
            callerRole: 'External Source',
            targetRole: 'Forensic System',
            scenarioTitle: 'Manual Audio Analysis',
            transcript: ['Audio processed via local upload buffer.'],
            telemetry: currentTelemetryRef.current || {},
            cloneScore: result.syntheticProbability,
          }),
        });
        const data = await res.json();
        if (data.success && data.report && onReportGenerated) {
          onReportGenerated({
            id: 'FR-' + Math.random().toString(36).substring(2, 9).toUpperCase(),
            timestamp: Date.now(),
            source: 'Upload',
            telemetrySnapshot: currentTelemetryRef.current || {},
            analysis: data.report
          });
        }
      } catch (e) {
        console.error('AI analysis error for upload:', e);
      }
      onTelemetryUpdate(result.telemetry);
    } catch (err) {
      console.error('Preset sample generation error:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const startPlayback = () => {
    if (!analysis?.audioBuffer) return;
    const ctx = getAudioContext();

    if (isPlaying) {
      stopPlayback();
      return;
    }

    try {
      const source = ctx.createBufferSource();
      source.buffer = analysis.audioBuffer;

      const analyser = ctx.createAnalyser();
      analyser.fftSize = 2048;
      analyser.smoothingTimeConstant = 0.8;

      source.connect(analyser);
      analyser.connect(ctx.destination);

      sourceNodeRef.current = source;
      analyserNodeRef.current = analyser;

      const freqData = new Uint8Array(analyser.frequencyBinCount);
      const timeData = new Uint8Array(analyser.fftSize);

      playbackStartTimeRef.current = ctx.currentTime;
      const duration = analysis.audioBuffer.duration;

      source.onended = () => {
        setIsPlaying(false);
        setPlaybackProgress(0);
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current);
          animationFrameRef.current = null;
        }
      };

      source.start(0);
      setIsPlaying(true);

      const renderLoop = () => {
        if (!analyserNodeRef.current) return;
        analyserNodeRef.current.getByteFrequencyData(freqData);
        analyserNodeRef.current.getByteTimeDomainData(timeData);

        setLiveFreqData(new Uint8Array(freqData));
        setLiveTimeData(new Uint8Array(timeData));

        const elapsed = ctx.currentTime - playbackStartTimeRef.current;
        const progress = Math.min(100, (elapsed / duration) * 100);
        setPlaybackProgress(progress);

        if (progress < 100) {
          animationFrameRef.current = requestAnimationFrame(renderLoop);
        }
      };

      animationFrameRef.current = requestAnimationFrame(renderLoop);
    } catch (err) {
      console.error('Playback error:', err);
      setIsPlaying(false);
    }
  };

  const handleExportReport = () => {
    if (!analysis) return;
    const dataStr =
      'data:text/json;charset=utf-8,' +
      encodeURIComponent(
        JSON.stringify(
          {
            reportTitle: 'V.A.L.I.D Forensic Acoustic Audio Ingestion Report',
            timestamp: new Date().toISOString(),
            fileName: analysis.fileName,
            fileSize: `${(analysis.fileSizeBytes / 1024).toFixed(1)} KB`,
            duration: `${analysis.durationSec}s`,
            sampleRate: `${analysis.sampleRate} Hz`,
            channels: analysis.numberOfChannels,
            syntheticProbability: `${analysis.syntheticProbability}%`,
            isDeepfakeSuspect: analysis.isDeepfakeSuspect,
            highFrequencyEnergyRatio16k: `${analysis.highFreqEnergyRatio16k}%`,
            spectralRolloff: `${analysis.spectralRolloffHz} Hz`,
            microPauseVariance: `${analysis.microPauseVariance}ms`,
            dominantAnomalies: analysis.dominantAnomalies,
          },
          null,
          2
        )
      );
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `VALID_Forensic_${analysis.fileName.replace(/\.[^/.]+$/, '')}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const isThreat = analysis ? analysis.syntheticProbability > 65 : false;

  return (
    <div id="audio-uploader-tester-view" className="flex flex-col gap-6 font-sans">
      {/* ----------------------------------------------------------------------------------------- */}
      {/* Section Header */}
      {/* ----------------------------------------------------------------------------------------- */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 bg-neutral-950 border border-white/10 rounded-2xl">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-white/5 border border-white/10 rounded-2xl text-white">
            <Upload className="w-6 h-6 text-cyan-400" />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="text-xl font-bold text-white tracking-tight">
                Audio File Ingestion & Forensic Inspector
              </h2>
              <span className="px-2 py-0.5 rounded-2xl bg-white/5 border border-white/10 text-zinc-300 text-[10px] font-mono font-bold uppercase">
                Web Audio DSP Pipeline
              </span>
            </div>
            <p className="text-sm text-[#A1A1AA] mt-1">
              Upload custom voice recordings (.wav, .mp3, .m4a, .ogg, .flac) or test benchmark presets to inspect vocoder roll-off, glottal jitter, and deepfake impersonation markers.
            </p>
          </div>
        </div>

        {/* Global Action Controls */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            id="audio-lab-toggle-mic-btn"
            onClick={onToggleMic}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-mono text-xs uppercase tracking-wider transition-all border ${
              isLiveMicActive
                ? 'bg-red-600 hover:bg-red-500 text-white font-bold border-red-400 shadow-md animate-pulse'
                : 'bg-white/5 hover:bg-[#27272A] text-[#A1A1AA] hover:text-white border-white/10'
            }`}
          >
            {isLiveMicActive ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5 text-zinc-400" />}
            <span>{isLiveMicActive ? 'Mic Active (Capturing)' : 'Activate Live Mic'}</span>
          </button>
        </div>
      </div>

      {/* ----------------------------------------------------------------------------------------- */}
      {/* Upload Zone & Quick Benchmark Presets */}
      {/* ----------------------------------------------------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Drag & Drop Audio Upload Box (7 Cols) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          <div className="p-5 bg-neutral-900/60 backdrop-blur-xl border border-white/10 rounded-2xl flex flex-col gap-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider flex items-center gap-2">
                <FileAudio className="w-4 h-4 text-white" />
                Select or Drop Audio File
              </span>
              <span className="text-[10px] font-mono text-[#A1A1AA] uppercase">
                Supported: .WAV, .MP3, .M4A, .OGG, .FLAC (Up to 50MB)
              </span>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="audio/*,.wav,.mp3,.m4a,.ogg,.flac,.aac,.webm"
              onChange={handleFileInputChange}
              className="hidden"
              id="audio-uploader-hidden-input"
            />

            {/* Interactive Drop Box */}
            <div
              onClick={() => fileInputRef.current?.click()}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`p-8 rounded-2xl border-2 border-dashed cursor-pointer flex flex-col items-center justify-center gap-3 transition-all ${
                isDragging
                  ? 'border-cyan-400 bg-emerald-950/20 shadow-lg shadow-emerald-950/40'
                  : 'border-white/10 hover:border-white bg-white/5/60 hover:bg-white/5'
              }`}
            >
              <div className="p-3.5 rounded-full bg-black border border-white/10">
                <Upload className={`w-6 h-6 ${isDragging ? 'text-cyan-400' : 'text-[#A1A1AA]'}`} />
              </div>

              <div className="text-center space-y-1">
                <p className="text-sm font-mono font-bold text-white uppercase tracking-wider">
                  {analysis?.fileName ? `Loaded: ${analysis.fileName}` : 'Click to Browse or Drag & Drop Voice Audio'}
                </p>
                <p className="text-xs text-[#A1A1AA] font-sans">
                  Instantly extracts 2048-bin FFT spectrum, 16kHz vocoder cliff, pitch jitter, and synthetic probability.
                </p>
              </div>

              <span className="px-3 py-1 rounded-2xl bg-black border border-white/10 text-zinc-400 text-[10px] font-mono uppercase tracking-wider">
                Select Local File
              </span>
            </div>

            {errorMessage && (
              <div className="p-3 rounded-2xl bg-red-950/90 border border-red-700 text-red-200 text-xs font-mono flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}
          </div>
        </div>

        {/* Quick Benchmark Presets Selector (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="p-5 bg-neutral-900/60 backdrop-blur-xl border border-white/10 rounded-2xl flex flex-col gap-3 h-full justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-3">
                <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider flex items-center gap-2">
                  <Radio className="w-4 h-4 text-amber-400" />
                  Quick Benchmark Test Presets
                </span>
                <span className="text-[10px] font-mono text-[#A1A1AA] uppercase">1-Click Test</span>
              </div>

              <p className="text-xs text-[#A1A1AA] mb-3">
                Don&apos;t have an audio file ready? Test our pre-synthesized acoustic benchmarks generated natively in browser Web Audio:
              </p>

              <div className="space-y-2">
                {[
                  {
                    id: 'ELEVENLABS_V3',
                    name: 'ElevenLabs v3 Zero-Shot Voice Clone',
                    desc: 'Sharp 16kHz vocoder spectral cliff & <20ms micro-pause rigidity',
                    type: 'CLONE',
                  },
                  {
                    id: 'GPT4O_VOICE',
                    name: 'OpenAI GPT-4o Voice Streaming Clone',
                    desc: 'Flow matching ODE synthesis with bispectrum glottal phase slip',
                    type: 'CLONE',
                  },
                  {
                    id: 'HUMAN_AUTHENTIC',
                    name: 'Authentic Executive Human Speech',
                    desc: 'Normal biological glottal jitter, natural respiration & wideband harmonics',
                    type: 'HUMAN',
                  },
                  {
                    id: 'PSTN_NARROWBAND',
                    name: 'PSTN G.711 Telephony Caller',
                    desc: '300Hz-3400Hz narrowband filter with genuine biological micro-tremors',
                    type: 'HUMAN',
                  },
                ].map((item) => (
                  <button
                    key={item.id}
                    id={`preset-btn-${item.id}`}
                    onClick={() => loadPresetSample(item.id as any)}
                    className="w-full text-left p-2.5 rounded-2xl bg-white/5 hover:bg-[#27272A] border border-white/10 hover:border-zinc-500 transition-all flex items-start justify-between gap-3 group"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            item.type === 'CLONE' ? 'bg-red-500' : 'bg-cyan-400'
                          }`}
                        />
                        <span className="text-xs font-mono font-bold text-white group-hover:text-white">
                          {item.name}
                        </span>
                      </div>
                      <p className="text-[11px] text-[#A1A1AA] mt-0.5 leading-snug">{item.desc}</p>
                    </div>

                    <span
                      className={`text-[9px] font-mono uppercase px-1.5 py-0.5 rounded-xl shrink-0 ${
                        item.type === 'CLONE'
                          ? 'bg-red-950 text-red-300 border border-red-800'
                          : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      }`}
                    >
                      {item.type}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ----------------------------------------------------------------------------------------- */}
      {/* Active Audio File Player & Forensic Spectrum Visualizer */}
      {/* ----------------------------------------------------------------------------------------- */}
      {analysis && (
        <div className="p-6 bg-neutral-900/60 backdrop-blur-xl border border-white/10 rounded-2xl flex flex-col gap-6">
          {/* Top Bar: File Details & Verdict Badge */}
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
            <div className="flex items-center gap-3">
              <div
                className={`p-2.5 rounded-2xl border ${
                  isThreat
                    ? 'bg-red-950 border-red-700 text-red-300'
                    : 'bg-emerald-950 border-emerald-700 text-emerald-300'
                }`}
              >
                {isThreat ? <ShieldAlert className="w-6 h-6 animate-pulse" /> : <ShieldCheck className="w-6 h-6" />}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-bold text-white font-mono">{analysis.fileName}</h3>
                  <span
                    className={`px-2 py-0.5 rounded-2xl text-[10px] font-mono font-bold uppercase border ${
                      isThreat
                        ? 'bg-red-950 text-red-300 border-red-800'
                        : 'bg-emerald-950 text-emerald-300 border-emerald-800'
                    }`}
                  >
                    {isThreat ? 'SYNTHETIC VOICE CLONE INTERCEPTED' : 'ORGANIC HUMAN SPEECH VERIFIED'}
                  </span>
                </div>
                <div className="text-xs font-mono text-[#A1A1AA] mt-0.5 flex items-center gap-3 flex-wrap">
                  <span>Duration: <strong className="text-white">{analysis.durationSec}s</strong></span>
                  <span>•</span>
                  <span>Sample Rate: <strong className="text-white">{analysis.sampleRate} Hz</strong></span>
                  <span>•</span>
                  <span>Channels: <strong className="text-white">{analysis.numberOfChannels === 1 ? 'Mono' : 'Stereo'}</strong></span>
                  <span>•</span>
                  <span>RMS: <strong className="text-white">{analysis.rmsLevelDb} dB</strong></span>
                </div>
              </div>
            </div>

            {/* Playback Controls & Action Buttons */}
            <div className="flex items-center gap-3">
              <button
                id="play-uploaded-audio-btn"
                onClick={startPlayback}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl font-mono text-xs font-bold uppercase tracking-wider transition-all shadow-md ${
                  isPlaying
                    ? 'bg-amber-500 hover:bg-amber-400 text-black border border-amber-400'
                    : 'bg-white hover:bg-[#E4E4E7] text-black border border-white'
                }`}
              >
                {isPlaying ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                <span>{isPlaying ? 'Pause Audio' : 'Play Audio & Inspect'}</span>
              </button>

              <button
                id="export-forensic-report-btn"
                onClick={handleExportReport}
                className="flex items-center gap-1.5 px-3 py-2.5 rounded-2xl bg-white/5 hover:bg-[#27272A] text-zinc-300 hover:text-white font-mono text-xs uppercase border border-white/10 transition-colors"
                title="Export Forensic JSON Report"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Export Report</span>
              </button>
            </div>
          </div>

          {/* Interactive Waveform Scrub Bar */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between text-[11px] font-mono text-[#A1A1AA]">
              <span>Audio Waveform Envelope (PCM)</span>
              <span>
                Progress: <strong className="text-white">{playbackProgress.toFixed(1)}%</strong>
              </span>
            </div>

            <div className="w-full h-12 bg-black rounded-2xl border border-white/10 flex items-center px-2 relative overflow-hidden">
              {/* Playback Progress Indicator */}
              <div
                className="absolute top-0 bottom-0 left-0 bg-cyan-400/15 border-r-2 border-cyan-400 transition-all duration-75"
                style={{ width: `${playbackProgress}%` }}
              />

              {/* Downsampled Waveform Bars */}
              <div className="w-full h-full flex items-center justify-between gap-[2px] z-10">
                {analysis.pcmWaveformPreview.map((val, idx) => {
                  const isPassed = (idx / 100) * 100 <= playbackProgress;
                  return (
                    <div
                      key={idx}
                      className={`flex-1 rounded-full transition-colors ${
                        isPassed
                          ? isThreat
                            ? 'bg-red-400'
                            : 'bg-cyan-400'
                          : 'bg-zinc-700'
                      }`}
                      style={{ height: `${Math.max(12, val * 100)}%` }}
                    />
                  );
                })}
              </div>
            </div>
          </div>

          {/* Real-time Frequency Domain Visualizer Canvas */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider">
                Live FFT Spectrum & Time-Domain Waveform Inspector
              </span>
              <span className="text-[10px] font-mono text-[#A1A1AA]">
                {isPlaying ? 'STREAMING REAL-TIME AUDIO PLAYBACK' : 'OFFLINE BUFFER INSPECTION'}
              </span>
            </div>

            <FrequencyDomainVisualizer
              telemetry={analysis.telemetry}
              frequencyData={liveFreqData}
              timeDomainData={liveTimeData}
              isThreat={isThreat}
              isLiveMicActive={false}
              onToggleLiveMic={onToggleMic}
              isSimulatingCall={isPlaying}
              audioSourceLabel={`File: ${analysis.fileName}`}
            />
          </div>

          {/* Forensic Acoustic Metrics Breakdown Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-col justify-between">
              <span className="text-[10px] font-mono text-[#A1A1AA] uppercase">Synthetic Voice Probability</span>
              <div
                className={`text-2xl font-bold font-mono mt-1 ${
                  isThreat ? 'text-red-400' : 'text-cyan-400'
                }`}
              >
                {analysis.syntheticProbability}%
              </div>
              <div className="text-[10px] font-mono text-[#71717A] mt-1">
                Threshold: &gt;65% Critical
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-col justify-between">
              <span className="text-[10px] font-mono text-[#A1A1AA] uppercase">&gt;16kHz Vocoder Energy Ratio</span>
              <div
                className={`text-2xl font-bold font-mono mt-1 ${
                  analysis.highFreqEnergyRatio16k < 1.5 ? 'text-red-400' : 'text-zinc-200'
                }`}
              >
                {analysis.highFreqEnergyRatio16k}%
              </div>
              <div className="text-[10px] font-mono text-[#71717A] mt-1">
                Human: &gt;2.5% • AI Vocoder: &lt;1.0%
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-col justify-between">
              <span className="text-[10px] font-mono text-[#A1A1AA] uppercase">Micro-Pause Variance</span>
              <div
                className={`text-2xl font-bold font-mono mt-1 ${
                  analysis.microPauseVariance < 50 ? 'text-red-400' : 'text-cyan-400'
                }`}
              >
                {analysis.microPauseVariance} ms
              </div>
              <div className="text-[10px] font-mono text-[#71717A] mt-1">
                Human Respiration: &gt;180ms
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-col justify-between">
              <span className="text-[10px] font-mono text-[#A1A1AA] uppercase">Glottal Pitch Jitter</span>
              <div className="text-2xl font-bold font-mono text-white mt-1">
                {analysis.pitchJitterPercent}%
              </div>
              <div className="text-[10px] font-mono text-[#71717A] mt-1">
                Natural Perturbation Band: 0.5% - 1.2%
              </div>
            </div>
          </div>

          {/* Dominant Forensic Findings & Cross-Module Action Links */}
          <div className="p-4 rounded-2xl bg-black border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="text-[10px] font-mono text-[#71717A] uppercase block mb-1">
                Forensic Biomarker Vector Findings:
              </span>
              <ul className="list-disc list-inside space-y-0.5 font-mono text-xs">
                {analysis.dominantAnomalies.map((anom, idx) => (
                  <li key={idx} className={isThreat ? 'text-red-300' : 'text-emerald-300'}>
                    {anom}
                  </li>
                ))}
              </ul>
            </div>

            {/* Cross-Module Navigation Links */}
            {onNavigateToTab && (
              <div className="flex flex-wrap items-center gap-2">
                <button
                  id="nav-to-sentinel-from-audio-btn"
                  onClick={() => onNavigateToTab('sentinel')}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-white/5 hover:bg-[#27272A] text-white font-mono text-xs uppercase border border-white/10 transition-colors"
                >
                  <span>Telephony Interceptor</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <button
                  id="nav-to-rl-from-audio-btn"
                  onClick={() => onNavigateToTab('forensic_report')}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-white hover:bg-[#E4E4E7] text-black font-mono text-xs font-bold uppercase transition-colors"
                >
                  <Zap className="w-3.5 h-3.5 fill-current" />
                  <span>Test in RL Defense</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
