import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldAlert,
  PhoneOff,
  Activity,
  AlertTriangle,
  X,
  Volume2,
  VolumeX,
  Zap,
  Radio,
  Clock,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { AcousticTelemetry } from '../types';

interface GlobalThreatAlertOverlayProps {
  telemetry: AcousticTelemetry;
  onNavigateToTab: (tab: string) => void;
  onTriggerKillswitch?: () => void;
}

export const GlobalThreatAlertOverlay: React.FC<GlobalThreatAlertOverlayProps> = ({
  telemetry,
  onNavigateToTab,
  onTriggerKillswitch,
}) => {
  const isThresholdExceeded = telemetry.syntheticProbability > 80;
  const [isDismissed, setIsDismissed] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(true);
  const [elapsedAlertSeconds, setElapsedAlertSeconds] = useState<number>(0);
  const audioContextRef = useRef<AudioContext | null>(null);
  const lastAlertProbabilityRef = useRef<number>(telemetry.syntheticProbability);

  // Re-arm alert if probability resets and then spikes above 80% again
  useEffect(() => {
    if (telemetry.syntheticProbability <= 80) {
      setIsDismissed(false);
      setElapsedAlertSeconds(0);
    } else if (telemetry.syntheticProbability > 80 && lastAlertProbabilityRef.current <= 80) {
      setIsDismissed(false);
      setElapsedAlertSeconds(0);
    }
    lastAlertProbabilityRef.current = telemetry.syntheticProbability;
  }, [telemetry.syntheticProbability]);

  // Alert timer
  useEffect(() => {
    let timer: any = null;
    if (isThresholdExceeded && !isDismissed) {
      timer = setInterval(() => {
        setElapsedAlertSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isThresholdExceeded, isDismissed]);

  // Web Audio subtle warning pulse sound
  useEffect(() => {
    if (!isThresholdExceeded || isDismissed || isMuted) return;

    try {
      if (!audioContextRef.current) {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          audioContextRef.current = new AudioCtx();
        }
      }

      const ctx = audioContextRef.current;
      if (!ctx) return;

      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime); // A5
      osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.25); // Pitch drop

      gain.gain.setValueAtTime(0.04, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.3);
    } catch (e) {
      // Audio context might be blocked by browser autoplay policy
    }
  }, [isThresholdExceeded, isDismissed, isMuted, Math.floor(elapsedAlertSeconds / 3)]);

  if (!isThresholdExceeded) {
    return null;
  }

  return (
    <>
      {/* 1. Global Pulsing Red Perimeter Screen Vignette Overlay */}
      <div 
        id="global-threat-pulsing-overlay"
        aria-live="assertive"
        className="fixed inset-0 pointer-events-none z-[9999] overflow-hidden"
      >
        {/* Outer Red Breathing Frame Border */}
        <div 
          className="absolute inset-0 border-[6px] sm:border-[8px] border-red-600/80 animate-pulse transition-opacity duration-300"
          style={{
            boxShadow: 'inset 0 0 80px rgba(220, 38, 38, 0.45), inset 0 0 180px rgba(185, 28, 28, 0.3), 0 0 30px rgba(239, 68, 68, 0.5)',
          }}
        />

        {/* Ambient Pulsing Red Corner Accents */}
        <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-red-600/40 via-red-600/10 to-transparent pointer-events-none animate-pulse" />
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-red-600/40 via-red-600/10 to-transparent pointer-events-none animate-pulse" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-tr from-red-600/40 via-red-600/10 to-transparent pointer-events-none animate-pulse" />
        <div className="absolute bottom-0 right-0 w-32 h-32 bg-gradient-to-tl from-red-600/40 via-red-600/10 to-transparent pointer-events-none animate-pulse" />

        {/* Scanline Strobe Effect */}
        <div 
          className="absolute inset-0 bg-[linear-gradient(rgba(239,68,68,0.06)_1px,transparent_1px)] bg-[size:100%_4px] opacity-70 pointer-events-none animate-pulse" 
        />
      </div>

      {/* 2. Top Screen Warning Bar (always visible when >80% threshold is active) */}
      <div 
        id="global-alert-indicator-strip"
        className="fixed top-0 left-0 right-0 z-[10000] bg-red-600 text-white font-mono text-[11px] py-1 px-4 flex items-center justify-between shadow-lg tracking-wider pointer-events-auto"
      >
        <div className="flex items-center gap-2 font-bold uppercase truncate">
          <span className="inline-block w-2 h-2 rounded-full bg-white animate-ping shrink-0" />
          <span className="shrink-0">CRITICAL THREAT OVERLAY ACTIVE</span>
          <span className="hidden sm:inline text-red-200">|</span>
          <span className="hidden sm:inline text-red-100">
            Synthetic Probability: <strong className="text-white">{telemetry.syntheticProbability.toFixed(1)}%</strong> (&gt;80% Policy Ceiling)
          </span>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            id="toggle-alert-sound-btn"
            onClick={() => setIsMuted(!isMuted)}
            className="flex items-center gap-1 text-[10px] uppercase font-bold text-red-100 hover:text-white hover:underline transition-colors"
            title={isMuted ? 'Unmute alert audio' : 'Mute alert audio'}
          >
            {isMuted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3 text-white animate-bounce" />}
            <span className="hidden xs:inline">{isMuted ? 'Muted' : 'Audio On'}</span>
          </button>

          {isDismissed ? (
            <button
              onClick={() => setIsDismissed(false)}
              className="text-[10px] text-white underline font-bold uppercase"
            >
              Expand Alert
            </button>
          ) : (
            <button
              id="dismiss-global-alert-hud-btn"
              onClick={() => setIsDismissed(true)}
              className="text-red-200 hover:text-white p-0.5"
              title="Minimize HUD (screen overlay remains active)"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* 3. Floating Interactive Executive Alert Modal / HUD */}
      {!isDismissed && (
        <div 
          id="global-threat-floating-hud"
          className="fixed top-12 left-1/2 -translate-x-1/2 z-[10000] w-[95%] max-w-2xl pointer-events-auto animate-in fade-in slide-in-from-top-4 duration-200"
        >
          <div className="bg-neutral-900/60 backdrop-blur-xl border-2 border-red-600 rounded-2xl shadow-2xl p-5 text-white font-mono space-y-4 relative overflow-hidden">
            {/* Background Red Radial Tint */}
            <div className="absolute -right-16 -top-16 w-48 h-48 bg-red-600/20 rounded-full blur-3xl pointer-events-none" />

            {/* Header / Title */}
            <div className="flex items-start justify-between gap-3 border-b border-red-900/80 pb-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-red-950 border border-red-700 rounded-2xl text-red-400 shrink-0">
                  <ShieldAlert className="w-6 h-6 animate-pulse text-red-500" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 bg-red-600 text-white font-bold text-[10px] uppercase rounded-xl">
                      CRITICAL ALERT
                    </span>
                    <span className="text-[11px] text-red-400 uppercase tracking-widest font-bold">
                      Synthetic Deepfake Detected
                    </span>
                  </div>
                  <h3 className="text-lg font-sans font-semibold text-white tracking-tight mt-0.5">
                    Impersonation Probability Exceeded 80% Threshold
                  </h3>
                </div>
              </div>

              <button
                onClick={() => setIsDismissed(true)}
                className="text-[#A1A1AA] hover:text-white p-1 rounded-2xl hover:bg-white/5 transition-colors"
                title="Minimize Banner"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Metrics Breakdown */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 bg-black rounded-2xl border border-red-900/60 space-y-1">
                <span className="text-[10px] text-[#A1A1AA] uppercase block">Synthetic Confidence:</span>
                <div className="text-xl font-bold text-red-400">
                  {telemetry.syntheticProbability.toFixed(1)}%
                </div>
                <span className="text-[10px] text-red-300 block">Threshold: &gt;80.0%</span>
              </div>

              <div className="p-3 bg-black rounded-2xl border border-white/10 space-y-1">
                <span className="text-[10px] text-[#A1A1AA] uppercase block">Phase Continuity Score:</span>
                <div className="text-xl font-bold text-amber-400">
                  {telemetry.phaseContinuityScore || 88}%
                </div>
                <span className="text-[10px] text-[#A1A1AA] block">Vocoder Artifacts: {telemetry.vocoderArtifactScore || 8}%</span>
              </div>

              <div className="p-3 bg-black rounded-2xl border border-white/10 space-y-1">
                <span className="text-[10px] text-[#A1A1AA] uppercase block">Pitch Jitter:</span>
                <div className="text-xl font-bold text-white">
                  {telemetry.pitchJitterPercent ? telemetry.pitchJitterPercent.toFixed(2) : '0.72'}%
                </div>
                <span className="text-[10px] text-[#A1A1AA] block">Absent Diaphragmatic Cycles</span>
              </div>
            </div>

            {/* Incident Summary & Advisory */}
            <div className="p-3 bg-red-950/40 border border-red-900 rounded-2xl text-[11px] font-sans text-red-200 leading-relaxed">
              <strong className="text-white font-mono uppercase font-bold">Threat Action Directive: </strong>
              The audio stream exhibits high-order neural vocoder synthesis artifacts and unnatural phase transitions characteristic of real-time voice conversion. <strong>Do not execute wire transfers, transfer credentials, or proceed with verbal authentication.</strong>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <div className="flex items-center gap-2">
                <button
                  id="alert-terminate-sip-btn"
                  onClick={() => {
                    if (onTriggerKillswitch) {
                      onTriggerKillswitch();
                    }
                    onNavigateToTab('overview');
                  }}
                  className="px-4 py-2.5 bg-red-600 hover:bg-red-500 text-white font-mono font-bold text-xs uppercase tracking-wider rounded-2xl flex items-center gap-2 shadow-lg transition-all"
                >
                  <PhoneOff className="w-3.5 h-3.5" />
                  <span>Terminate Call (SIP BYE)</span>
                </button>

                <button
                  id="alert-view-protocols-btn"
                  onClick={() => onNavigateToTab('procedural_guard')}
                  className="px-3.5 py-2.5 bg-white/5 hover:bg-[#27272A] text-white border border-white/10 font-mono text-xs uppercase tracking-wider rounded-2xl flex items-center gap-1.5 transition-all"
                >
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  <span>Verbal Safeguard</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsDismissed(true)}
                  className="px-3 py-2 text-[#A1A1AA] hover:text-white font-mono text-xs uppercase tracking-wider rounded-2xl hover:bg-white/5 transition-colors"
                >
                  Minimize Alert
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
