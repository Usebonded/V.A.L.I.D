/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { FileSearch,
  ShieldAlert,
  Activity,
  Radio,
  Lock,
  Cpu,
  FileCode2,
  Mic,
  MicOff,
  Volume2,
  Upload,
  Zap,
  Layers,
  ChevronDown,
  Menu,
  X,
  RadioTower,
  LayoutDashboard,
  ShieldCheck,
  AlertTriangle
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isLiveMicActive: boolean;
  onToggleMic: () => void;
  isSimulatingCall: boolean;
  onOpenVerdictModal?: () => void;
  syntheticProbability?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  isLiveMicActive,
  onToggleMic,
  isSimulatingCall,
  onOpenVerdictModal,
  syntheticProbability = 4.2,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isFake = syntheticProbability > 50;

  // Primary navigation pages
  const primaryNavItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'sentinel', label: 'Interceptor', icon: Volume2 },
    { id: 'audio_upload', label: 'Upload', icon: Upload },
    { id: 'forensic_report', label: 'Forensic', icon: FileSearch },
    { id: 'procedural_guard', label: 'Safeguards', icon: ShieldCheck },
    { id: 'architecture', label: 'Docs', icon: FileCode2 },
  ];

  const handleTabClick = (tabId: string) => {
    setActiveTab(tabId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-neutral-950/95 backdrop-blur-md shrink-0">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-[72px] flex items-center justify-between gap-4">
        {/* Brand & Subtitle */}
        <div className="flex items-center gap-6">
          <button
            onClick={() => handleTabClick('overview')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="font-mono text-[13px] tracking-widest font-bold border border-[#FFFFFF] px-2.5 py-1 text-white group-hover:bg-white group-hover:text-black transition-colors rounded-xl">
              V.A.L.I.D
            </div>
          </button>

          {/* Desktop Primary Nav */}
          <nav className="hidden xl:flex items-center gap-1 text-[11px] font-mono uppercase tracking-tight">
            {primaryNavItems.map((item) => {
              const isActive = activeTab === item.id || (item.id === 'sentinel' && activeTab === 'analysis');
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  id={`nav-btn-${item.id}`}
                  onClick={() => handleTabClick(item.id)}
                  className={`px-3 py-1.5 rounded-2xl transition-all flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-white/5 text-white font-bold border border-white/10 shadow-xs'
                      : 'text-[#A1A1AA] hover:text-white hover:bg-[#121214]'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-zinc-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Action Controls & Status */}
        <div className="flex items-center gap-3">
          {onOpenVerdictModal && (
            <button
              id="nav-verdict-popup-btn"
              onClick={onOpenVerdictModal}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-2xl text-[11px] font-mono uppercase tracking-wider transition-all border ${
                isFake
                  ? 'bg-red-950/70 hover:bg-red-900 border-red-600 text-red-300 font-bold'
                  : 'bg-emerald-950/70 hover:bg-emerald-900 border-emerald-600 text-cyan-400 font-bold'
              }`}
              title="Open Voice Authentication Status (Authentic vs. Fake)"
            >
              {isFake ? (
                <ShieldAlert className="w-3.5 h-3.5 text-red-400 animate-pulse" />
              ) : (
                <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              )}
              <span className="hidden xs:inline">
                {isFake ? 'Fake Voice' : 'Authentic'}
              </span>
              <span className="xs:hidden">Verdict</span>
            </button>
          )}

          <button
            id="nav-toggle-mic-btn"
            onClick={onToggleMic}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-2xl text-[11px] font-mono uppercase tracking-wider transition-all border ${
              isLiveMicActive
                ? 'bg-red-950 text-red-300 border-red-600 animate-pulse font-bold'
                : 'bg-white/5 hover:bg-[#27272A] text-[#A1A1AA] hover:text-white border-white/10'
            }`}
          >
            {isLiveMicActive ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5 text-zinc-400" />}
            <span>{isLiveMicActive ? 'Mic Active' : 'Live Mic'}</span>
          </button>

          {activeTab !== 'sentinel' && (
            <button
              id="nav-quick-start-sentinel-btn"
              onClick={() => handleTabClick('sentinel')}
              className="hidden sm:flex items-center gap-1.5 px-4 py-1.5 bg-[#FFFFFF] text-[#000000] text-[11px] font-bold rounded-2xl uppercase tracking-wider hover:bg-[#E4E4E7] transition-all shadow-sm"
            >
              <Volume2 className="w-3.5 h-3.5 fill-current" />
              <span>Scan Call</span>
            </button>
          )}

          {/* Mobile Menu Toggle Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-2 rounded-2xl bg-white/5 text-zinc-300 hover:text-white border border-white/10"
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Medium Screen Horizontal Nav Scrollbar (Tablets & Laptops) */}
      <div className="hidden lg:flex xl:hidden items-center justify-start overflow-x-auto px-6 py-2 border-t border-white/10 gap-2 bg-neutral-900/60 backdrop-blur-xl no-scrollbar">
        {primaryNavItems.map((item) => {
          const isActive = activeTab === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => handleTabClick(item.id)}
              className={`px-2.5 py-1 rounded-2xl text-[11px] font-mono uppercase whitespace-nowrap tracking-tight transition-all flex items-center gap-1.5 ${
                isActive
                  ? 'bg-white/5 text-white font-bold border border-white/10'
                  : 'text-[#A1A1AA] hover:text-white'
              }`}
            >
              <Icon className={`w-3 h-3 ${isActive ? 'text-cyan-400' : 'text-zinc-400'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-t border-white/10 bg-neutral-900/60 backdrop-blur-xl px-4 py-4 space-y-1 shadow-2xl animate-in slide-in-from-top-2">
          {primaryNavItems.map((item) => {
            const isActive = activeTab === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => handleTabClick(item.id)}
                className={`w-full text-left px-3 py-2.5 rounded-2xl text-xs font-mono uppercase tracking-wider flex items-center justify-between transition-colors ${
                  isActive
                    ? 'bg-white/5 text-white font-bold border border-white/10'
                    : 'text-[#A1A1AA] hover:text-white hover:bg-[#121214]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-zinc-400'}`} />
                  <span>{item.label}</span>
                </div>
                {isActive && <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />}
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
};
