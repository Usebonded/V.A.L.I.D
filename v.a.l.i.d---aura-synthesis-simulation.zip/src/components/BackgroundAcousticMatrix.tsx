import React, { useEffect, useRef } from 'react';
import { AcousticTelemetry } from '../types';

interface BackgroundAcousticMatrixProps {
  telemetry?: AcousticTelemetry;
  threatDetected?: boolean;
}

export const BackgroundAcousticMatrix: React.FC<BackgroundAcousticMatrixProps> = ({
  telemetry,
  threatDetected = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mouseRef = useRef<{ x: number; y: number; active: boolean }>({ x: 0, y: 0, active: false });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current = { x: e.clientX, y: e.clientY, active: true };
    };

    const handleMouseLeave = () => {
      mouseRef.current.active = false;
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseleave', handleMouseLeave);

    // Particle nodes for matrix
    const numCols = Math.floor(width / 48);
    const numRows = Math.floor(height / 48);
    const particles: { x: number; y: number; baseAlpha: number; speed: number; phase: number }[] = [];

    for (let i = 0; i < 90; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        baseAlpha: 0.15 + Math.random() * 0.35,
        speed: 0.2 + Math.random() * 0.5,
        phase: Math.random() * Math.PI * 2,
      });
    }

    let time = 0;

    const render = () => {
      time += 0.015;
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, width, height);

      const rms = telemetry?.rms || 0.05;
      const synthProb = telemetry?.syntheticProbability || 0;
      const isRed = threatDetected || synthProb > 65;

      // Draw subtle background grid
      ctx.strokeStyle = 'rgba(39, 39, 42, 0.35)'; // zinc-800 subtle
      ctx.lineWidth = 1;

      const gridSize = 64;
      ctx.beginPath();
      for (let x = 0; x < width; x += gridSize) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
      }
      ctx.stroke();

      // Render Concentric WAVES Ripple Field (inspired by WAVES video)
      if (mouseRef.current.active) {
        const mx = mouseRef.current.x;
        const my = mouseRef.current.y;
        const numRings = 16;
        for (let ring = 1; ring <= numRings; ring++) {
          const baseRadius = ring * 22;
          const radialWave = Math.sin(time * 3 - ring * 0.45) * 8;
          const radius = baseRadius + radialWave;
          const alpha = (1 - ring / (numRings + 2)) * 0.14;

          ctx.beginPath();
          ctx.arc(mx, my, Math.max(0, radius), 0, Math.PI * 2);
          ctx.strokeStyle = isRed
            ? `rgba(239, 68, 68, ${alpha * 1.5})`
            : `rgba(0, 240, 255, ${alpha * 1.2})`;
          ctx.lineWidth = 1;
          ctx.setLineDash([4, 6]);
          ctx.stroke();
          ctx.setLineDash([]);
        }
      }

      // Render 4 Sinusoidal Acoustic Wave Lines (Vocal Cord Resonance Simulation)
      const numWaves = 4;
      for (let w = 0; w < numWaves; w++) {
        ctx.beginPath();
        const waveOffset = w * (Math.PI / 2);
        const yCenter = height * 0.45 + w * 35;
        const amplitude = 30 + rms * 140 + (w === 0 ? Math.sin(time) * 15 : 0);
        const frequency = 0.0035 + w * 0.0012;

        for (let x = 0; x < width; x += 4) {
          // Distance to mouse
          let mouseDistortion = 0;
          if (mouseRef.current.active) {
            const dx = x - mouseRef.current.x;
            const dy = yCenter - mouseRef.current.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < 220) {
              mouseDistortion = (1 - dist / 220) * 35 * Math.sin(time * 3);
            }
          }

          const y =
            yCenter +
            Math.sin(x * frequency + time * (1.2 + w * 0.4) + waveOffset) * amplitude +
            Math.cos(x * 0.008 - time * 0.8) * (amplitude * 0.3) +
            mouseDistortion;

          if (x === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }

        if (isRed) {
          ctx.strokeStyle = `rgba(239, 68, 68, ${0.18 + w * 0.12})`; // Threat Crimson
        } else {
          ctx.strokeStyle = `rgba(255, 255, 255, ${0.08 + w * 0.07})`; // Minimalist crisp white/zinc
        }
        ctx.lineWidth = w === 0 ? 1.5 : 1;
        ctx.stroke();
      }

      // Draw Dithered Matrix Dots
      const ditherStep = 32;
      for (let dx = 16; dx < width; dx += ditherStep) {
        for (let dy = 16; dy < height; dy += ditherStep) {
          const distToWave = Math.abs(dy - (height * 0.45 + Math.sin(dx * 0.005 + time) * 40));
          if (distToWave < 120) {
            const dotAlpha = (1 - distToWave / 120) * (0.15 + rms * 0.4);
            ctx.fillStyle = isRed
              ? `rgba(239, 68, 68, ${dotAlpha})`
              : `rgba(255, 255, 255, ${dotAlpha})`;
            ctx.fillRect(dx - 0.75, dy - 0.75, 1.5, 1.5);
          }
        }
      }

      // Draw Floating Spectral Particle Nodes
      particles.forEach((p, idx) => {
        p.y -= p.speed * (1 + rms * 3);
        if (p.y < 0) {
          p.y = height;
          p.x = Math.random() * width;
        }

        const alpha = p.baseAlpha * (0.6 + Math.sin(time * 2 + p.phase) * 0.4);
        ctx.fillStyle = isRed
          ? `rgba(239, 68, 68, ${alpha * 1.5})`
          : `rgba(255, 255, 255, ${alpha})`;

        ctx.beginPath();
        ctx.arc(p.x, p.y, isRed ? 1.8 : 1.2, 0, Math.PI * 2);
        ctx.fill();

        // Connect nearby particles
        if (idx % 2 === 0) {
          for (let j = idx + 1; j < Math.min(idx + 4, particles.length); j++) {
            const p2 = particles[j];
            const dx = p.x - p2.x;
            const dy = p.y - p2.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < 90) {
              ctx.strokeStyle = isRed
                ? `rgba(239, 68, 68, ${0.08 * (1 - dist / 90)})`
                : `rgba(255, 255, 255, ${0.05 * (1 - dist / 90)})`;
              ctx.beginPath();
              ctx.moveTo(p.x, p.y);
              ctx.lineTo(p2.x, p2.y);
              ctx.stroke();
            }
          }
        }
      });

      // Subtle Radial Vignette
      const gradient = ctx.createRadialGradient(
        width / 2,
        height / 2,
        height * 0.2,
        width / 2,
        height / 2,
        Math.max(width, height) * 0.7
      );
      gradient.addColorStop(0, 'rgba(0, 0, 0, 0)');
      gradient.addColorStop(1, 'rgba(0, 0, 0, 0.85)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, height);

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseleave', handleMouseLeave);
      cancelAnimationFrame(animationFrameId);
    };
  }, [telemetry, threatDetected]);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      <canvas ref={canvasRef} className="w-full h-full block" />
      <div className="absolute inset-0 scanline opacity-40 pointer-events-none" />
    </div>
  );
};
