import React, { useState, useEffect, useRef } from 'react';
import {
  Wind,
  Timer,
  Compass,
  Cpu,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Flame,
  Radio,
  Zap,
  CheckCircle2,
  RefreshCw,
  Sliders,
  BarChart2,
  TrendingDown,
  Info
} from 'lucide-react';
import { AcousticTelemetry, ModelFingerprintMatch } from '../types';

interface NeuralBiomarkerTrackingViewProps {
  telemetry: AcousticTelemetry;
  isLiveActive: boolean;
}

export const NeuralBiomarkerTrackingView: React.FC<NeuralBiomarkerTrackingViewProps> = ({
  telemetry,
  isLiveActive,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'breathing' | 'micro_pauses' | 'phase' | 'models'>('all');
  const [selectedModelFilter, setSelectedModelFilter] = useState<string>('all');
  
  const breathingCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const lissajousCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const pauseHistogramCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const biomarkers = telemetry.biomarkers || {
    overallBiomarkerAnomalyScore: telemetry.syntheticProbability > 60 ? 91.4 : 11.2,
    predictedModel: telemetry.syntheticProbability > 60 ? 'ElevenLabs Multilingual v2' : 'Biological Human Vocal Cord',
    verdict: telemetry.syntheticProbability > 60 ? 'CONFIRMED_NEURAL_VOICE_MODEL' : 'BIOLOGICAL_RESPIRATION_AND_PHASE',
    breathingPattern: {
      inhalationDetected: false,
      inhalationIntervalMs: telemetry.syntheticProbability > 60 ? 1200 : 4400,
      inhalationDurationMs: telemetry.syntheticProbability > 60 ? 160 : 410,
      respirationEnergyRatio: telemetry.syntheticProbability > 60 ? 0.015 : 0.082,
      syntheticBreathArtifact: telemetry.syntheticProbability > 60 ? 'LOOPED_SYNTHETIC_INSERT' : 'ORGANIC_BIOLOGICAL_CYCLE',
      diaphragmaticAnomalyScore: telemetry.syntheticProbability > 60 ? 89 : 14,
      inhalationWaveform: [0.1, 0.2, 0.4, 0.6, 0.8, 0.7, 0.5, 0.3, 0.1],
    },
    microPauses: {
      currentPauseDurationMs: 40,
      averagePauseDurationMs: telemetry.syntheticProbability > 60 ? 32 : 310,
      pauseVariance: telemetry.syntheticProbability > 60 ? 14 : 178,
      tokenQuantizationIndex: telemetry.syntheticProbability > 60 ? 92 : 12,
      speechToSilenceTransitionSharpnessDbMs: telemetry.syntheticProbability > 60 ? 2.4 : 0.38,
      pauseCadenceHistory: [280, 310, 190, 420, 290, 340],
      isRigidTokenBoundaries: telemetry.syntheticProbability > 60,
      anomalyFlag: telemetry.syntheticProbability > 60,
    },
    phaseInconsistency: {
      instantaneousPhaseDiscontinuity: telemetry.syntheticProbability > 60 ? 88 : 12,
      overlapAddCancellationScore: telemetry.syntheticProbability > 60 ? 84 : 8,
      vocoderPhaseContinuityIndex: telemetry.syntheticProbability > 60 ? 18 : 88,
      glottalPulsePhaseDispersion: telemetry.syntheticProbability > 60 ? 1.82 : 0.26,
      phaseLissajousTrajectory: [],
      phaseAnomalyFlag: telemetry.syntheticProbability > 60,
    },
    modelFingerprints: [
      {
        modelName: 'ElevenLabs_Multilingual_v2',
        displayName: 'ElevenLabs Multilingual v2',
        confidence: telemetry.syntheticProbability > 60 ? 94.2 : 4.1,
        signatureMarkers: [
          '16.0 kHz Neural Vocoder brickwall cutoff with high-frequency phase dither',
          'Synthetic looped breath token injection detected',
          'High-order cepstral (c4-c12) L1 loss over-smoothing',
        ],
        primaryVector: 'Neural Vocoder 16kHz Cutoff & Looped Respiration',
      },
      {
        modelName: 'VALL_E_2',
        displayName: 'Microsoft VALL-E 2 Neural Codec',
        confidence: telemetry.syntheticProbability > 60 ? 45.4 : 2.1,
        signatureMarkers: [
          'EnCodec / SoundStream discrete token boundary phase jumps',
          'Absent diaphragmatic respiration intake',
          'Prompt-continuation acoustic variance mismatch',
        ],
        primaryVector: 'Discrete Neural Codec Token Concatenation',
      },
      {
        modelName: 'Tortoise_TTS',
        displayName: 'Tortoise-TTS Autoregressive',
        confidence: telemetry.syntheticProbability > 60 ? 32.0 : 1.8,
        signatureMarkers: [
          'Rigid token-quantized micro-pauses (<18ms variance)',
          'Autoregressive drift in pitch contour semitones',
          'DiffWave vocoder phase cancellation',
        ],
        primaryVector: 'Autoregressive Micro-Pause Quantization',
      },
    ],
    detectedBiomarkerFlags: [],
  };

  const isSynthetic = biomarkers.overallBiomarkerAnomalyScore > 60;
  const breathing = biomarkers.breathingPattern;
  const microPauses = biomarkers.microPauses;
  const phase = biomarkers.phaseInconsistency;

  // 1. Draw Respiration / Breathing Waveform Canvas
  useEffect(() => {
    const canvas = breathingCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = (canvas.width = canvas.parentElement?.clientWidth || 400);
    const height = (canvas.height = 130);
    const waveform = breathing.inhalationWaveform;

    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, width, height);

    // Draw baseline
    ctx.strokeStyle = '#27272A';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, height / 2);
    ctx.lineTo(width, height / 2);
    ctx.stroke();

    if (waveform.length > 1) {
      ctx.beginPath();
      ctx.strokeStyle = isSynthetic ? '#EF4444' : '#00FF41';
      ctx.lineWidth = 2;

      for (let i = 0; i < waveform.length; i++) {
        const x = (i / (waveform.length - 1)) * (width - 30) + 15;
        const amp = waveform[i];
        const y = height / 2 - (amp * (height / 2 - 16));

        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Mirror reflection for acoustic envelope
      ctx.beginPath();
      ctx.strokeStyle = isSynthetic ? 'rgba(239, 68, 68, 0.3)' : 'rgba(0, 255, 65, 0.3)';
      ctx.lineWidth = 1.5;
      for (let i = 0; i < waveform.length; i++) {
        const x = (i / (waveform.length - 1)) * (width - 30) + 15;
        const amp = waveform[i];
        const y = height / 2 + (amp * (height / 2 - 16));

        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
  }, [breathing, isSynthetic]);

  // 2. Draw 2D Phase Lissajous Orbital Trajectory Canvas
  useEffect(() => {
    const canvas = lissajousCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = (canvas.width = canvas.height = 150);
    const trajectory = phase.phaseLissajousTrajectory;
    const center = size / 2;
    const radius = size * 0.42;

    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, size, size);

    // Crosshairs
    ctx.strokeStyle = '#27272A';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(center, 10);
    ctx.lineTo(center, size - 10);
    ctx.moveTo(10, center);
    ctx.lineTo(size - 10, center);
    ctx.stroke();

    // Orbital path
    if (trajectory.length > 1) {
      ctx.beginPath();
      ctx.strokeStyle = isSynthetic ? '#EF4444' : '#00FF41';
      ctx.lineWidth = 1.8;

      for (let i = 0; i < trajectory.length; i++) {
        const pt = trajectory[i];
        const x = center + pt.x * radius;
        const y = center + pt.y * radius;

        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.stroke();

      // Draw points for phase nodes
      ctx.fillStyle = isSynthetic ? '#EF4444' : '#00FF41';
      for (let i = 0; i < trajectory.length; i += 4) {
        const pt = trajectory[i];
        const x = center + pt.x * radius;
        const y = center + pt.y * radius;
        ctx.beginPath();
        ctx.arc(x, y, 2, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }, [phase, isSynthetic]);

  // 3. Draw Micro-Pause Cadence Timeline Canvas
  useEffect(() => {
    const canvas = pauseHistogramCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = (canvas.width = canvas.parentElement?.clientWidth || 400);
    const height = (canvas.height = 110);
    const history = microPauses.pauseCadenceHistory;

    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, width, height);

    if (history.length > 0) {
      const barW = Math.max(12, Math.min(32, (width - 40) / history.length - 4));
      const maxPause = 600;

      for (let i = 0; i < history.length; i++) {
        const pauseVal = history[i];
        const x = 20 + i * (barW + 6);
        const barH = Math.max(6, (pauseVal / maxPause) * (height - 30));
        const y = height - barH - 10;

        ctx.fillStyle = isSynthetic ? '#EF4444' : '#00FF41';
        ctx.fillRect(x, y, barW, barH);

        // Pause value label
        ctx.fillStyle = '#A1A1AA';
        ctx.font = '9px monospace';
        ctx.fillText(`${pauseVal}ms`, x, y - 3);
      }
    }
  }, [microPauses, isSynthetic]);

  return (
    <div className="space-y-6">
      {/* Main Header & Master Biomarker Verdict */}
      <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Zap className="w-4 h-4 text-white" />
              <span className="text-xs font-mono text-[#A1A1AA] uppercase tracking-widest">
                Deepfake Acoustic Ingress Defense
              </span>
            </div>
            <h2 className="text-2xl font-sans font-medium text-white tracking-tight">
              Neural Biomarker Tracking
            </h2>
            <p className="text-xs text-[#A1A1AA] max-w-3xl mt-1 font-sans">
              Continuous detection of artificial respiration cycles, token-quantized micro-pauses, and vocoder phase inconsistencies engineered by generative voice models (<strong className="text-white">ElevenLabs, Tortoise-TTS, VALL-E 2, XTTS-v2</strong>).
            </p>
          </div>

          {/* Master Neural Verdict Box */}
          <div className={`p-4 rounded-2xl border font-mono text-xs flex items-center gap-3 shrink-0 ${
            biomarkers.verdict === 'CONFIRMED_NEURAL_VOICE_MODEL'
              ? 'bg-red-950/60 border-red-800 text-red-300'
              : biomarkers.verdict === 'SYNTHETIC_BIOMARKER_ANOMALIES'
              ? 'bg-amber-950/60 border-amber-800 text-amber-300'
              : 'bg-white/5 border-white/10 text-white'
          }`}>
            {biomarkers.verdict === 'CONFIRMED_NEURAL_VOICE_MODEL' ? (
              <ShieldAlert className="w-6 h-6 text-red-400 shrink-0 animate-pulse" />
            ) : biomarkers.verdict === 'SYNTHETIC_BIOMARKER_ANOMALIES' ? (
              <AlertTriangle className="w-6 h-6 text-amber-400 shrink-0" />
            ) : (
              <ShieldCheck className="w-6 h-6 text-cyan-400 shrink-0" />
            )}
            <div>
              <div className="text-[10px] text-[#A1A1AA] uppercase">Neural Biomarker Classification</div>
              <div className="text-sm font-bold tracking-wider uppercase">
                {biomarkers.verdict.replace(/_/g, ' ')}
              </div>
              <div className="text-[11px] mt-0.5">
                Matched Architecture: <strong className={isSynthetic ? 'text-red-400 font-bold' : 'text-cyan-400 font-bold'}>{biomarkers.predictedModel}</strong>
              </div>
            </div>
          </div>
        </div>

        {/* 3 Core Biomarker Pillars Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 border-t border-white/10">
          {/* Pillar 1: Breathing */}
          <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10 space-y-1">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-[#A1A1AA] uppercase flex items-center gap-1.5">
                <Wind className="w-3.5 h-3.5 text-white" />
                1. Respiration Cycle
              </span>
              <span className={`font-bold ${breathing.diaphragmaticAnomalyScore > 60 ? 'text-red-400' : 'text-cyan-400'}`}>
                {breathing.diaphragmaticAnomalyScore}% Anomaly
              </span>
            </div>
            <div className="w-full bg-black h-1.5 rounded-full overflow-hidden">
              <div
                className={`h-full ${breathing.diaphragmaticAnomalyScore > 60 ? 'bg-red-500' : 'bg-cyan-400'}`}
                style={{ width: `${breathing.diaphragmaticAnomalyScore}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-[#A1A1AA] block truncate">
              {breathing.syntheticBreathArtifact.replace(/_/g, ' ')}
            </span>
          </div>

          {/* Pillar 2: Micro-Pauses */}
          <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10 space-y-1">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-[#A1A1AA] uppercase flex items-center gap-1.5">
                <Timer className="w-3.5 h-3.5 text-white" />
                2. Micro-Pause Cadence
              </span>
              <span className={`font-bold ${microPauses.tokenQuantizationIndex > 60 ? 'text-red-400' : 'text-cyan-400'}`}>
                {microPauses.tokenQuantizationIndex}% Rigidity
              </span>
            </div>
            <div className="w-full bg-black h-1.5 rounded-full overflow-hidden">
              <div
                className={`h-full ${microPauses.tokenQuantizationIndex > 60 ? 'bg-red-500' : 'bg-cyan-400'}`}
                style={{ width: `${microPauses.tokenQuantizationIndex}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-[#A1A1AA] block">
              Inter-Pause Variance: σ = {microPauses.pauseVariance}ms {microPauses.pauseVariance < 30 ? '(Quantized)' : '(Biological)'}
            </span>
          </div>

          {/* Pillar 3: Phase Inconsistency */}
          <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10 space-y-1">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-[#A1A1AA] uppercase flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-white" />
                3. Vocoder Phase Coherence
              </span>
              <span className={`font-bold ${phase.instantaneousPhaseDiscontinuity > 60 ? 'text-red-400' : 'text-cyan-400'}`}>
                {phase.instantaneousPhaseDiscontinuity}% Discontinuity
              </span>
            </div>
            <div className="w-full bg-black h-1.5 rounded-full overflow-hidden">
              <div
                className={`h-full ${phase.instantaneousPhaseDiscontinuity > 60 ? 'bg-red-500' : 'bg-cyan-400'}`}
                style={{ width: `${phase.instantaneousPhaseDiscontinuity}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-[#A1A1AA] block">
              Dispersion: {phase.glottalPulsePhaseDispersion} rad | Continuity: {phase.vocoderPhaseContinuityIndex}%
            </span>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { id: 'all', label: 'All Biomarkers' },
          { id: 'breathing', label: '1. Respiration & Breathing' },
          { id: 'micro_pauses', label: '2. Micro-Pause Quantization' },
          { id: 'phase', label: '3. Vocoder Phase Inconsistency' },
          { id: 'models', label: '4. AI Model Fingerprints' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`px-4 py-2 rounded-2xl text-xs font-mono uppercase tracking-wider transition-all whitespace-nowrap border ${
              activeTab === tab.id
                ? 'bg-white text-black font-bold border-white shadow-sm'
                : 'bg-neutral-900/60 backdrop-blur-xl hover:bg-white/5 text-[#A1A1AA] hover:text-white border-white/10'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* SECTION 1: ARTIFICIAL BREATHING PATTERNS */}
      {(activeTab === 'all' || activeTab === 'breathing') && (
        <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Wind className="w-4 h-4 text-white" />
              <h3 className="text-base font-mono font-semibold text-white uppercase tracking-wider">
                Biomarker 1: Respiration & Artificial Breathing Detection
              </h3>
            </div>
            <span className="text-[11px] font-mono text-[#A1A1AA] uppercase">
              Sub-Phonemic Diaphragmatic Acoustics
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            {/* Inhalation Waveform Envelope Canvas */}
            <div className="lg:col-span-6 space-y-2">
              <span className="text-xs font-mono text-[#A1A1AA] uppercase tracking-wider block">
                Sub-Threshold Inhalation Amplitude Envelope
              </span>
              <div className="rounded-2xl overflow-hidden border border-white/10 bg-black p-2">
                <canvas ref={breathingCanvasRef} className="w-full h-[130px] block" />
              </div>
              <div className="flex items-center justify-between text-[11px] font-mono text-[#A1A1AA]">
                <span>Inhalation Window: <strong className="text-white">{breathing.inhalationDurationMs}ms</strong></span>
                <span>Breath Energy Ratio: <strong className="text-white">{breathing.respirationEnergyRatio}</strong></span>
              </div>
            </div>

            {/* Breathing Biomarker Defense Analysis */}
            <div className="lg:col-span-6 space-y-3">
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider block">
                  Synthetic Respiration Vulnerability Mechanics
                </span>
                <p className="text-xs text-[#A1A1AA] leading-relaxed font-sans">
                  Human biology requires diaphragmatic air intake every 3.2–5.8 seconds, accompanied by distinctive broad-spectrum turbulent air friction in the 1.5–4.0 kHz band.
                  Generative voice cloning engines either:
                </p>
                <ul className="text-xs text-[#A1A1AA] space-y-1 list-disc list-inside font-sans">
                  <li><strong className="text-white">Omit respiration entirely</strong> (e.g. VALL-E, Tortoise), producing continuous robotic phonation without lung replenishment.</li>
                  <li><strong className="text-white">Inject looped breath audio tokens</strong> (e.g. ElevenLabs), which repeat identical acoustic envelopes and lack biological cadence modulation.</li>
                </ul>
              </div>

              <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                <div className="p-3 bg-black rounded-2xl border border-white/10">
                  <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">Respiration Cycle Status:</span>
                  <span className={breathing.diaphragmaticAnomalyScore > 60 ? 'text-red-400 font-bold' : 'text-cyan-400 font-bold'}>
                    {breathing.syntheticBreathArtifact.replace(/_/g, ' ')}
                  </span>
                </div>
                <div className="p-3 bg-black rounded-2xl border border-white/10">
                  <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">Diaphragmatic Anomaly Score:</span>
                  <span className={breathing.diaphragmaticAnomalyScore > 60 ? 'text-red-400 font-bold' : 'text-cyan-400 font-bold'}>
                    {breathing.diaphragmaticAnomalyScore}% (Flagged)
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: UNNATURAL MICRO-PAUSES */}
      {(activeTab === 'all' || activeTab === 'micro_pauses') && (
        <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Timer className="w-4 h-4 text-white" />
              <h3 className="text-base font-mono font-semibold text-white uppercase tracking-wider">
                Biomarker 2: Token-Quantized Micro-Pauses & Cadence Variance
              </h3>
            </div>
            <span className="text-[11px] font-mono text-[#A1A1AA] uppercase">
              Inter-Word Latency Distribution
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Micro-Pause Cadence Sequence */}
            <div className="lg:col-span-6 space-y-2">
              <span className="text-xs font-mono text-[#A1A1AA] uppercase tracking-wider block">
                Inter-Phoneme Silence Durations (ms)
              </span>
              <div className="rounded-2xl overflow-hidden border border-white/10 bg-black p-2">
                <canvas ref={pauseHistogramCanvasRef} className="w-full h-[110px] block" />
              </div>
              <div className="flex items-center justify-between text-[11px] font-mono text-[#A1A1AA]">
                <span>Mean Pause: <strong className="text-white">{microPauses.averagePauseDurationMs}ms</strong></span>
                <span>Pause Variance (σ): <strong className={microPauses.pauseVariance < 30 ? 'text-red-400' : 'text-cyan-400'}>{microPauses.pauseVariance}ms</strong></span>
              </div>
            </div>

            {/* Token Quantization & Transition Gating */}
            <div className="lg:col-span-6 space-y-3">
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider block">
                  Autoregressive Token Boundary Gating
                </span>
                <p className="text-xs text-[#A1A1AA] leading-relaxed font-sans">
                  Neural speech synthesis engines decode audio in discrete token chunks. Between tokens, neural vocoders insert uniform silent intervals (<strong className="text-white">10–35ms with σ &lt; 20ms</strong>). Furthermore, vocoders abruptly gate audio energy at <strong className="text-white">&gt;2.0 dB/ms</strong>, omitting natural vocal tract acoustic decay.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                <div className="p-3 bg-black rounded-2xl border border-white/10">
                  <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">Token Quantization Index:</span>
                  <span className={microPauses.tokenQuantizationIndex > 60 ? 'text-red-400 font-bold' : 'text-cyan-400 font-bold'}>
                    {microPauses.tokenQuantizationIndex}% {microPauses.isRigidTokenBoundaries ? '(RIGID)' : '(ORGANIC)'}
                  </span>
                </div>
                <div className="p-3 bg-black rounded-2xl border border-white/10">
                  <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">Silence Gating Sharpness:</span>
                  <span className={microPauses.speechToSilenceTransitionSharpnessDbMs > 1.5 ? 'text-red-400 font-bold' : 'text-cyan-400 font-bold'}>
                    {microPauses.speechToSilenceTransitionSharpnessDbMs} dB/ms
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: NEURAL VOCODER PHASE INCONSISTENCIES */}
      {(activeTab === 'all' || activeTab === 'phase') && (
        <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-white" />
              <h3 className="text-base font-mono font-semibold text-white uppercase tracking-wider">
                Biomarker 3: Neural Vocoder Phase Inconsistency & Lissajous Orbit
              </h3>
            </div>
            <span className="text-[11px] font-mono text-[#A1A1AA] uppercase">
              2D Phase Polar Dispersion & STFT Overlap Cancellation
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            {/* 2D Lissajous Phase Orbital Trajectory Canvas */}
            <div className="lg:col-span-4 flex flex-col items-center space-y-2">
              <div className="p-2 bg-black rounded-2xl border border-white/10 inline-block">
                <canvas ref={lissajousCanvasRef} className="block" />
              </div>
              <span className="text-[10px] font-mono text-[#A1A1AA] uppercase text-center block">
                2D Lissajous Phase Orbital Trajectory (sin θ vs sin(θ+φ))
              </span>
            </div>

            {/* Phase Inconsistency Physics Breakdown */}
            <div className="lg:col-span-8 space-y-3">
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider block">
                  Why Neural Phase Inconsistencies Occur:
                </span>
                <p className="text-xs text-[#A1A1AA] leading-relaxed font-sans">
                  Unlike biological vocal folds that oscillate with continuous acoustic inertia, neural vocoders (<strong className="text-white">HiFi-GAN, BigVGAN, SoundStream, EnCodec</strong>) reconstruct phase from magnitude spectra or discrete neural tokens across discrete STFT frames. 
                  This creates <strong className="text-white">frame boundary phase flips, STFT overlap-add destructive cancellation, and high phase dispersion angle (&gt;1.5 rad)</strong>.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs">
                <div className="p-3 bg-black rounded-2xl border border-white/10">
                  <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">Instantaneous Phase Flip Rate:</span>
                  <span className={phase.instantaneousPhaseDiscontinuity > 60 ? 'text-red-400 font-bold' : 'text-cyan-400 font-bold'}>
                    {phase.instantaneousPhaseDiscontinuity}%
                  </span>
                </div>
                <div className="p-3 bg-black rounded-2xl border border-white/10">
                  <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">STFT Cancellation Score:</span>
                  <span className={phase.overlapAddCancellationScore > 60 ? 'text-red-400 font-bold' : 'text-cyan-400 font-bold'}>
                    {phase.overlapAddCancellationScore}%
                  </span>
                </div>
                <div className="p-3 bg-black rounded-2xl border border-white/10">
                  <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">Phase Dispersion Angle:</span>
                  <span className={phase.glottalPulsePhaseDispersion > 1.0 ? 'text-red-400 font-bold' : 'text-cyan-400 font-bold'}>
                    {phase.glottalPulsePhaseDispersion} rad
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 4: MODEL ARCHITECTURE FINGERPRINT MATCHING */}
      {(activeTab === 'all' || activeTab === 'models') && (
        <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-white" />
              <h3 className="text-base font-mono font-semibold text-white uppercase tracking-wider">
                Biomarker 4: AI Voice Synthesis Model Fingerprint Matching
              </h3>
            </div>
            <span className="text-[11px] font-mono text-[#A1A1AA] uppercase">
              Acoustic Profile Signature Alignment
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {biomarkers.modelFingerprints.map((model, idx) => (
              <div 
                key={idx}
                className={`p-4 rounded-2xl border space-y-3 ${
                  model.confidence > 70
                    ? 'bg-red-950/40 border-red-800'
                    : 'bg-white/5 border-white/10'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-white uppercase tracking-wider">
                    {model.displayName}
                  </span>
                  <span className={`px-2 py-0.5 rounded-xl text-[10px] font-mono font-bold ${
                    model.confidence > 70 ? 'bg-red-900 text-red-200' : 'bg-black text-[#A1A1AA]'
                  }`}>
                    {model.confidence}% Match
                  </span>
                </div>

                <div className="w-full bg-black h-1 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${model.confidence > 70 ? 'bg-red-500' : 'bg-cyan-400'}`}
                    style={{ width: `${model.confidence}%` }}
                  />
                </div>

                <div className="space-y-1 text-xs">
                  <span className="text-[10px] font-mono text-[#A1A1AA] uppercase block">Primary Forensic Vector:</span>
                  <p className="text-xs text-white font-mono">{model.primaryVector}</p>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-mono text-[#A1A1AA] uppercase block">Signature Markers:</span>
                  <ul className="text-[11px] text-[#A1A1AA] space-y-1 list-disc list-inside font-sans">
                    {model.signatureMarkers.map((marker, mIdx) => (
                      <li key={mIdx}>{marker}</li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Forensic Biomarker Anomaly Log */}
      <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-white/10">
          <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider">
            Flagged Neural Biomarker Indicators
          </span>
          <span className="text-[10px] font-mono text-[#A1A1AA] uppercase">
            {biomarkers.detectedBiomarkerFlags.length} Biomarkers Registered
          </span>
        </div>

        {biomarkers.detectedBiomarkerFlags.length === 0 ? (
          <div className="p-6 text-center text-xs font-mono text-[#A1A1AA] bg-white/5 rounded-2xl border border-white/10">
            ✓ All respiration cycles, micro-pause cadence variances, and phase coherence vectors confirm authentic biological human phonation. Zero neural voice synthesis biomarkers flagged.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {biomarkers.detectedBiomarkerFlags.map((flag, idx) => (
              <div key={idx} className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded-xl text-[9px] font-mono font-bold uppercase tracking-wider bg-red-950 text-red-300 border border-red-800">
                    {flag.biomarkerType} // {flag.severity}
                  </span>
                  <span className="text-xs font-mono font-bold text-white">{flag.metricValue}</span>
                </div>
                <h4 className="text-xs font-mono font-semibold text-white">{flag.title}</h4>
                <p className="text-xs text-[#A1A1AA] font-sans leading-relaxed">{flag.description}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
