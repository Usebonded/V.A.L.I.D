import React, { useState, useEffect, useRef } from 'react';
import { 
  Activity, 
  BarChart3, 
  Layers, 
  Cpu, 
  Radio, 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles, 
  RefreshCw,
  Sliders,
  TrendingUp,
  Flame,
  Info,
  Maximize2
} from 'lucide-react';
import { AcousticTelemetry } from '../types';

interface MultiFeatureDetectionViewProps {
  telemetry: AcousticTelemetry;
  isLiveActive: boolean;
}

export const MultiFeatureDetectionView: React.FC<MultiFeatureDetectionViewProps> = ({
  telemetry,
  isLiveActive,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'all' | 'mfcc' | 'spectrogram' | 'bispectrum' | 'pitch'>('all');
  const [spectrogramColormap, setSpectrogramColormap] = useState<'phosphor' | 'thermal' | 'monochrome'>('phosphor');
  
  const spectrogramCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const pitchContourCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const bispectrumCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const waterfallBufferRef = useRef<number[][]>([]);

  const mfcc = telemetry.mfccFeatures || {
    coefficients: [3.4, -1.2, 0.8, -0.4, 0.25, -0.15, 0.12, -0.08, 0.05, -0.04, 0.03, -0.02, 0.01],
    deltas: [0.1, -0.05, 0.04, -0.02, 0.01, -0.01, 0, 0, 0, 0, 0, 0, 0],
    deltaDeltas: [0.01, -0.01, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    highOrderSmoothness: 18,
    cepstralVariance: 0.82,
    spectralFlux: 0.65,
    anomalyFlag: false,
  };

  const spectrogram = telemetry.spectrogramAnalysis || {
    spectralCentroidHz: 2150,
    spectralRolloffHz: telemetry.spectralRollOffHz || 21800,
    spectralFlatness: 0.045,
    harmonicToNoiseRatioDb: 22.4,
    vocoderCutoffFrequencyHz: 22050,
    nyquistDitherScore: telemetry.vocoderArtifactScore || 12,
    checkerboardAnomalyScore: 10,
    spectralEnergyBands: {
      subBass: 18,
      lowMids: 42,
      highMids: 28,
      presence: 14,
      brilliance: 8,
    },
    anomalyFlag: false,
  };

  const bispectrum = telemetry.bispectrumFeatures || {
    bicoherenceMatrix: Array.from({ length: 12 }, () => Array.from({ length: 12 }, () => Math.random() * 0.3)),
    phaseCouplingIndex: telemetry.phaseContinuityScore || 84,
    nonGaussianityScore: 86,
    glottalPulseDecoupling: false,
    bispectralPeakRatio: 0.88,
    anomalyFlag: false,
  };

  const pitch = telemetry.pitchVariability || {
    f0Hz: telemetry.pitchHz || 156,
    f0MeanHz: 154,
    f0StdDev: 18.5,
    pitchRangeSemitones: 4.8,
    jitterPercent: telemetry.pitchJitterPercent || 0.78,
    shimmerPercent: telemetry.shimmerPercent || 1.92,
    microProsodyContour: [145, 148, 152, 156, 162, 158, 150, 147, 154, 160],
    glottalWaveformSymmetry: 0.78,
    unnaturalSmoothnessFlag: false,
    erraticDiscontinuityFlag: false,
  };

  const deepfakeReport = telemetry.deepfakeReport || {
    overallSyntheticProbability: telemetry.syntheticProbability || 8.4,
    verdict: telemetry.syntheticProbability > 65 ? 'CONFIRMED_DEEPFAKE_CLONE' : 'AUTHENTIC_BIOLOGICAL_VOICE',
    featureScores: {
      mfccAnomaly: mfcc.highOrderSmoothness,
      spectrogramAnomaly: spectrogram.nyquistDitherScore,
      bispectrumAnomaly: 100 - bispectrum.phaseCouplingIndex,
      pitchVariabilityAnomaly: pitch.jitterPercent < 0.25 ? 85 : 15,
    },
    detectedArtifacts: [],
  };

  const isSynthetic = deepfakeReport.overallSyntheticProbability > 65;

  // 1. Render Spectrogram Waterfall Canvas
  useEffect(() => {
    const canvas = spectrogramCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = (canvas.width = canvas.parentElement?.clientWidth || 700);
    const height = (canvas.height = 190);
    const numBins = 72;

    const slice: number[] = [];
    for (let i = 0; i < numBins; i++) {
      const freqHz = (i / numBins) * 22050;
      let power = 0;
      if (Math.abs(freqHz - telemetry.formants.f1) < 140) power += 0.85;
      if (Math.abs(freqHz - telemetry.formants.f2) < 220) power += 0.65;
      if (Math.abs(freqHz - telemetry.formants.f3) < 320) power += 0.45;

      if (isSynthetic && freqHz > (spectrogram.vocoderCutoffFrequencyHz || 16000)) {
        power *= 0.04;
      } else {
        power += Math.random() * 0.12 * telemetry.rms;
      }
      slice.push(Math.min(1, Math.max(0, power * (telemetry.rms > 0.02 ? 1 : 0.08))));
    }

    waterfallBufferRef.current.unshift(slice);
    if (waterfallBufferRef.current.length > width / 4) {
      waterfallBufferRef.current.pop();
    }

    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, width, height);

    const history = waterfallBufferRef.current;
    const colW = 4;

    for (let c = 0; c < history.length; c++) {
      const currentSlice = history[c];
      const x = width - c * colW;
      const binH = height / numBins;

      for (let r = 0; r < numBins; r++) {
        const val = currentSlice[r];
        const y = height - (r + 1) * binH;

        if (spectrogramColormap === 'phosphor') {
          if (isSynthetic) {
            ctx.fillStyle = `rgb(${Math.floor(val * 255)}, ${Math.floor(val * 60)}, ${Math.floor(val * 40)})`;
          } else {
            ctx.fillStyle = `rgb(${Math.floor(val * 40)}, ${Math.floor(val * 255)}, ${Math.floor(val * 80)})`;
          }
        } else if (spectrogramColormap === 'thermal') {
          const rVal = Math.min(255, Math.floor(val * 350));
          const gVal = Math.min(255, Math.floor(Math.max(0, val - 0.3) * 350));
          const bVal = Math.min(255, Math.floor(Math.max(0, val - 0.7) * 400));
          ctx.fillStyle = `rgb(${rVal}, ${gVal}, ${bVal})`;
        } else {
          const lum = Math.floor(val * 255);
          ctx.fillStyle = `rgb(${lum}, ${lum}, ${lum})`;
        }

        ctx.fillRect(x, y, colW, binH + 0.5);
      }
    }

    // Vocoder 16kHz Cutoff Line
    const cutoffY = height - (16000 / 22050) * height;
    ctx.strokeStyle = isSynthetic ? '#EF4444' : 'rgba(255, 255, 255, 0.4)';
    ctx.setLineDash([4, 4]);
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, cutoffY);
    ctx.lineTo(width, cutoffY);
    ctx.stroke();
    ctx.setLineDash([]);
  }, [telemetry, isSynthetic, spectrogramColormap, spectrogram.vocoderCutoffFrequencyHz]);

  // 2. Render 2D Bispectrum / Bicoherence Heatmap Canvas
  useEffect(() => {
    const canvas = bispectrumCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = (canvas.width = canvas.height = 180);
    const matrix = bispectrum.bicoherenceMatrix;
    const rows = matrix.length;
    const cols = matrix[0]?.length || 12;
    const cellW = size / cols;
    const cellH = size / rows;

    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, size, size);

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const val = matrix[r][c] || 0;
        const x = c * cellW;
        const y = (rows - 1 - r) * cellH;

        if (isSynthetic) {
          // Flat/suppressed bicoherence in synthetic speech
          const lum = Math.floor(val * 160);
          ctx.fillStyle = `rgb(${lum + 40}, ${Math.floor(lum * 0.3)}, ${Math.floor(lum * 0.3)})`;
        } else {
          // Sharp phase coupling peaks in human vocal tract
          const isHarmonic = (r === 1 && c === 1) || (r === 2 && c === 1) || (r === 1 && c === 2);
          if (isHarmonic) {
            ctx.fillStyle = '#00FF41';
          } else {
            const lum = Math.floor(val * 240);
            ctx.fillStyle = `rgb(${Math.floor(lum * 0.2)}, ${lum}, ${Math.floor(lum * 0.4)})`;
          }
        }
        ctx.fillRect(x + 0.5, y + 0.5, cellW - 1, cellH - 1);
      }
    }
  }, [bispectrum, isSynthetic]);

  // 3. Render Pitch Contour Trajectory Canvas
  useEffect(() => {
    const canvas = pitchContourCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = (canvas.width = canvas.parentElement?.clientWidth || 300);
    const height = (canvas.height = 110);
    const contour = pitch.microProsodyContour;

    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, width, height);

    // Draw grid
    ctx.strokeStyle = '#27272A';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, height / 2);
    ctx.lineTo(width, height / 2);
    ctx.stroke();

    if (contour.length > 1) {
      ctx.beginPath();
      ctx.strokeStyle = isSynthetic ? '#EF4444' : '#00FF41';
      ctx.lineWidth = 2;

      const minF0 = 80;
      const maxF0 = 260;

      for (let i = 0; i < contour.length; i++) {
        const val = contour[i];
        const x = (i / (contour.length - 1)) * (width - 20) + 10;
        const normalized = Math.max(0, Math.min(1, (val - minF0) / (maxF0 - minF0)));
        const y = height - (normalized * (height - 24) + 12);

        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
  }, [pitch, isSynthetic]);

  return (
    <div className="space-y-6">
      {/* Primary Header & Composite Verdict Banner */}
      <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Activity className="w-4 h-4 text-white" />
              <span className="text-xs font-mono text-[#A1A1AA] uppercase tracking-widest">
                Deepfake Acoustic Extraction Matrix
              </span>
            </div>
            <h2 className="text-2xl font-sans font-medium text-white tracking-tight">
              Multi-Feature DSP Deepfake Detection
            </h2>
            <p className="text-xs text-[#A1A1AA] max-w-3xl mt-1 font-sans">
              Comprehensive extraction across 13-band Mel-Frequency Cepstral Coefficients (MFCCs), high-resolution STFT spectrogram invariants, 2D Higher-Order Bispectrum phase coupling, and glottal pitch variability.
            </p>
          </div>

          {/* Master Verdict Badge */}
          <div className={`p-4 rounded-2xl border font-mono text-xs flex items-center gap-3 shrink-0 ${
            deepfakeReport.verdict === 'CONFIRMED_DEEPFAKE_CLONE'
              ? 'bg-red-950/60 border-red-800 text-red-300'
              : deepfakeReport.verdict === 'SUSPECT_SYNTHETIC_ANOMALIES'
              ? 'bg-amber-950/60 border-amber-800 text-amber-300'
              : 'bg-white/5 border-white/10 text-white'
          }`}>
            {deepfakeReport.verdict === 'CONFIRMED_DEEPFAKE_CLONE' ? (
              <ShieldAlert className="w-6 h-6 text-red-400 shrink-0 animate-pulse" />
            ) : deepfakeReport.verdict === 'SUSPECT_SYNTHETIC_ANOMALIES' ? (
              <AlertTriangle className="w-6 h-6 text-amber-400 shrink-0" />
            ) : (
              <ShieldCheck className="w-6 h-6 text-cyan-400 shrink-0" />
            )}
            <div>
              <div className="text-[10px] text-[#A1A1AA] uppercase">Composite Forensic Verdict</div>
              <div className="text-sm font-bold tracking-wider uppercase">
                {deepfakeReport.verdict.replace(/_/g, ' ')}
              </div>
              <div className="text-[11px] mt-0.5">
                Synthetic Anomaly Index: <strong className={isSynthetic ? 'text-red-400' : 'text-cyan-400'}>{deepfakeReport.overallSyntheticProbability}%</strong>
              </div>
            </div>
          </div>
        </div>

        {/* 4-Pillar Score Bar Overview */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 pt-2 border-t border-white/10">
          {/* MFCC Pillar */}
          <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10 space-y-1">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-[#A1A1AA] uppercase">1. MFCC Cepstral</span>
              <span className={`font-bold ${deepfakeReport.featureScores.mfccAnomaly > 60 ? 'text-red-400' : 'text-cyan-400'}`}>
                {deepfakeReport.featureScores.mfccAnomaly}% Anomaly
              </span>
            </div>
            <div className="w-full bg-black h-1.5 rounded-full overflow-hidden">
              <div 
                className={`h-full ${deepfakeReport.featureScores.mfccAnomaly > 60 ? 'bg-red-500' : 'bg-cyan-400'}`} 
                style={{ width: `${deepfakeReport.featureScores.mfccAnomaly}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-[#A1A1AA] block">c4-c12 Loss Smoothing</span>
          </div>

          {/* Spectrogram Pillar */}
          <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10 space-y-1">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-[#A1A1AA] uppercase">2. Spectrogram Invariants</span>
              <span className={`font-bold ${deepfakeReport.featureScores.spectrogramAnomaly > 60 ? 'text-red-400' : 'text-cyan-400'}`}>
                {deepfakeReport.featureScores.spectrogramAnomaly}% Anomaly
              </span>
            </div>
            <div className="w-full bg-black h-1.5 rounded-full overflow-hidden">
              <div 
                className={`h-full ${deepfakeReport.featureScores.spectrogramAnomaly > 60 ? 'bg-red-500' : 'bg-cyan-400'}`} 
                style={{ width: `${deepfakeReport.featureScores.spectrogramAnomaly}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-[#A1A1AA] block">16kHz Cutoff & Wiener Flatness</span>
          </div>

          {/* Bispectrum Pillar */}
          <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10 space-y-1">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-[#A1A1AA] uppercase">3. Bispectrum (HOSA)</span>
              <span className={`font-bold ${deepfakeReport.featureScores.bispectrumAnomaly > 60 ? 'text-red-400' : 'text-cyan-400'}`}>
                {deepfakeReport.featureScores.bispectrumAnomaly}% Decoupled
              </span>
            </div>
            <div className="w-full bg-black h-1.5 rounded-full overflow-hidden">
              <div 
                className={`h-full ${deepfakeReport.featureScores.bispectrumAnomaly > 60 ? 'bg-red-500' : 'bg-cyan-400'}`} 
                style={{ width: `${deepfakeReport.featureScores.bispectrumAnomaly}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-[#A1A1AA] block">Quadratic Phase Coupling</span>
          </div>

          {/* Pitch Variability Pillar */}
          <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10 space-y-1">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-[#A1A1AA] uppercase">4. Pitch & Jitter</span>
              <span className={`font-bold ${deepfakeReport.featureScores.pitchVariabilityAnomaly > 60 ? 'text-red-400' : 'text-cyan-400'}`}>
                {deepfakeReport.featureScores.pitchVariabilityAnomaly}% Anomaly
              </span>
            </div>
            <div className="w-full bg-black h-1.5 rounded-full overflow-hidden">
              <div 
                className={`h-full ${deepfakeReport.featureScores.pitchVariabilityAnomaly > 60 ? 'bg-red-500' : 'bg-cyan-400'}`} 
                style={{ width: `${deepfakeReport.featureScores.pitchVariabilityAnomaly}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-[#A1A1AA] block">Perturbation: {pitch.jitterPercent}% Jitter</span>
          </div>
        </div>
      </div>

      {/* Domain Focus Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { id: 'all', label: 'All 4 Feature Extraction Domains' },
          { id: 'mfcc', label: '1. MFCC Cepstral Coefficients' },
          { id: 'spectrogram', label: '2. Spectrogram & Nyquist Dither' },
          { id: 'bispectrum', label: '3. Higher-Order Bispectrum (HOSA)' },
          { id: 'pitch', label: '4. Pitch & Glottal Micro-Prosody' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id as typeof activeSubTab)}
            className={`px-4 py-2 rounded-2xl text-xs font-mono uppercase tracking-wider transition-all whitespace-nowrap border ${
              activeSubTab === tab.id
                ? 'bg-white text-black font-bold border-white shadow-sm'
                : 'bg-neutral-900/60 backdrop-blur-xl hover:bg-white/5 text-[#A1A1AA] hover:text-white border-white/10'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* SECTION 1: MFCC FEATURE EXTRACTION */}
      {(activeSubTab === 'all' || activeSubTab === 'mfcc') && (
        <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-white" />
              <h3 className="text-base font-mono font-semibold text-white uppercase tracking-wider">
                Feature Domain 1: Mel-Frequency Cepstral Coefficients (MFCCs)
              </h3>
            </div>
            <span className="text-[11px] font-mono text-[#A1A1AA] uppercase">
              13-Band DCT-II Log Triangular Filterbank
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* 13 MFCC Bars */}
            <div className="lg:col-span-8 space-y-3">
              <span className="text-xs font-mono text-[#A1A1AA] uppercase tracking-wider block">
                Instantaneous Mel Cepstral Vector (c0 to c12)
              </span>
              <div className="grid grid-cols-13 gap-1.5 p-4 rounded-2xl bg-black border border-white/10 items-end h-[160px]">
                {mfcc.coefficients.map((coeff, idx) => {
                  const normalizedH = Math.min(100, Math.max(10, Math.abs(coeff) * 28 + 15));
                  const isHighOrder = idx >= 4;
                  return (
                    <div key={idx} className="flex flex-col items-center gap-1.5 h-full justify-end">
                      <span className="text-[9px] font-mono text-[#A1A1AA]">
                        {coeff > 0 ? `+${coeff}` : coeff}
                      </span>
                      <div 
                        className={`w-full rounded-xl transition-all duration-150 ${
                          isSynthetic && isHighOrder
                            ? 'bg-red-500/80'
                            : isHighOrder
                            ? 'bg-cyan-400'
                            : 'bg-white'
                        }`}
                        style={{ height: `${normalizedH}%` }}
                      />
                      <span className="text-[10px] font-mono text-[#A1A1AA] uppercase">
                        c{idx}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Dynamic Delta and Delta-Delta Trajectory Row */}
              <div className="grid grid-cols-2 gap-3 font-mono text-xs pt-1">
                <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
                  <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">Δ (Velocity) Cepstral Flux:</span>
                  <span className="text-white font-bold">{mfcc.spectralFlux} Δ/frame</span>
                </div>
                <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
                  <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">ΔΔ (Acceleration) Dynamic Variance:</span>
                  <span className={mfcc.cepstralVariance < 0.3 ? 'text-red-400 font-bold' : 'text-cyan-400 font-bold'}>
                    {mfcc.cepstralVariance} (Dynamic)
                  </span>
                </div>
              </div>
            </div>

            {/* MFCC Deepfake Detection Theory & Diagnostics */}
            <div className="lg:col-span-4 space-y-3">
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider block">
                  Synthetic Artifact Insight: High-Order Smoothing
                </span>
                <p className="text-xs text-[#A1A1AA] leading-relaxed font-sans">
                  Autoregressive and diffusion voice synthesizers apply L1/L2 loss penalties during Mel spectrogram generation. This causes unnatural dampening in higher-order cepstral coefficients (<strong className="text-white">c4–c12</strong>), resulting in loss of natural micro-timbre texture.
                </p>
                <div className="p-2.5 bg-black rounded-2xl border border-white/10 font-mono text-[11px] flex items-center justify-between uppercase">
                  <span className="text-[#A1A1AA]">Smoothing Anomaly Index:</span>
                  <span className={mfcc.highOrderSmoothness > 60 ? 'text-red-400 font-bold' : 'text-cyan-400 font-bold'}>
                    {mfcc.highOrderSmoothness}% {mfcc.highOrderSmoothness > 60 ? '(ARTIFICIAL)' : '(ORGANIC)'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: SPECTROGRAM & SPECTRAL INVARIANTS */}
      {(activeSubTab === 'all' || activeSubTab === 'spectrogram') && (
        <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-white" />
              <h3 className="text-base font-mono font-semibold text-white uppercase tracking-wider">
                Feature Domain 2: Spectrogram Invariants & Wiener Entropy
              </h3>
            </div>
            
            {/* Colormap Switcher */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-[#A1A1AA] uppercase">Palette:</span>
              {(['phosphor', 'thermal', 'monochrome'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setSpectrogramColormap(mode)}
                  className={`px-2.5 py-1 rounded-xl text-[10px] font-mono uppercase tracking-wider border ${
                    spectrogramColormap === mode
                      ? 'bg-white text-black border-white font-bold'
                      : 'bg-white/5 text-[#A1A1AA] border-white/10'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-black">
              <canvas ref={spectrogramCanvasRef} className="w-full h-[190px] block" />
              <div className="absolute left-2 top-2 text-[9px] font-mono text-[#A1A1AA] bg-black/90 px-2 py-0.5 rounded-2xl border border-white/10 uppercase">
                Nyquist Upper Bound (22.05 kHz)
              </div>
              <div className="absolute right-2 top-2 text-[9px] font-mono text-red-400 bg-black/90 px-2 py-0.5 rounded-2xl border border-red-800 uppercase">
                Dashed = 16.0 kHz Neural Vocoder Hard Cutoff
              </div>
              <div className="absolute left-2 bottom-2 text-[9px] font-mono text-[#A1A1AA] bg-black/90 px-2 py-0.5 rounded-2xl border border-white/10 uppercase">
                Formants F0-F2 Base (0 - 2 kHz)
              </div>
            </div>

            {/* Spectral Metrics Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono text-xs">
              <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10">
                <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">Spectral Centroid:</span>
                <span className="text-white font-bold">{spectrogram.spectralCentroidHz} Hz</span>
              </div>
              <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10">
                <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">Spectral Rolloff (85%):</span>
                <span className={spectrogram.spectralRolloffHz <= 16500 ? 'text-red-400 font-bold' : 'text-white font-bold'}>
                  {spectrogram.spectralRolloffHz} Hz
                </span>
              </div>
              <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10">
                <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">Wiener Entropy (Flatness):</span>
                <span className="text-white font-bold">{spectrogram.spectralFlatness}</span>
              </div>
              <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10">
                <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">Harmonic-to-Noise (HNR):</span>
                <span className={spectrogram.harmonicToNoiseRatioDb < 12 ? 'text-red-400 font-bold' : 'text-cyan-400 font-bold'}>
                  {spectrogram.harmonicToNoiseRatioDb} dB
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: BISPECTRUM & HIGHER-ORDER SPECTRAL ANALYSIS (HOSA) */}
      {(activeSubTab === 'all' || activeSubTab === 'bispectrum') && (
        <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-white" />
              <h3 className="text-base font-mono font-semibold text-white uppercase tracking-wider">
                Feature Domain 3: Bispectrum & Quadratic Phase Coupling (QPC)
              </h3>
            </div>
            <span className="text-[11px] font-mono text-[#A1A1AA] uppercase">
              B(f1, f2) Higher-Order Spectral Analysis
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            {/* 2D Bicoherence Canvas */}
            <div className="lg:col-span-4 flex flex-col items-center space-y-2">
              <div className="p-2 bg-black rounded-2xl border border-white/10 inline-block">
                <canvas ref={bispectrumCanvasRef} className="block" />
              </div>
              <span className="text-[10px] font-mono text-[#A1A1AA] uppercase text-center block">
                2D Normalized Bicoherence Matrix b²(f1, f2)
              </span>
            </div>

            {/* Bispectrum Mathematical Explanation & Anomaly Diagnosis */}
            <div className="lg:col-span-8 space-y-4">
              <div className="space-y-2">
                <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider block">
                  Why Bispectrum Exposes Synthetic Voice Clones:
                </span>
                <p className="text-xs text-[#A1A1AA] leading-relaxed font-sans">
                  Human vocal cords generate non-linear quadratic phase coupling (QPC) between the fundamental pitch (<strong className="text-white">F0</strong>) and acoustic formant resonances (<strong className="text-white">F1, F2</strong>). 
                  Zero-shot diffusion and autoregressive voice cloning engines synthesize speech under independent harmonic assumptions or reconstruct phase via deterministic vocoders. Consequently, <strong className="text-white">synthetic voice clones exhibit flat, decoupled bicoherence matrices with zero biological QPC peaks</strong>.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs">
                <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10">
                  <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">Phase Coupling Index:</span>
                  <span className={bispectrum.phaseCouplingIndex < 40 ? 'text-red-400 font-bold' : 'text-cyan-400 font-bold'}>
                    {bispectrum.phaseCouplingIndex}% {bispectrum.phaseCouplingIndex < 40 ? '(DECOUPLED)' : '(COUPLED)'}
                  </span>
                </div>
                <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10">
                  <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">Non-Gaussianity Score:</span>
                  <span className="text-white font-bold">{bispectrum.nonGaussianityScore}/100</span>
                </div>
                <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10">
                  <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">Peak Bicoherence:</span>
                  <span className="text-white font-bold">{bispectrum.bispectralPeakRatio}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 4: PITCH VARIABILITY & GLOTTAL MICRO-PROSODY */}
      {(activeSubTab === 'all' || activeSubTab === 'pitch') && (
        <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-white" />
              <h3 className="text-base font-mono font-semibold text-white uppercase tracking-wider">
                Feature Domain 4: Pitch Variability, Glottal Jitter & Shimmer
              </h3>
            </div>
            <span className="text-[11px] font-mono text-[#A1A1AA] uppercase">
              F0 Dynamic Autocorrelation & Micro-Perturbation
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Pitch Contour Visualizer */}
            <div className="lg:col-span-6 space-y-3">
              <span className="text-xs font-mono text-[#A1A1AA] uppercase tracking-wider block">
                Instantaneous Fundamental Pitch Trajectory (F0 Contour)
              </span>
              <div className="rounded-2xl overflow-hidden border border-white/10 bg-black">
                <canvas ref={pitchContourCanvasRef} className="w-full h-[110px] block" />
              </div>
              <div className="flex items-center justify-between text-xs font-mono text-[#A1A1AA]">
                <span>Current F0: <strong className="text-white">{pitch.f0Hz} Hz</strong></span>
                <span>Mean F0: <strong className="text-white">{pitch.f0MeanHz} Hz</strong></span>
                <span>StdDev: <strong className="text-white">{pitch.f0StdDev} Hz</strong></span>
              </div>
            </div>

            {/* Perturbation Metrics & Jitter/Shimmer Gauges */}
            <div className="lg:col-span-6 space-y-3">
              <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                {/* Jitter Gauge */}
                <div className="p-4 bg-white/5 rounded-2xl border border-white/10 space-y-1">
                  <span className="text-[10px] text-[#A1A1AA] uppercase block">Glottal Jitter (Frequency Perturbation):</span>
                  <div className="flex items-baseline gap-2">
                    <span className={`text-xl font-bold ${pitch.jitterPercent < 0.25 ? 'text-red-400' : 'text-cyan-400'}`}>
                      {pitch.jitterPercent}%
                    </span>
                    <span className="text-[10px] text-[#A1A1AA]">Normal: 0.5 - 1.5%</span>
                  </div>
                  <p className="text-[10px] text-[#A1A1AA] font-sans">
                    {pitch.jitterPercent < 0.25 ? '⚠️ Abnormal mathematical smoothness detected (<0.25%).' : '✓ Natural biological vocal cord jitter verified.'}
                  </p>
                </div>

                {/* Shimmer Gauge */}
                <div className="p-4 bg-white/5 rounded-2xl border border-white/10 space-y-1">
                  <span className="text-[10px] text-[#A1A1AA] uppercase block">Amplitude Shimmer (Perturbation):</span>
                  <div className="flex items-baseline gap-2">
                    <span className={`text-xl font-bold ${pitch.shimmerPercent < 0.8 ? 'text-red-400' : 'text-cyan-400'}`}>
                      {pitch.shimmerPercent}%
                    </span>
                    <span className="text-[10px] text-[#A1A1AA]">Normal: 1.2 - 3.5%</span>
                  </div>
                  <p className="text-[10px] text-[#A1A1AA] font-sans">
                    {pitch.shimmerPercent < 0.8 ? '⚠️ Artificially constrained amplitude modulation.' : '✓ Organic glottal pulse shimmer verified.'}
                  </p>
                </div>
              </div>

              {/* Pitch Range Semitones */}
              <div className="p-3 bg-black rounded-2xl border border-white/10 font-mono text-xs flex items-center justify-between uppercase">
                <span className="text-[#A1A1AA]">Dynamic Prosody Pitch Range:</span>
                <span className="text-white font-bold">{pitch.pitchRangeSemitones} Semitones</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Forensic Evidence Log Table */}
      <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-white/10">
          <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider">
            Detailed Multi-Feature Anomaly Flags & Artifacts
          </span>
          <span className="text-[10px] font-mono text-[#A1A1AA] uppercase">
            {deepfakeReport.detectedArtifacts.length} Flagged Acoustic Indicators
          </span>
        </div>

        {deepfakeReport.detectedArtifacts.length === 0 ? (
          <div className="p-6 text-center text-xs font-mono text-[#A1A1AA] bg-white/5 rounded-2xl border border-white/10">
            ✓ All 4 feature extraction domains within authentic human biological parameters. Zero deepfake synthetic artifacts detected.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {deepfakeReport.detectedArtifacts.map((artifact, idx) => (
              <div key={idx} className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className={`px-2 py-0.5 rounded-xl text-[9px] font-mono font-bold uppercase tracking-wider ${
                    artifact.severity === 'critical'
                      ? 'bg-red-950 text-red-300 border border-red-800'
                      : 'bg-amber-950 text-amber-300 border border-amber-800'
                  }`}>
                    {artifact.featureCategory} // {artifact.severity}
                  </span>
                  <span className="text-xs font-mono font-bold text-white">{artifact.metricValue}</span>
                </div>
                <h4 className="text-xs font-mono font-semibold text-white">{artifact.title}</h4>
                <p className="text-xs text-[#A1A1AA] font-sans leading-relaxed">{artifact.description}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
