import React, { useEffect, useState, useRef } from 'react';
import { motion, useMotionValue, useSpring } from 'motion/react';

interface Ripple {
  x: number;
  y: number;
  id: number;
}

export const CustomCursor: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isPointer, setIsPointer] = useState(false);
  const [isMouseDown, setIsMouseDown] = useState(false);
  const [ripples, setRipples] = useState<Ripple[]>([]);

  // Raw mouse position (instant)
  const rawX = useMotionValue(-100);
  const rawY = useMotionValue(-100);

  // Smooth fluid spring position for the trailing glowing cyan wave orb (inspired by video)
  const springConfig = { damping: 22, stiffness: 260, mass: 0.55 };
  const smoothX = useSpring(rawX, springConfig);
  const smoothY = useSpring(rawY, springConfig);

  const rippleIdRef = useRef(0);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      rawX.set(e.clientX);
      rawY.set(e.clientY);
      if (!isVisible) setIsVisible(true);
    };

    const handleMouseLeave = () => setIsVisible(false);
    const handleMouseEnter = () => setIsVisible(true);

    const handleMouseDown = (e: MouseEvent) => {
      setIsMouseDown(true);
      // Spawn ripple on click
      const newId = ++rippleIdRef.current;
      setRipples((prev) => [...prev.slice(-4), { x: e.clientX, y: e.clientY, id: newId }]);
    };

    const handleMouseUp = () => setIsMouseDown(false);

    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target) return;

      const isClickable =
        window.getComputedStyle(target).cursor === 'pointer' ||
        target.tagName.toLowerCase() === 'button' ||
        target.tagName.toLowerCase() === 'a' ||
        target.closest('button') !== null ||
        target.closest('a') !== null;

      setIsPointer(isClickable);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseleave', handleMouseLeave);
    window.addEventListener('mouseenter', handleMouseEnter);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('mouseover', handleMouseOver);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('mouseenter', handleMouseEnter);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('mouseover', handleMouseOver);
    };
  }, [rawX, rawY, isVisible]);

  if (typeof window === 'undefined') return null;

  return (
    <>
      {/* Click Wave Ripples expanding from click location */}
      {ripples.map((ripple) => (
        <motion.div
          key={ripple.id}
          initial={{ scale: 0.2, opacity: 0.8 }}
          animate={{ scale: 3.5, opacity: 0 }}
          transition={{ duration: 0.85, ease: 'easeOut' }}
          onAnimationComplete={() => {
            setRipples((prev) => prev.filter((r) => r.id !== ripple.id));
          }}
          className="fixed pointer-events-none rounded-full border border-cyan-400 z-[99997]"
          style={{
            left: ripple.x - 24,
            top: ripple.y - 24,
            width: 48,
            height: 48,
            boxShadow: '0 0 15px rgba(0,240,255,0.4)',
          }}
        />
      ))}

      {/* Layer 1: Instant Precision Cyan Core Point */}
      <motion.div
        className="fixed top-0 left-0 pointer-events-none z-[99999]"
        style={{
          x: rawX,
          y: rawY,
          opacity: isVisible ? 1 : 0,
        }}
      >
        <div
          className={`relative flex items-center justify-center transition-transform duration-100 ${
            isMouseDown ? 'scale-75' : isPointer ? 'scale-125' : 'scale-100'
          }`}
          style={{ transform: 'translate(-50%, -50%)' }}
        >
          {/* Central Bright Point */}
          <div className="w-2 h-2 bg-white rounded-full shadow-[0_0_10px_#00f0ff]" />
        </div>
      </motion.div>

      {/* Layer 2: Glowing Cyan Wave Orb (Exact visual match to WAVES demo video) */}
      <motion.div
        className="fixed top-0 left-0 pointer-events-none z-[99998]"
        style={{
          x: smoothX,
          y: smoothY,
          opacity: isVisible ? 1 : 0,
        }}
      >
        <div
          className={`relative flex items-center justify-center transition-all duration-300 ${
            isPointer ? 'scale-150' : isMouseDown ? 'scale-90' : 'scale-100'
          }`}
          style={{ transform: 'translate(-50%, -50%)' }}
        >
          {/* Main Glowing Turquoise/Cyan Orb */}
          <div className="w-6 h-6 rounded-full bg-[#00f0ff] opacity-80 shadow-[0_0_24px_#00f0ff,0_0_40px_rgba(0,240,255,0.6)] mix-blend-screen" />

          {/* Concentric Ambient Aura Ring */}
          <div
            className={`absolute rounded-full border border-cyan-300/60 transition-all duration-300 ${
              isPointer
                ? 'w-12 h-12 opacity-100 border-cyan-200 shadow-[0_0_20px_rgba(0,240,255,0.8)]'
                : 'w-9 h-9 opacity-40'
            }`}
          />

          {/* Pulse Ripple Wave on Hover */}
          {isPointer && (
            <motion.div
              animate={{ scale: [1, 1.4, 1], opacity: [0.6, 0.1, 0.6] }}
              transition={{ repeat: Infinity, duration: 1.5, ease: 'easeInOut' }}
              className="absolute w-12 h-12 rounded-full border border-cyan-400/80"
            />
          )}
        </div>
      </motion.div>
    </>
  );
};
