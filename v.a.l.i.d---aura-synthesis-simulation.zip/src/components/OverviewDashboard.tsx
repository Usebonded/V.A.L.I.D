/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Zap,
  Radio,
  Lock,
  ArrowRight,
  Play,
  Upload,
  Activity,
  Layers,
  FileCode2,
  Cpu,
  BarChart3,
  CheckCircle2,
  AlertTriangle,
  FileAudio,
  RadioTower,
  Sliders,
  Terminal
, FileSearch} from 'lucide-react';
import { motion } from 'motion/react';
import { AcousticTelemetry } from '../types';
import { SCENARIOS } from '../data/scenarios';

interface OverviewDashboardProps {
  telemetry: AcousticTelemetry;
  onNavigate: (tab: string) => void;
  onOpenVerdictModal: () => void;
  isLiveMicActive: boolean;
  onToggleMic: () => void;
}

export const OverviewDashboard: React.FC<OverviewDashboardProps> = ({
  telemetry,
  onNavigate,
  onOpenVerdictModal,
  isLiveMicActive,
  onToggleMic,
}) => {
  const isThreat = telemetry.syntheticProbability > 65;

  const modules = [
    {
      id: 'sentinel',
      title: 'Live Interceptor',
      badge: 'Core Engine',
      badgeColor: 'emerald',
      desc: 'Real-time SIP stream interception with sub-200ms neural inference and automatic killswitches.',
      icon: Play,
      actionText: 'Launch Interceptor',
      metric: `${telemetry.syntheticProbability.toFixed(1)}% Synthetic`,
      metricLabel: 'Current Probability',
    },
    {
      id: 'audio_upload',
      title: 'Audio File Ingestion & DSP',
      badge: 'Web Audio DSP',
      badgeColor: 'blue',
      desc: 'Drag & drop custom voice audio (.wav, .mp3, .flac) or test benchmark presets for vocoder cliff analysis.',
      icon: Upload,
      actionText: 'Upload & Inspect',
      metric: '2048-bin FFT',
      metricLabel: 'Spectrum Resolution',
    },
        {
      id: 'forensic_report',
      title: 'Forensic Report History',
      badge: 'Analysis Log',
      badgeColor: 'purple',
      desc: 'Detailed breakdown of audio artifacts, acoustic anomalies, and behavioral psychology flags from uploaded or live audio.',
      icon: FileSearch,
      actionText: 'View History',
      metric: '0',
      metricLabel: 'Reports Logged',
    },
    {
      id: 'procedural_guard',
      title: 'Procedural Safeguards & MFA',
      badge: 'Defensive Protocol',
      badgeColor: 'zinc',
      desc: 'Autonomous interactive challenge prompts and zero-trust verification rules for voice operators.',
      icon: ShieldCheck,
      actionText: 'View Protocols',
      metric: 'Active',
      metricLabel: 'Policy Status',
    },
  ];

  return (
    <div id="overview-dashboard-page" className="flex flex-col gap-10 font-sans">
      {/* ----------------------------------------------------------------------------------------- */}
      {/* Top Hero Section */}
      {/* ----------------------------------------------------------------------------------------- */}
      <section className="border border-white/10 bg-neutral-950 rounded-2xl overflow-hidden shadow-2xl">
        <div className="flex flex-col lg:flex-row">
          {/* Left Hero Content (60%) */}
          <div className="w-full lg:w-[60%] p-8 sm:p-12 lg:p-14 flex flex-col justify-center lg:border-r border-white/10">
            <h1 className="text-[40px] sm:text-[56px] lg:text-[68px] leading-[0.95] font-medium tracking-tighter mb-6 text-[#FFFFFF]">
              V.A.L.I.D
            </h1>

            <p className="text-[#A1A1AA] text-[15px] sm:text-[17px] max-w-[560px] leading-relaxed mb-8 font-sans">
              Voice authentication and liveness identification detector
            </p>

            {/* Quick Action Bar */}
            <div className="flex flex-wrap items-center gap-3">
              <button
                id="overview-launch-interceptor-btn"
                onClick={() => onNavigate('sentinel')}
                className="bg-[#FFFFFF] text-[#000000] px-7 py-3.5 rounded-2xl font-bold text-[12px] uppercase tracking-widest hover:bg-[#E4E4E7] transition-all shadow-sm flex items-center gap-2"
              >
                <Play className="w-4 h-4 fill-current text-black" />
                <span>Initialize Live Scan</span>
              </button>

              <button
                id="overview-upload-audio-btn"
                onClick={() => onNavigate('audio_upload')}
                className="bg-white/5 border border-white/10 text-white hover:border-cyan-400 hover:text-cyan-400 px-6 py-3.5 rounded-2xl font-bold text-[12px] uppercase tracking-widest transition-all flex items-center gap-2"
              >
                <Upload className="w-4 h-4 text-cyan-400" />
                <span>Upload Audio File</span>
              </button>

              <button
                id="overview-rl-defense-btn"
                onClick={() => onNavigate('forensic_report')}
                className="bg-white/5 border border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black px-6 py-3.5 rounded-2xl font-bold text-[12px] uppercase tracking-widest transition-all flex items-center gap-2"
              >
                <Zap className="w-4 h-4 fill-current" />
                <span>RL Defense</span>
              </button>

              <button
                id="overview-open-verdict-btn"
                onClick={onOpenVerdictModal}
                className="bg-white/5 border border-white/10 hover:border-white text-white px-5 py-3.5 rounded-2xl font-bold text-[12px] uppercase tracking-widest transition-all flex items-center gap-2"
                title="Open Voice Authentication Verdict (Authentic vs. Fake)"
              >
                <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                <span>Voice Verdict</span>
              </button>
            </div>
          </div>

          {/* Right Hero Telemetry & Status (40%) */}
          <div className="w-full lg:w-[40%] bg-neutral-900/60 backdrop-blur-xl flex flex-col justify-between p-8 sm:p-10">
            <div>
              <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-6">
                <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  Real-Time Posture Telemetry
                </span>
                <span className="text-[10px] font-mono text-cyan-400 bg-emerald-950 px-2 py-0.5 rounded-xl border border-emerald-800 uppercase">
                  ONLINE
                </span>
              </div>

              {/* Status Metric Grid */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
                  <span className="text-[10px] font-mono text-[#A1A1AA] uppercase block mb-1">
                    Synthetic Risk Score
                  </span>
                  <div
                    className={`text-3xl font-bold font-mono ${
                      isThreat ? 'text-red-400 animate-pulse' : 'text-cyan-400'
                    }`}
                  >
                    {telemetry.syntheticProbability.toFixed(1)}%
                  </div>
                  <span className="text-[10px] font-mono text-[#71717A] mt-1 block">
                    {isThreat ? 'HIGH RISK DETECTED' : 'ORGANIC SPEECH NOMINAL'}
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
                  <span className="text-[10px] font-mono text-[#A1A1AA] uppercase block mb-1">
                    Vocoder Roll-Off
                  </span>
                  <div className="text-3xl font-bold font-mono text-white">
                    {(telemetry.spectralRollOffHz / 1000).toFixed(1)}k
                    <span className="text-sm font-normal text-[#A1A1AA] ml-1">Hz</span>
                  </div>
                  <span className="text-[10px] font-mono text-[#71717A] mt-1 block">
                    16kHz Cliff Inspection
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
                  <span className="text-[10px] font-mono text-[#A1A1AA] uppercase block mb-1">
                    Micro-Pause Variance
                  </span>
                  <div className="text-2xl font-bold font-mono text-white">
                    {telemetry.microPauseVariance}
                    <span className="text-xs font-normal text-[#A1A1AA] ml-1">ms</span>
                  </div>
                  <span className="text-[10px] font-mono text-[#71717A] mt-1 block">
                    Biological Respiration
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
                  <span className="text-[10px] font-mono text-[#A1A1AA] uppercase block mb-1">
                    Phase Continuity
                  </span>
                  <div className="text-2xl font-bold font-mono text-white">
                    {telemetry.phaseContinuityScore}
                    <span className="text-xs font-normal text-[#A1A1AA] ml-1">/100</span>
                  </div>
                  <span className="text-[10px] font-mono text-[#71717A] mt-1 block">
                    Bispectrum Phase Shift
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Live Mic Button */}
            <div className="p-4 rounded-2xl bg-black border border-white/10 flex items-center justify-between">
              <div>
                <span className="text-xs font-mono text-white font-bold block">Live Audio Ingress</span>
                <span className="text-[11px] text-[#A1A1AA]">
                  {isLiveMicActive ? 'Capturing live microphone stream' : 'Web Audio context standby'}
                </span>
              </div>
              <button
                onClick={onToggleMic}
                className={`px-4 py-2 rounded-2xl text-xs font-mono uppercase tracking-wider font-bold transition-all border ${
                  isLiveMicActive
                    ? 'bg-red-600 hover:bg-red-500 text-white border-red-400 animate-pulse'
                    : 'bg-white/5 hover:bg-[#27272A] text-[#A1A1AA] hover:text-white border-white/10'
                }`}
              >
                {isLiveMicActive ? 'Stop Mic' : 'Enable Mic'}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ----------------------------------------------------------------------------------------- */}
      {/* Multipage Navigation Command Bento Grid */}
      {/* ----------------------------------------------------------------------------------------- */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
              <Layers className="w-5 h-5 text-cyan-400" />
              Multi-Module Defense Station
            </h2>
            <p className="text-xs text-[#A1A1AA] mt-0.5">
              Select any specialized defense module below to navigate directly to its dedicated full-screen workstation.
            </p>
          </div>

          <span className="text-[11px] font-mono text-[#71717A] uppercase hidden sm:inline">
            8 Independent Modules Available
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {modules.map((mod) => {
            const Icon = mod.icon;
            return (
              <div
                key={mod.id}
                id={`module-card-${mod.id}`}
                onClick={() => onNavigate(mod.id)}
                className="p-5 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 hover:border-zinc-500 hover:bg-[#121214] transition-all cursor-pointer flex flex-col justify-between gap-4 group shadow-md"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="p-2 rounded-2xl bg-white/5 border border-white/10 text-white group-hover:text-cyan-400 group-hover:border-cyan-400/40 transition-colors">
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="text-[9px] font-mono uppercase px-2 py-0.5 rounded-xl bg-white/5 text-zinc-300 border border-white/10">
                      {mod.badge}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-white font-mono mb-1.5 group-hover:text-cyan-400 transition-colors">
                    {mod.title}
                  </h3>
                  <p className="text-xs text-[#A1A1AA] line-clamp-2 leading-relaxed">
                    {mod.desc}
                  </p>
                </div>

                <div className="border-t border-white/10 pt-3 flex items-center justify-between">
                  <div>
                    <span className="text-[9px] font-mono text-[#71717A] uppercase block">
                      {mod.metricLabel}
                    </span>
                    <span className="text-xs font-mono font-bold text-zinc-200">
                      {mod.metric}
                    </span>
                  </div>

                  <div className="flex items-center gap-1 text-[11px] font-mono uppercase text-white group-hover:text-cyan-400 font-bold transition-colors">
                    <span>Open</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ----------------------------------------------------------------------------------------- */}
      {/* Live Attack Scenario Quick-Launch Station */}
      {/* ----------------------------------------------------------------------------------------- */}
      <div className="p-6 bg-neutral-900/60 backdrop-blur-xl border border-white/10 rounded-2xl flex flex-col gap-4">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div>
            <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              Pre-Configured Vishing Threat Scenarios
            </span>
            <p className="text-xs text-[#A1A1AA] mt-0.5">
              Launch enterprise deepfake attack vectors into the real-time interceptor with 1 click.
            </p>
          </div>

          <button
            onClick={() => onNavigate('attack_vectors')}
            className="text-xs font-mono text-white hover:text-cyan-400 uppercase flex items-center gap-1.5 transition-colors"
          >
            <span>View All Vectors</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {SCENARIOS.map((scen) => (
            <div
              key={scen.id}
              onClick={() => onNavigate('sentinel')}
              className="p-3.5 rounded-2xl bg-white/5 hover:bg-[#27272A] border border-white/10 hover:border-zinc-500 transition-all cursor-pointer flex flex-col justify-between gap-3 group"
            >
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] font-mono font-bold text-red-400 uppercase">
                    {scen.threatLevel} RISK
                  </span>
                  <span className="text-[9px] font-mono text-[#A1A1AA] bg-black px-1.5 py-0.5 rounded-xl border border-white/10">
                    {scen.callerRole}
                  </span>
                </div>
                <h4 className="text-xs font-mono font-bold text-white group-hover:text-white leading-snug">
                  {scen.name}
                </h4>
                <p className="text-[11px] text-[#A1A1AA] mt-1 line-clamp-2">
                  {scen.scenarioDescription}
                </p>
              </div>

              <div className="flex items-center justify-between text-[10px] font-mono text-[#71717A] pt-2 border-t border-white/10/80">
                <span>Model: {scen.cloneEngine || scen.callerName}</span>
                <span className="text-white group-hover:text-cyan-400 font-bold flex items-center gap-1">
                  Test Call <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
