import React, { useEffect, useRef } from 'react';
import { ShieldCheck, Zap, Radio, Lock, ArrowRight, Play, Mic , FileSearch} from 'lucide-react';
import { motion } from 'motion/react';

const GlowingWaveVisualizer: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let time = 0;

    const resize = () => {
      canvas.width = canvas.parentElement?.clientWidth || window.innerWidth;
      canvas.height = canvas.parentElement?.clientHeight || window.innerHeight;
    };
    
    window.addEventListener('resize', resize);
    resize();

    const drawWave = (
      amplitude: number,
      frequency: number,
      phase: number,
      color: string,
      glowColor: string,
      lineWidth: number
    ) => {
      ctx.beginPath();
      ctx.moveTo(0, canvas.height / 2);
      
      for (let x = 0; x < canvas.width; x++) {
        // Taper the ends to 0 amplitude to make it a flat line at edges
        const edgeTaper = Math.pow(Math.sin((x / canvas.width) * Math.PI), 2.5);
        const y = Math.sin(x * frequency + phase) * amplitude * edgeTaper;
        ctx.lineTo(x, canvas.height / 2 + y);
      }
      
      ctx.lineWidth = lineWidth;
      ctx.strokeStyle = color;
      ctx.shadowBlur = 15;
      ctx.shadowColor = glowColor;
      ctx.stroke();
      ctx.shadowBlur = 0; // reset
    };

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Global composition for blending glowing waves
      ctx.globalCompositeOperation = 'screen';

      const w = canvas.width;
      // Responsive amplitude based on canvas width
      const baseAmp = Math.min(60, canvas.height / 3);

      // Deep Blue/Purple wave
      drawWave(baseAmp * 0.9, 0.006, time * 2.2, 'rgba(100, 50, 255, 0.8)', 'rgba(100, 50, 255, 0.6)', 3);
      // Cyan wave
      drawWave(baseAmp, 0.008, time * -3 + Math.PI, 'rgba(0, 240, 255, 0.9)', 'rgba(0, 240, 255, 0.6)', 2);
      // Magenta/Pink wave
      drawWave(baseAmp * 0.7, 0.007, time * 2.5 + Math.PI / 2, 'rgba(255, 0, 127, 0.9)', 'rgba(255, 0, 127, 0.6)', 2);
      // Bright inner core wave (White-ish blue)
      drawWave(baseAmp * 0.4, 0.009, time * -4, 'rgba(200, 255, 255, 0.9)', 'rgba(0, 255, 255, 0.8)', 1.5);
      // Flat center reference line (very subtle)
      drawWave(1, 0, 0, 'rgba(255, 255, 255, 0.3)', 'rgba(255, 255, 255, 0.1)', 1);

      time += 0.015;
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className="absolute inset-0 w-full h-full flex items-center justify-center bg-black overflow-hidden rounded-t-2xl lg:rounded-tr-2xl lg:rounded-tl-none">
      <canvas 
        ref={canvasRef} 
        className="w-full h-full"
      />
    </div>
  );
};

interface HeroSectionProps {
  onStartSimulation: () => void;
  onOpenTelemetry: () => void;
  onOpenProcedural: () => void;
  onOpenAudioUpload?: () => void;
  onOpenForensic?: () => void;
  onOpenMultiFeature?: () => void;
  
  onOpenBiometricsAuth?: () => void;
  onOpenMonitoring?: () => void;
  onOpenVerdictModal?: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onStartSimulation,
  onOpenTelemetry,
  onOpenProcedural,
  onOpenAudioUpload,
  onOpenForensic,
  onOpenMultiFeature,
  
  onOpenBiometricsAuth,
  onOpenMonitoring,
  onOpenVerdictModal,
}) => {
  return (
    <section className="relative z-10 border-b border-white/10 bg-black overflow-hidden min-h-[70vh] flex items-center">
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row relative z-10 w-full">
        {/* Left Side: 60% Width Geometric Hero */}
        <div className="w-full lg:w-[60%] p-8 sm:p-12 lg:p-16 flex flex-col justify-center lg:border-r border-white/10">
          <h1 className="text-[52px] sm:text-[68px] lg:text-[84px] leading-[0.9] font-medium tracking-tighter mb-8 text-[#FFFFFF]">
            V.A.L.I.D
          </h1>

          <p className="text-[#A1A1AA] text-[16px] sm:text-[18px] max-w-[520px] leading-relaxed mb-10 font-sans">
            Real-time defense against synthetic vishing. Autonomous reinforcement learning agents and multi-feature DSP detecting zero-day AI voice clones in sub-200ms windows.
          </p>

          <div className="flex flex-wrap gap-4">
            <button
              id="hero-start-sim-btn"
              onClick={onStartSimulation}
              className="bg-[#FFFFFF] text-[#000000] px-8 py-4 rounded-2xl font-bold text-[13px] uppercase tracking-widest hover:bg-[#E4E4E7] transition-all shadow-sm flex items-center gap-2.5"
            >
              <Play className="w-4 h-4 fill-current text-black" />
              <span>Initialize Scan</span>
            </button>

            {onOpenAudioUpload && (
              <button
                id="hero-open-audio-upload-btn"
                onClick={onOpenAudioUpload}
                className="bg-white/5 border border-white/10 text-white hover:border-cyan-400 hover:text-cyan-400 px-8 py-4 rounded-2xl font-bold text-[13px] uppercase tracking-widest transition-all flex items-center gap-2 shadow-sm"
              >
                <Radio className="w-4 h-4 text-cyan-400" />
                <span>Upload Audio File</span>
              </button>
            )}

            {onOpenForensic && (
              <button
                id="hero-open-forensic-btn"
                onClick={onOpenForensic}
                className="bg-white/5 border border-purple-500 text-purple-400 hover:bg-purple-500 hover:text-white px-8 py-4 rounded-2xl font-bold text-[13px] uppercase tracking-widest transition-all flex items-center gap-2 shadow-sm"
              >
                <FileSearch className="w-4 h-4" />
                <span>Forensic History</span>
              </button>
            )}

            {onOpenMonitoring && null}

            {onOpenBiometricsAuth && null}

            

            {onOpenMultiFeature && (
              <button
                id="hero-open-feature-matrix-btn"
                onClick={onOpenMultiFeature}
                className="bg-white/5 border border-white text-white px-8 py-4 rounded-2xl font-bold text-[13px] uppercase tracking-widest hover:bg-white hover:text-black transition-all flex items-center gap-2"
              >
                <Radio className="w-4 h-4 text-cyan-400" />
                <span>Feature Matrix</span>
              </button>
            )}

            <button
              id="hero-open-telemetry-btn"
              onClick={onOpenTelemetry}
              className="border border-white/10 text-[#FFFFFF] px-8 py-4 rounded-2xl font-bold text-[13px] uppercase tracking-widest hover:bg-white/5 transition-all"
            >
              DSP Protocols
            </button>

            {onOpenVerdictModal && (
              <button
                id="hero-voice-verdict-btn"
                onClick={onOpenVerdictModal}
                className="bg-white/5 border border-white/10 hover:border-white text-white px-6 py-4 rounded-2xl font-bold text-[13px] uppercase tracking-widest transition-all flex items-center gap-2"
                title="Open Voice Authentication Verdict (Authentic vs. Fake)"
              >
                <ShieldCheck className="w-4 h-4 text-cyan-400" />
                <span>Voice Verdict</span>
              </button>
            )}
          </div>
        </div>

        {/* Right Side: 40% Width Geometric Telemetry & Spectrogram */}
        <div className="w-full lg:w-[40%] bg-black flex flex-col border-t lg:border-t-0 border-white/10">
          {/* Top Visualizer */}
          <div className="flex-1 relative flex items-center justify-center border-b border-white/10 min-h-[300px] overflow-hidden">
            <GlowingWaveVisualizer />
            <div className="absolute bottom-4 left-6 z-10 font-mono text-[10px] text-white/50 uppercase tracking-wider mix-blend-difference">
              SPECTROGRAM_FEED_LIVE
            </div>
          </div>

          {/* Bottom Telemetry Cards */}
          <div className="p-6 sm:p-8 flex flex-col gap-4 bg-neutral-900/60 backdrop-blur-xl">
            <div className="grid grid-cols-2 gap-4">
              <div className="border border-white/10 p-4 bg-white/5 rounded-2xl">
                <div className="font-mono text-[10px] text-[#A1A1AA] uppercase mb-1">Organic Match</div>
                <div className="text-2xl font-medium tracking-tighter text-white">12.4%</div>
              </div>
              <div className="border border-white/10 p-4 bg-white/5 rounded-2xl">
                <div className="font-mono text-[10px] text-[#A1A1AA] uppercase mb-1">Latency Offset</div>
                <div className="text-2xl font-medium tracking-tighter text-white">0.02ms</div>
              </div>
            </div>

            <div className="border border-white/10 p-4 bg-white/5 rounded-2xl">
              <div className="font-mono text-[10px] text-[#A1A1AA] uppercase mb-3 flex justify-between">
                <span>Digital Artifact Density</span>
                <span className="text-red-500 font-bold">CRITICAL</span>
              </div>
              <div className="h-2 bg-[#27272A] w-full rounded-full overflow-hidden">
                <div className="h-full bg-red-500 w-[92%]"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
