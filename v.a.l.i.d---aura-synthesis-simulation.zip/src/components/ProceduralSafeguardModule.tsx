import React, { useState, useEffect } from 'react';
import { KeyRound, Shield, Clock, CheckCircle2, XCircle, RefreshCw, Zap, Mic, Volume2, AlertTriangle, Lock } from 'lucide-react';
import { ProceduralPassphrase } from '../types';

export const ProceduralSafeguardModule: React.FC = () => {
  const [passphrase, setPassphrase] = useState<ProceduralPassphrase | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [countdown, setCountdown] = useState<number>(45);
  const [testResult, setTestResult] = useState<{
    callerType: 'human' | 'synthetic_clone';
    latencyMs: number;
    phoneticScore: number;
    passed: boolean;
    reason: string;
  } | null>(null);
  const [isTesting, setIsTesting] = useState<boolean>(false);

  const fetchNewPassphrase = async () => {
    setIsLoading(true);
    setTestResult(null);
    try {
      const res = await fetch('/api/generate-passphrase', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setPassphrase({
          id: data.id,
          token: data.token,
          phoneticPhrase: data.phoneticPhrase,
          generatedAt: data.generatedAt,
          expiresInSec: data.expiresInSec,
          challengeStatus: 'issued',
          expectedLatencyWindowMs: data.expectedLatencyWindowMs,
        });
        setCountdown(data.expiresInSec);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchNewPassphrase();
  }, []);

  // Countdown timer
  useEffect(() => {
    if (countdown <= 0) return;
    const interval = setInterval(() => {
      setCountdown((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => clearInterval(interval);
  }, [countdown]);

  const simulateChallengeResponse = (type: 'human' | 'synthetic_clone') => {
    setIsTesting(true);
    setTestResult(null);

    const latency = type === 'human' 
      ? Math.floor(420 + Math.random() * 260) 
      : Math.floor(1380 + Math.random() * 450);

    setTimeout(() => {
      setIsTesting(false);
      if (type === 'human') {
        setTestResult({
          callerType: 'human',
          latencyMs: latency,
          phoneticScore: 97,
          passed: true,
          reason: `Response received in ${latency}ms (within human cognitive window <800ms). Natural plosive /p/ and /k/ phonetic transient attack observed.`,
        });
      } else {
        setTestResult({
          callerType: 'synthetic_clone',
          latencyMs: latency,
          phoneticScore: 41,
          passed: false,
          reason: `CRITICAL LATENCY BREACH (${latency}ms). Cloned generative pipeline incurred STT->LLM->TTS roundtrip delay. Sibilant /s/ smear detected.`,
        });
      }
    }, Math.min(1800, latency));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <KeyRound className="w-4 h-4 text-white" />
              <span className="text-xs font-mono text-[#A1A1AA] uppercase tracking-widest">
                Procedural Security & Zero-Knowledge Protocol
              </span>
            </div>
            <h2 className="text-2xl font-sans font-medium text-white tracking-tight">
              Dynamic Verbal Verification Passphrases
            </h2>
            <p className="text-xs text-[#A1A1AA] max-w-2xl mt-1 font-sans">
              Technical acoustic filters paired with ephemeral challenge tokens force attackers into fatal inference latency traps.
            </p>
          </div>

          <button
            id="refresh-passphrase-btn"
            disabled={isLoading}
            onClick={fetchNewPassphrase}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white/5 hover:bg-[#27272A] border border-white/10 text-white font-mono text-xs uppercase tracking-wider transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Generate Ephemeral Token</span>
          </button>
        </div>
      </div>

      {/* Ephemeral Passphrase Active Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Active Token Display */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="text-xs font-mono text-white uppercase tracking-wider flex items-center gap-2">
                <Shield className="w-4 h-4 text-cyan-400" />
                Live Ephemeral Zero-Knowledge Token
              </span>
              <div className="flex items-center gap-2 text-xs font-mono">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span className={countdown <= 10 ? 'text-red-400 animate-pulse font-bold' : 'text-[#A1A1AA]'}>
                  Expires in {countdown}s
                </span>
              </div>
            </div>

            {/* Big Phonetic Display */}
            <div className="p-6 rounded-2xl bg-black border border-white/10 text-center space-y-2">
              <span className="text-[11px] font-mono text-[#A1A1AA] uppercase tracking-widest block">
                Required Verbal Challenge Phrase
              </span>
              <div className="text-2xl sm:text-4xl font-mono font-bold tracking-widest text-white py-2">
                {passphrase ? passphrase.phoneticPhrase : 'GENERATING...'}
              </div>
              <span className="text-xs font-mono text-[#A1A1AA] block uppercase">
                Token ID: {passphrase?.token || 'TK-INIT'}
              </span>
            </div>

            {/* Cognitive Latency Explanation */}
            <div className="grid grid-cols-2 gap-4 font-mono text-xs">
              <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
                <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">Human Latency Window:</span>
                <span className="text-cyan-400 text-lg font-bold">350ms – 750ms</span>
              </div>
              <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
                <span className="text-[10px] text-[#A1A1AA] uppercase block mb-1">AI Clone Latency Trap:</span>
                <span className="text-red-500 text-lg font-bold">&gt; 1,200ms</span>
              </div>
            </div>

            {/* Simulation Triggers */}
            <div className="space-y-2 pt-2 border-t border-white/10">
              <span className="text-[11px] font-mono text-[#A1A1AA] uppercase tracking-wider block">
                Test Challenge Response Simulation:
              </span>
              <div className="flex flex-wrap gap-3">
                <button
                  id="test-human-response-btn"
                  disabled={isTesting || countdown === 0}
                  onClick={() => simulateChallengeResponse('human')}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white/5 hover:bg-[#27272A] border border-white/10 text-emerald-400 font-mono text-xs uppercase tracking-wider transition-all"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Simulate Authentic Human (480ms)</span>
                </button>

                <button
                  id="test-clone-response-btn"
                  disabled={isTesting || countdown === 0}
                  onClick={() => simulateChallengeResponse('synthetic_clone')}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white/5 hover:bg-[#27272A] border border-red-800 text-red-300 font-mono text-xs uppercase tracking-wider transition-all"
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                  <span>Simulate AI Voice Clone (1,420ms Latency Trap)</span>
                </button>
              </div>
            </div>

            {/* Test Result Feedback */}
            {isTesting && (
              <div className="p-4 rounded-2xl bg-black border border-white/10 flex items-center justify-center gap-3 text-xs font-mono text-white">
                <RefreshCw className="w-4 h-4 animate-spin text-white" />
                <span>Measuring acoustic response latency & phoneme integrity...</span>
              </div>
            )}

            {testResult && (
              <div className={`p-4 rounded-2xl border text-xs font-mono space-y-2 ${
                testResult.passed
                  ? 'bg-white/5 border-emerald-800 text-emerald-300'
                  : 'bg-white/5 border-red-800 text-red-300'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="font-bold tracking-wider uppercase flex items-center gap-1.5">
                    {testResult.passed ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <XCircle className="w-4 h-4 text-red-400" />}
                    {testResult.passed ? 'AUTHENTIC HUMAN VERIFIED' : 'DEEPFAKE INFERENCE LATENCY DETECTED'}
                  </span>
                  <span>Latency: {testResult.latencyMs}ms</span>
                </div>
                <p className="text-[#A1A1AA] font-sans">{testResult.reason}</p>
              </div>
            )}

          </div>
        </div>

        {/* Right: Multi-Layered Defense Architecture */}
        <div className="lg:col-span-5 space-y-3">
          <div className="p-6 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-white/10 space-y-4">
            <span className="text-xs font-mono font-semibold text-white uppercase tracking-wider block pb-2 border-b border-white/10">
              4-Tier Multi-Layered Defense Blueprint
            </span>

            <div className="space-y-3 text-xs">
              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                <div className="flex items-center justify-between font-mono">
                  <span className="font-semibold text-white">Layer 1: Acoustic Signal Processing</span>
                  <span className="text-[10px] text-[#A1A1AA]">0.0s – 3.0s</span>
                </div>
                <p className="text-[#A1A1AA] text-[11px] font-sans">
                  Passive monitoring of micro-pause variance (&lt;15ms anomaly), vocoder high-frequency rolloff (16kHz), and glottal jitter.
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                <div className="flex items-center justify-between font-mono">
                  <span className="font-semibold text-white">Layer 2: Zero-Knowledge Passphrase</span>
                  <span className="text-[10px] text-cyan-400 font-bold uppercase">Active Trap</span>
                </div>
                <p className="text-[#A1A1AA] text-[11px] font-sans">
                  Dynamic phonetic challenge sentences force real-time generative voice clones to reveal STT/TTS latency bottlenecks (&gt;1,200ms).
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                <div className="flex items-center justify-between font-mono">
                  <span className="font-semibold text-white">Layer 3: Out-of-Band Hardware MFA</span>
                  <span className="text-[10px] text-[#A1A1AA] uppercase">Dual Control</span>
                </div>
                <p className="text-[#A1A1AA] text-[11px] font-sans">
                  FIDO2 / YubiKey push notifications to registered executive hardware, isolating the spoofed telephony channel.
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                <div className="flex items-center justify-between font-mono">
                  <span className="font-semibold text-white">Layer 4: Ingress Scrambler & Forensics</span>
                  <span className="text-[10px] text-red-500 font-bold uppercase">Killswitch</span>
                </div>
                <p className="text-[#A1A1AA] text-[11px] font-sans">
                  Automatic line quarantine, operator whisper alerts, and full spectral evidentiary packaging for incident response.
                </p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
