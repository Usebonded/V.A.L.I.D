/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { MicOff, ShieldAlert, Sparkles, Upload, Play, RefreshCw, X, HelpCircle, Radio, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface MicrophonePermissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onActivateSimulation: () => void;
  onNavigateToAudioLab: () => void;
  onRetry: () => void;
  errorMessage?: string | null;
}

export const MicrophonePermissionModal: React.FC<MicrophonePermissionModalProps> = ({
  isOpen,
  onClose,
  onActivateSimulation,
  onNavigateToAudioLab,
  onRetry,
  errorMessage,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="mic-permission-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 10 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="w-full max-w-lg bg-neutral-900/60 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl p-6 sm:p-8 flex flex-col gap-6 relative"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-[#71717A] hover:text-white rounded-2xl hover:bg-white/5 transition-colors"
          title="Close dialog"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-start gap-4">
          <div className="p-3 bg-red-950/60 border border-red-800 text-red-400 rounded-2xl shrink-0">
            <MicOff className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-mono text-red-400 font-bold uppercase tracking-wider">
                AUDIO INGRESS // PERMISSION ERROR
              </span>
            </div>
            <h3 className="text-lg font-bold text-white font-mono leading-snug">
              Microphone Access Denied
            </h3>
            <p className="text-xs text-[#A1A1AA] mt-1 leading-relaxed">
              The browser or iframe blocked microphone access. You can still test all sub-200ms neural DSP models using our built-in live voice simulation or audio file inspector.
            </p>
          </div>
        </div>

        {/* Technical Error Notice */}
        {errorMessage && (
          <div className="p-3 bg-white/5 border border-white/10 rounded-2xl text-[11px] font-mono text-zinc-300">
            <span className="text-[#71717A] block mb-0.5">SYSTEM DIAGNOSTIC:</span>
            <span className="text-red-300">{errorMessage}</span>
          </div>
        )}

        {/* Fallback Action Options */}
        <div className="flex flex-col gap-3">
          <button
            id="modal-activate-sim-btn"
            onClick={() => {
              onActivateSimulation();
              onClose();
            }}
            className="w-full p-3.5 bg-[#FFFFFF] text-[#000000] hover:bg-[#E4E4E7] transition-all rounded-2xl font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-between group shadow-sm"
          >
            <div className="flex items-center gap-2.5">
              <Radio className="w-4 h-4 text-black" />
              <span>Enable Live Speech Simulation</span>
            </div>
            <span className="text-[10px] text-zinc-600 font-normal">Recommended</span>
          </button>

          <button
            id="modal-navigate-audio-lab-btn"
            onClick={() => {
              onNavigateToAudioLab();
              onClose();
            }}
            className="w-full p-3.5 bg-white/5 hover:bg-[#27272A] border border-white/10 hover:border-zinc-500 text-white transition-all rounded-2xl font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-between"
          >
            <div className="flex items-center gap-2.5">
              <Upload className="w-4 h-4 text-cyan-400" />
              <span>Upload Voice Audio / Presets</span>
            </div>
            <span className="text-[10px] text-[#A1A1AA] font-normal">.wav, .mp3</span>
          </button>

          <button
            id="modal-retry-mic-btn"
            onClick={onRetry}
            className="w-full p-2.5 bg-transparent hover:bg-white/5 border border-white/10 text-[#A1A1AA] hover:text-white transition-all rounded-2xl font-mono text-xs uppercase tracking-wider flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Retry Microphone Permission</span>
          </button>
        </div>

        {/* How to enable instructions */}
        <div className="p-3.5 bg-neutral-950 border border-white/10 rounded-2xl text-[11px] text-[#71717A] flex flex-col gap-1.5 font-sans">
          <div className="flex items-center gap-1.5 text-zinc-300 font-mono text-[10px] uppercase font-bold">
            <HelpCircle className="w-3.5 h-3.5 text-cyan-400" />
            <span>How to Grant Microphone Permission</span>
          </div>
          <p className="leading-normal">
            1. Click the <strong>lock / site settings icon</strong> on the left side of your browser URL bar.
          </p>
          <p className="leading-normal">
            2. Toggle <strong>Microphone</strong> to <strong>Allow</strong>.
          </p>
          <p className="leading-normal">
            3. If previewing in an iframe, open the app in a <strong>new tab</strong> to bypass container sandbox restrictions.
          </p>
        </div>
      </motion.div>
    </div>
  );
};
