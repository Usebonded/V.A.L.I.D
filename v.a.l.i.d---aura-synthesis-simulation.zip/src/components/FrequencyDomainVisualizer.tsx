import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Activity,
  Mic,
  MicOff,
  Radio,
  Sliders,
  Maximize2,
  Minimize2,
  Layers,
  BarChart2,
  Waves,
  Zap,
  ShieldAlert,
  ShieldCheck,
  Pause,
  Play,
  RotateCcw
} from 'lucide-react';
import { AcousticTelemetry } from '../types';

export type VisualizerDisplayMode = 'spectrum' | 'waveform' | 'spectrogram' | 'split';
export type FrequencyScale = 'log' | 'linear';

interface FrequencyDomainVisualizerProps {
  telemetry: AcousticTelemetry;
  frequencyData?: Uint8Array | null;
  timeDomainData?: Uint8Array | null;
  isThreat?: boolean;
  isLiveMicActive?: boolean;
  onToggleLiveMic?: () => void;
  isSimulatingCall?: boolean;
  audioSourceLabel?: string;
}

export const FrequencyDomainVisualizer: React.FC<FrequencyDomainVisualizerProps> = ({
  telemetry,
  frequencyData,
  timeDomainData,
  isThreat = false,
  isLiveMicActive = false,
  onToggleLiveMic,
  isSimulatingCall = false,
  audioSourceLabel = 'Telephony Ingress Stream',
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // User Interactive Settings
  const [displayMode, setDisplayMode] = useState<VisualizerDisplayMode>('split');
  const [frequencyScale, setFrequencyScale] = useState<FrequencyScale>('log');
  const [gainBoost, setGainBoost] = useState<number>(1.2);
  const [showPeakHold, setShowPeakHold] = useState<boolean>(true);
  const [showFormantMarkers, setShowFormantMarkers] = useState<boolean>(true);
  const [isFrozen, setIsFrozen] = useState<boolean>(false);

  // Peak hold array & spectrogram buffer
  const peakHoldRef = useRef<number[]>([]);
  const spectrogramHistoryRef = useRef<ImageData | null>(null);
  const spectrogramCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Local fallback buffers if raw buffers aren't piped directly every frame
  const internalFreqBufferRef = useRef<Uint8Array>(new Uint8Array(512));
  const internalTimeBufferRef = useRef<Uint8Array>(new Uint8Array(512));

  // Sync internal buffers with props or generate subtle baseline
  useEffect(() => {
    if (frequencyData && frequencyData.length > 0) {
      internalFreqBufferRef.current = frequencyData;
    }
    if (timeDomainData && timeDomainData.length > 0) {
      internalTimeBufferRef.current = timeDomainData;
    }
  }, [frequencyData, timeDomainData]);

  // Main Canvas Rendering Loop
  const renderCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !containerRef.current) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high-DPI crisp rendering
    const dpr = window.devicePixelRatio || 1;
    const rect = containerRef.current.getBoundingClientRect();
    const width = Math.max(300, Math.floor(rect.width));
    const height = Math.max(160, Math.floor(rect.height || 220));

    if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
      canvas.width = width * dpr;
      canvas.height = height * dpr;
    }

    ctx.save();
    ctx.scale(dpr, dpr);

    // If frozen, keep last frame
    if (isFrozen) {
      ctx.restore();
      return;
    }

    const freqData = internalFreqBufferRef.current;
    const timeData = internalTimeBufferRef.current;
    const binCount = freqData.length || 512;

    // Initialize or resize peak hold buffer
    if (peakHoldRef.current.length !== binCount) {
      peakHoldRef.current = new Array(binCount).fill(0);
    }

    // Clear background
    ctx.fillStyle = '#050505';
    ctx.fillRect(0, 0, width, height);

    // Draw Subtle Grid & Coordinates
    ctx.strokeStyle = '#18181B';
    ctx.lineWidth = 1;
    for (let x = 40; x < width; x += 60) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 30; y < height; y += 35) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Mode-specific renderers
    if (displayMode === 'spectrum') {
      renderSpectrumView(ctx, width, height, freqData, isThreat, frequencyScale, gainBoost, showPeakHold, showFormantMarkers, telemetry);
    } else if (displayMode === 'waveform') {
      renderWaveformView(ctx, width, height, timeData, isThreat, gainBoost, telemetry);
    } else if (displayMode === 'spectrogram') {
      renderSpectrogramWaterfall(ctx, width, height, freqData, isThreat);
    } else if (displayMode === 'split') {
      // Top Half: Frequency Spectrum (60% height)
      const topHeight = Math.floor(height * 0.62);
      ctx.save();
      renderSpectrumView(ctx, width, topHeight, freqData, isThreat, frequencyScale, gainBoost, showPeakHold, showFormantMarkers, telemetry);
      ctx.restore();

      // Divider line
      ctx.strokeStyle = '#27272A';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(0, topHeight);
      ctx.lineTo(width, topHeight);
      ctx.stroke();

      // Bottom Half: Oscilloscope Time Waveform (38% height)
      const bottomHeight = height - topHeight;
      ctx.save();
      ctx.translate(0, topHeight);
      renderWaveformView(ctx, width, bottomHeight, timeData, isThreat, gainBoost, telemetry, true);
      ctx.restore();
    }

    ctx.restore();
  }, [displayMode, frequencyScale, gainBoost, showPeakHold, showFormantMarkers, isThreat, isFrozen, telemetry]);

  // Animation frame loop
  useEffect(() => {
    let active = true;
    const loop = () => {
      if (!active) return;
      renderCanvas();
      animationFrameRef.current = requestAnimationFrame(loop);
    };
    animationFrameRef.current = requestAnimationFrame(loop);

    return () => {
      active = false;
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [renderCanvas]);

  // Responsive resize observer
  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver(() => {
      renderCanvas();
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, [renderCanvas]);

  return (
    <div 
      id="frequency-domain-visualizer-card"
      className="rounded-2xl border border-white/10 bg-neutral-900/60 backdrop-blur-xl overflow-hidden flex flex-col transition-all duration-300"
    >
      {/* Visualizer Header Toolbar */}
      <div className="p-3.5 bg-[#0D0D0E] border-b border-white/10 flex flex-wrap items-center justify-between gap-3">
        {/* Left: Title & Live Signal Feed Badge */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Activity className={`w-4 h-4 ${isThreat ? 'text-red-500 animate-pulse' : 'text-cyan-400'}`} />
            <span className="text-xs font-mono font-bold uppercase tracking-widest text-white">
              Real-Time Frequency-Domain Spectrum
            </span>
          </div>

          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-2xl bg-black border border-white/10 text-[10px] font-mono text-[#A1A1AA]">
            <span className={`w-1.5 h-1.5 rounded-full ${
              isLiveMicActive 
                ? 'bg-cyan-400 animate-ping' 
                : isSimulatingCall 
                ? 'bg-amber-400 animate-ping' 
                : 'bg-zinc-600'
            }`} />
            <span className="text-white font-medium">
              {isLiveMicActive ? 'MIC INGRESS' : isSimulatingCall ? 'CALL SIMULATION' : 'STANDBY'}
            </span>
            <span className="text-[#71717A]">•</span>
            <span>2048 FFT</span>
          </div>
        </div>

        {/* Right Controls: Mode, Scale, Mic Toggle */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Display Mode Switcher */}
          <div className="flex items-center bg-black border border-white/10 rounded-2xl p-0.5 text-[10px] font-mono">
            <button
              id="viz-mode-split"
              onClick={() => setDisplayMode('split')}
              className={`px-2 py-1 rounded-xl uppercase tracking-wider transition-colors ${
                displayMode === 'split' ? 'bg-white text-black font-bold' : 'text-[#A1A1AA] hover:text-white'
              }`}
              title="Dual Split View (Frequency Spectrum + Waveform)"
            >
              Dual
            </button>
            <button
              id="viz-mode-spectrum"
              onClick={() => setDisplayMode('spectrum')}
              className={`px-2 py-1 rounded-xl uppercase tracking-wider transition-colors ${
                displayMode === 'spectrum' ? 'bg-white text-black font-bold' : 'text-[#A1A1AA] hover:text-white'
              }`}
              title="Full Frequency Spectrum"
            >
              Spectrum
            </button>
            <button
              id="viz-mode-waveform"
              onClick={() => setDisplayMode('waveform')}
              className={`px-2 py-1 rounded-xl uppercase tracking-wider transition-colors ${
                displayMode === 'waveform' ? 'bg-white text-black font-bold' : 'text-[#A1A1AA] hover:text-white'
              }`}
              title="Time-Domain Oscilloscope"
            >
              Waveform
            </button>
            <button
              id="viz-mode-spectrogram"
              onClick={() => setDisplayMode('spectrogram')}
              className={`px-2 py-1 rounded-xl uppercase tracking-wider transition-colors ${
                displayMode === 'spectrogram' ? 'bg-white text-black font-bold' : 'text-[#A1A1AA] hover:text-white'
              }`}
              title="Waterfall Spectrogram"
            >
              Waterfall
            </button>
          </div>

          {/* Log / Lin Scale Switcher */}
          <button
            id="viz-toggle-scale"
            onClick={() => setFrequencyScale((s) => (s === 'log' ? 'linear' : 'log'))}
            className="px-2.5 py-1 rounded-2xl bg-white/5 border border-white/10 text-[10px] font-mono text-[#A1A1AA] hover:text-white uppercase transition-colors"
            title="Toggle Logarithmic / Linear Frequency Axis Scale"
          >
            {frequencyScale.toUpperCase()}
          </button>

          {/* Formants Toggle */}
          <button
            id="viz-toggle-formants"
            onClick={() => setShowFormantMarkers(!showFormantMarkers)}
            className={`px-2 py-1 rounded-2xl border text-[10px] font-mono uppercase transition-colors ${
              showFormantMarkers
                ? 'bg-white/5 text-cyan-400 border-cyan-400/40 font-bold'
                : 'bg-black text-[#71717A] border-white/10'
            }`}
            title="Toggle Formant Peak Overlays (F1, F2, F3)"
          >
            F1-F3
          </button>

          {/* Freeze / Snapshot */}
          <button
            id="viz-toggle-freeze"
            onClick={() => setIsFrozen(!isFrozen)}
            className={`p-1.5 rounded-2xl border text-[10px] font-mono uppercase transition-colors ${
              isFrozen ? 'bg-amber-950 text-amber-300 border-amber-600' : 'bg-black text-[#A1A1AA] hover:text-white border-white/10'
            }`}
            title={isFrozen ? 'Resume live spectrum' : 'Freeze / inspect current acoustic frame'}
          >
            {isFrozen ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
          </button>

          {/* Active Live Microphone Toggle Button */}
          {onToggleLiveMic && (
            <button
              id="viz-toggle-live-mic-btn"
              onClick={onToggleLiveMic}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-2xl text-xs font-mono font-bold uppercase tracking-wider transition-all border ${
                isLiveMicActive
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-400 shadow-md shadow-emerald-950/40 animate-pulse'
                  : 'bg-white/5 hover:bg-[#27272A] text-[#A1A1AA] hover:text-white border-white/10'
              }`}
              title={isLiveMicActive ? 'Stop Active Microphone Analysis' : 'Activate Live Microphone Input for Real-Time Analysis'}
            >
              {isLiveMicActive ? <Mic className="w-3.5 h-3.5 text-white" /> : <MicOff className="w-3.5 h-3.5" />}
              <span>{isLiveMicActive ? 'Mic Active' : 'Live Mic'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Interactive Canvas Surface */}
      <div 
        ref={containerRef} 
        className="relative w-full h-[220px] sm:h-[240px] bg-[#050505] overflow-hidden select-none cursor-crosshair"
      >
        <canvas ref={canvasRef} className="w-full h-full block" />

        {/* Dynamic Threat Annotation Banner in Canvas Corner */}
        {isThreat && (
          <div className="absolute top-2.5 right-3 z-10 pointer-events-none flex items-center gap-2 bg-red-950/90 border border-red-800 text-red-300 font-mono text-[10px] px-2.5 py-1 rounded-2xl shadow-lg animate-pulse font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
            <span>&gt;16kHz Vocoder Artifact / Phase Discontinuity Detected</span>
          </div>
        )}

        {/* Live Mic Waveform Live Readout Banner */}
        {isLiveMicActive && (
          <div className="absolute bottom-2.5 left-3 z-10 pointer-events-none flex items-center gap-2 bg-black/85 border border-emerald-800/80 text-emerald-400 font-mono text-[10px] px-2.5 py-1 rounded-2xl backdrop-blur-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
            <span>Live Mic Stream: {(telemetry.pitchHz || 0).toFixed(0)} Hz • RMS: {(telemetry.rms * 100).toFixed(1)}% • F1: {telemetry.formants?.f1 || 480}Hz</span>
          </div>
        )}
      </div>

      {/* Acoustic HUD Telemetry Footer Status */}
      <div className="p-2.5 bg-[#09090B] border-t border-white/10 flex flex-wrap items-center justify-between text-[11px] font-mono text-[#A1A1AA] gap-2">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="text-[#71717A] uppercase">Spectral Roll-Off:</span>
            <span className={`font-bold ${isThreat ? 'text-red-400' : 'text-white'}`}>
              {telemetry.spectralRollOffHz ? `${(telemetry.spectralRollOffHz / 1000).toFixed(1)} kHz` : '21.8 kHz'}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[#71717A] uppercase">Vocoder Cliff:</span>
            <span className={`font-bold ${telemetry.vocoderArtifactScore > 50 ? 'text-red-400' : 'text-cyan-400'}`}>
              {telemetry.vocoderArtifactScore || 8}%
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[#71717A] uppercase">Pitch Jitter:</span>
            <span className="text-white font-bold">
              {telemetry.pitchJitterPercent ? `${telemetry.pitchJitterPercent.toFixed(2)}%` : '0.72%'}
            </span>
          </div>

          <div className="hidden sm:flex items-center gap-1.5">
            <span className="text-[#71717A] uppercase">Formants:</span>
            <span className="text-zinc-300">
              F1:{telemetry.formants?.f1 || 480} F2:{telemetry.formants?.f2 || 1720} F3:{telemetry.formants?.f3 || 2840}
            </span>
          </div>
        </div>

        {/* Live Input VU Meter Bar */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-[#71717A] uppercase">Level:</span>
          <div className="w-24 h-2 bg-black rounded-xl border border-white/10 overflow-hidden flex">
            <div
              className={`h-full transition-all duration-75 ${
                telemetry.rms > 0.75
                  ? 'bg-red-500'
                  : telemetry.rms > 0.4
                  ? 'bg-amber-400'
                  : 'bg-cyan-400'
              }`}
              style={{ width: `${Math.min(100, Math.max(4, telemetry.rms * 100))}%` }}
            />
          </div>
          <span className="text-[10px] text-white font-mono min-w-[32px] text-right">
            {telemetry.peakDb ? `${telemetry.peakDb}dB` : '-24dB'}
          </span>
        </div>
      </div>
    </div>
  );
};

// -------------------------------------------------------------------------------------------------
// Sub-Renderers: Frequency Spectrum, Waveform Oscilloscope, Spectrogram Waterfall
// -------------------------------------------------------------------------------------------------

function renderSpectrumView(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  freqData: Uint8Array,
  isThreat: boolean,
  scale: FrequencyScale,
  gainBoost: number,
  showPeakHold: boolean,
  showFormants: boolean,
  telemetry: AcousticTelemetry
) {
  const binCount = freqData.length || 512;
  const barCount = Math.min(binCount, Math.floor(width / 3.5));
  const barWidth = width / barCount;
  const sampleRate = 44100;
  const nyquist = sampleRate / 2;

  // 16 kHz Vocoder Artifact Anomaly Marker Line
  const cutoffFreq = 16000;
  let cutoffX: number;
  if (scale === 'log') {
    const minF = 20;
    const maxF = nyquist;
    cutoffX = (Math.log10(cutoffFreq / minF) / Math.log10(maxF / minF)) * width;
  } else {
    cutoffX = (cutoffFreq / nyquist) * width;
  }

  // Draw 16kHz Cutoff Danger Zone Shading
  if (isThreat) {
    ctx.fillStyle = 'rgba(239, 68, 68, 0.08)';
    ctx.fillRect(cutoffX, 0, width - cutoffX, height);
  }

  // Draw 16 kHz Guideline
  ctx.strokeStyle = isThreat ? 'rgba(239, 68, 68, 0.7)' : 'rgba(161, 161, 170, 0.35)';
  ctx.setLineDash([4, 4]);
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(cutoffX, 0);
  ctx.lineTo(cutoffX, height);
  ctx.stroke();
  ctx.setLineDash([]);

  // Draw 16 kHz Label
  ctx.fillStyle = isThreat ? '#F87171' : '#71717A';
  ctx.font = '9px monospace';
  ctx.fillText('16 kHz (Vocoder Cutoff)', Math.max(10, cutoffX - 110), 14);

  // Frequency Bins / Bars
  for (let i = 0; i < barCount; i++) {
    // Map visual index to frequency bin (log vs linear)
    let binIdx: number;
    let freqAtBar: number;

    if (scale === 'log') {
      const minF = 20;
      const maxF = nyquist;
      const norm = i / barCount;
      freqAtBar = minF * Math.pow(maxF / minF, norm);
      binIdx = Math.floor((freqAtBar / nyquist) * (binCount - 1));
    } else {
      freqAtBar = (i / barCount) * nyquist;
      binIdx = Math.floor((i / barCount) * (binCount - 1));
    }

    binIdx = Math.max(0, Math.min(binCount - 1, binIdx));
    const rawVal = (freqData[binIdx] || 0) / 255;
    const boostedVal = Math.min(1, rawVal * gainBoost);
    const barHeight = Math.max(2, boostedVal * (height - 24));
    const x = i * barWidth;
    const y = height - barHeight;

    // Color gradient calculation
    const isAboveCutoff = freqAtBar > cutoffFreq;
    if (isThreat) {
      if (isAboveCutoff) {
        // High frequency dropoff anomaly
        ctx.fillStyle = 'rgba(239, 68, 68, 0.85)';
      } else {
        // Threat harmonic body
        const grad = ctx.createLinearGradient(0, height, 0, y);
        grad.addColorStop(0, '#7F1D1D');
        grad.addColorStop(0.6, '#DC2626');
        grad.addColorStop(1, '#F87171');
        ctx.fillStyle = grad;
      }
    } else {
      // Clean organic human spectrum (crisp emerald to pure white gradient)
      const grad = ctx.createLinearGradient(0, height, 0, y);
      grad.addColorStop(0, '#064E3B');
      grad.addColorStop(0.6, '#00FF41');
      grad.addColorStop(1, '#FFFFFF');
      ctx.fillStyle = grad;
    }

    ctx.fillRect(x, y, Math.max(1, barWidth - 1), barHeight);
  }

  // Formant Markers (F1, F2, F3)
  if (showFormants && telemetry.formants) {
    const { f1, f2, f3 } = telemetry.formants;
    const formants = [
      { label: 'F1', freq: f1, color: '#38BDF8' },
      { label: 'F2', freq: f2, color: '#A78BFA' },
      { label: 'F3', freq: f3, color: '#F472B6' },
    ];

    formants.forEach(({ label, freq, color }) => {
      let fx: number;
      if (scale === 'log') {
        const minF = 20;
        const maxF = nyquist;
        fx = (Math.log10(freq / minF) / Math.log10(maxF / minF)) * width;
      } else {
        fx = (freq / nyquist) * width;
      }

      if (fx > 0 && fx < width) {
        ctx.strokeStyle = color;
        ctx.lineWidth = 1;
        ctx.setLineDash([2, 2]);
        ctx.beginPath();
        ctx.moveTo(fx, 18);
        ctx.lineTo(fx, height);
        ctx.stroke();
        ctx.setLineDash([]);

        // Badge
        ctx.fillStyle = color;
        ctx.font = 'bold 8px monospace';
        ctx.fillText(`${label}:${freq}Hz`, fx + 2, 26);
      }
    });
  }

  // dB Axis Reference labels along right/left edge
  ctx.fillStyle = '#52525B';
  ctx.font = '8px monospace';
  ctx.fillText('0 dB', 4, 12);
  ctx.fillText('-18 dB', 4, height * 0.35);
  ctx.fillText('-36 dB', 4, height * 0.7);

  // Frequency Axis Labels along bottom
  const freqLabels = [
    { freq: 100, label: '100Hz' },
    { freq: 500, label: '500Hz' },
    { freq: 1000, label: '1kHz' },
    { freq: 4000, label: '4kHz' },
    { freq: 10000, label: '10kHz' },
    { freq: 20000, label: '20kHz' },
  ];

  ctx.fillStyle = '#71717A';
  ctx.font = '8px monospace';
  freqLabels.forEach(({ freq, label }) => {
    let lx: number;
    if (scale === 'log') {
      const minF = 20;
      const maxF = nyquist;
      lx = (Math.log10(freq / minF) / Math.log10(maxF / minF)) * width;
    } else {
      lx = (freq / nyquist) * width;
    }

    if (lx > 20 && lx < width - 35) {
      ctx.fillText(label, lx - 10, height - 4);
    }
  });
}

function renderWaveformView(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  timeData: Uint8Array,
  isThreat: boolean,
  gainBoost: number,
  telemetry: AcousticTelemetry,
  isSubPane: boolean = false
) {
  const bufferLength = timeData.length || 512;
  const centerY = height / 2;

  // Center baseline zero-line
  ctx.strokeStyle = '#27272A';
  ctx.lineWidth = 1;
  ctx.setLineDash([2, 2]);
  ctx.beginPath();
  ctx.moveTo(0, centerY);
  ctx.lineTo(width, centerY);
  ctx.stroke();
  ctx.setLineDash([]);

  // Find zero-crossing for oscilloscope trigger stabilization
  let triggerIndex = 0;
  for (let i = 0; i < bufferLength - 1; i++) {
    if (timeData[i] < 128 && timeData[i + 1] >= 128) {
      triggerIndex = i;
      break;
    }
  }

  // Draw PCM Waveform Path
  ctx.strokeStyle = isThreat ? '#EF4444' : '#00FF41';
  ctx.lineWidth = isSubPane ? 1.5 : 2;
  ctx.shadowColor = isThreat ? 'rgba(239, 68, 68, 0.4)' : 'rgba(0, 255, 65, 0.3)';
  ctx.shadowBlur = 4;

  ctx.beginPath();
  const sliceWidth = width / (bufferLength - triggerIndex);
  let x = 0;

  for (let i = triggerIndex; i < bufferLength; i++) {
    const rawVal = (timeData[i] - 128) / 128.0;
    const amplified = rawVal * gainBoost;
    const y = centerY + amplified * (centerY * 0.88);

    if (i === triggerIndex) {
      ctx.moveTo(x, y);
    } else {
      ctx.lineTo(x, y);
    }
    x += sliceWidth;
  }

  ctx.stroke();
  ctx.shadowBlur = 0;

  // Monospace oscilloscope label
  ctx.fillStyle = '#71717A';
  ctx.font = '8px monospace';
  ctx.fillText(
    isSubPane ? 'TIME-DOMAIN PCM (OSCILLOSCOPE)' : 'TIME-DOMAIN PCM WAVEFORM • ZERO-CROSSING STABILIZED',
    6,
    isSubPane ? 12 : 14
  );
}

function renderSpectrogramWaterfall(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  freqData: Uint8Array,
  isThreat: boolean
) {
  const binCount = Math.min(freqData.length, 256);
  const barHeight = height / binCount;

  // Draw vertical waterfall strip
  for (let i = 0; i < binCount; i++) {
    const val = (freqData[i] || 0) / 255;
    const y = height - (i * barHeight);

    if (isThreat) {
      const r = Math.floor(val * 255);
      const g = Math.floor(val * 40);
      const b = Math.floor(val * 40);
      ctx.fillStyle = `rgb(${r},${g},${b})`;
    } else {
      const r = Math.floor(val * 20);
      const g = Math.floor(val * 255);
      const b = Math.floor(val * 65);
      ctx.fillStyle = `rgb(${r},${g},${b})`;
    }

    ctx.fillRect(0, y, width, barHeight);
  }

  ctx.fillStyle = '#FFFFFF';
  ctx.font = '9px monospace';
  ctx.fillText('WATERFALL SPECTROGRAM (SCROLLING TIME-FREQUENCY)', 10, 16);
}
