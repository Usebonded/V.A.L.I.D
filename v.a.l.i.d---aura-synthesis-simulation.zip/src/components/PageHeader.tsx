/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowLeft, Home, Mic, MicOff, Play, ShieldAlert, Sparkles, Activity } from 'lucide-react';
import { AcousticTelemetry } from '../types';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  category: string;
  onNavigateHome: () => void;
  isLiveMicActive?: boolean;
  onToggleMic?: () => void;
  telemetry?: AcousticTelemetry;
  extraActions?: React.ReactNode;
}

export const PageHeader: React.FC<PageHeaderProps> = ({
  title,
  subtitle,
  category,
  onNavigateHome,
  isLiveMicActive,
  onToggleMic,
  telemetry,
  extraActions,
}) => {
  const isThreat = telemetry ? telemetry.syntheticProbability > 65 : false;

  return (
    <div className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 bg-neutral-950 border border-white/10 rounded-2xl">
      {/* Breadcrumb & Title */}
      <div className="flex items-center gap-4">
        <button
          onClick={onNavigateHome}
          className="p-2.5 rounded-2xl bg-white/5 hover:bg-[#27272A] text-zinc-400 hover:text-white border border-white/10 transition-colors"
          title="Back to Mission Overview"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        <div>
          <div className="flex items-center gap-2 mb-0.5">
            <span className="text-[10px] font-mono text-[#A1A1AA] uppercase tracking-wider">
              COMMAND CENTER / {category}
            </span>
            <span className="w-1 h-1 rounded-full bg-zinc-600" />
            <span
              className={`text-[9px] font-mono font-bold uppercase px-1.5 py-0.2 rounded-xl border ${
                isThreat
                  ? 'bg-red-950 text-red-300 border-red-800'
                  : 'bg-emerald-950 text-emerald-300 border-emerald-800'
              }`}
            >
              {isThreat ? 'ANOMALY DETECTED' : 'SYSTEM NOMINAL'}
            </span>
          </div>

          <h1 className="text-xl font-bold text-white font-mono tracking-tight flex items-center gap-2">
            {title}
          </h1>

          {subtitle && (
            <p className="text-xs text-[#A1A1AA] font-sans mt-0.5 max-w-2xl">
              {subtitle}
            </p>
          )}
        </div>
      </div>

      {/* Right Actions & Status */}
      <div className="flex items-center gap-3 flex-wrap">
        {telemetry && (
          <div className="hidden sm:flex items-center gap-3 px-3 py-1.5 bg-white/5 border border-white/10 rounded-2xl text-xs font-mono">
            <span className="text-[#71717A]">Synthetic:</span>
            <span
              className={`font-bold ${
                isThreat ? 'text-red-400' : 'text-cyan-400'
              }`}
            >
              {telemetry.syntheticProbability.toFixed(1)}%
            </span>
          </div>
        )}

        {onToggleMic && (
          <button
            onClick={onToggleMic}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-2xl font-mono text-xs uppercase tracking-wider transition-all border ${
              isLiveMicActive
                ? 'bg-red-600 hover:bg-red-500 text-white font-bold border-red-400 animate-pulse'
                : 'bg-white/5 hover:bg-[#27272A] text-[#A1A1AA] hover:text-white border-white/10'
            }`}
          >
            {isLiveMicActive ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5 text-zinc-400" />}
            <span>{isLiveMicActive ? 'Mic Active' : 'Live Mic'}</span>
          </button>
        )}

        {extraActions}
      </div>
    </div>
  );
};
