import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

# Find the start of the rl_defense block
start_idx = code.find("{/* PAGE 4: REINFORCEMENT LEARNING DEFENSE AGENT */}")
# Find the end of the biomarkers block
end_idx = code.find("              )}", code.find("{biomarkerSubTab === 'waterfall' && (")) + 16

forensic_block = """              {/* PAGE 4: FORENSIC REPORT */}
              {activeTab === 'forensic_report' && (
                <div>
                  <PageHeader
                    title="Forensic Analysis Report"
                    subtitle="Detailed log of deep reasoning, acoustic anomalies, and behavioral psychology flags intercepted."
                    category="FORENSIC LOGS"
                    onNavigateHome={() => setActiveTab('overview')}
                    isLiveMicActive={isLiveMicActive}
                    onToggleMic={handleToggleMic}
                    telemetry={telemetry}
                  />
                  <div className="p-6 sm:p-10 max-w-7xl mx-auto">
                    <ForensicReportView
                      reportsHistory={reportsHistory}
                      onNavigateToTab={setActiveTab}
                    />
                  </div>
                </div>
              )}"""

if start_idx != -1 and end_idx != -1:
    new_code = code[:start_idx] + forensic_block + code[end_idx:]
    with open('src/App.tsx', 'w') as f:
        f.write(new_code)
else:
    print("Could not find blocks")
