import re

with open('src/App.tsx', 'r') as f:
    code = f.read()

# Update LiveCallInterceptor props
code = re.sub(
    r"<LiveCallInterceptor\n\s*currentTelemetry=\{telemetry\}\n\s*onTelemetryUpdate=\{setTelemetry\}\n\s*onOpenProcedural=\{\(\) => setActiveTab\('procedural_guard'\)\}\n\s*onOpenAudioUpload=\{\(\) => setActiveTab\('audio_upload'\)\}\n\s*/>",
    """<LiveCallInterceptor
                    currentTelemetry={telemetry}
                    onTelemetryUpdate={setTelemetry}
                    onOpenProcedural={() => setActiveTab('procedural_guard')}
                    onOpenAudioUpload={() => setActiveTab('audio_upload')}
                    onReportGenerated={(report) => setReportsHistory(prev => [report, ...prev])}
                  />""",
    code
)

# Update AudioUploaderTester props
code = re.sub(
    r"<AudioUploaderTester\n\s*onTelemetryUpdate=\{setTelemetry\}\n\s*isLiveMicActive=\{isLiveMicActive\}\n\s*onToggleMic=\{handleToggleMic\}\n\s*onNavigateToTab=\{setActiveTab\}\n\s*/>",
    """<AudioUploaderTester
                    onTelemetryUpdate={setTelemetry}
                    isLiveMicActive={isLiveMicActive}
                    onToggleMic={handleToggleMic}
                    onNavigateToTab={setActiveTab}
                    onReportGenerated={(report) => setReportsHistory(prev => [report, ...prev])}
                  />""",
    code
)

with open('src/App.tsx', 'w') as f:
    f.write(code)
