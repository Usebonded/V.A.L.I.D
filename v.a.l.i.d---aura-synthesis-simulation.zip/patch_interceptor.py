import re

with open('src/components/LiveCallInterceptor.tsx', 'r') as f:
    code = f.read()

# Add import
code = re.sub(
    r"import \{ AcousticTelemetry, CallAnalysisResult, ProceduralPassphrase, VishingScenario \} from '\.\./types';",
    "import { AcousticTelemetry, CallAnalysisResult, ProceduralPassphrase, VishingScenario, ForensicReportEntry } from '../types';",
    code
)

# Add prop to interface
code = re.sub(
    r"isLiveMicActive\?: boolean;\n  onToggleMic\?: \(\) => void;",
    "isLiveMicActive?: boolean;\n  onToggleMic?: () => void;\n  onReportGenerated?: (report: ForensicReportEntry) => void;",
    code
)

# Add prop to component
code = re.sub(
    r"isLiveMicActive: externalMicActive,\n  onToggleMic: externalToggleMic,",
    "isLiveMicActive: externalMicActive,\n  onToggleMic: externalToggleMic,\n  onReportGenerated,",
    code
)

# Update triggerAIAnalysis
analysis_code = """      const data = await res.json();
      if (data.success && data.report) {
        setAnalysisReport(data.report);
        if (onReportGenerated) {
          onReportGenerated({
            id: 'FR-' + Math.random().toString(36).substring(2, 9).toUpperCase(),
            timestamp: Date.now(),
            source: 'Live Call',
            telemetrySnapshot: currentTelemetry,
            analysis: data.report
          });
        }
      }"""

code = re.sub(
    r"const data = await res\.json\(\);\n\s*if \(data\.success && data\.report\) \{\n\s*setAnalysisReport\(data\.report\);\n\s*\}",
    analysis_code,
    code
)

with open('src/components/LiveCallInterceptor.tsx', 'w') as f:
    f.write(code)
