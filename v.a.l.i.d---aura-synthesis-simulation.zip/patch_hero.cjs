const fs = require('fs');
let code = fs.readFileSync('src/components/HeroSection.tsx', 'utf8');

code = code.replace(/import {([^}]*)} from 'lucide-react';/, "import {$1, FileSearch} from 'lucide-react';");

code = code.replace(/onOpenRLDefense\?: \(\) => void;/g, 'onOpenForensic?: () => void;');
code = code.replace(/onOpenRLDefense,/g, 'onOpenForensic,');

const oldRLButton = `{onOpenRLDefense && (
              <button
                id="hero-open-rl-defense-btn"
                onClick={onOpenRLDefense}
                className="bg-white/5 border border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black px-8 py-4 rounded-2xl font-bold text-[13px] uppercase tracking-widest transition-all flex items-center gap-2 shadow-sm"
              >
                <Zap className="w-4 h-4 fill-current" />
                <span>RL Defense & Alerts</span>
              </button>
            )}`;

const newForensicButton = `{onOpenForensic && (
              <button
                id="hero-open-forensic-btn"
                onClick={onOpenForensic}
                className="bg-white/5 border border-purple-500 text-purple-400 hover:bg-purple-500 hover:text-white px-8 py-4 rounded-2xl font-bold text-[13px] uppercase tracking-widest transition-all flex items-center gap-2 shadow-sm"
              >
                <FileSearch className="w-4 h-4" />
                <span>Forensic History</span>
              </button>
            )}`;

code = code.replace(oldRLButton, newForensicButton);

// Remove biomarkers button
const oldBiomarkersButton = `{onOpenBiomarkers && (
              <button
                id="hero-open-biomarkers-btn"
                onClick={onOpenBiomarkers}
                className="bg-white/5 border border-white/10 text-[#FFFFFF] px-8 py-4 rounded-2xl font-bold text-[13px] uppercase tracking-widest hover:border-white hover:text-white transition-all flex items-center gap-2"
              >
                <Zap className="w-4 h-4 text-white" />
                <span>Neural Biomarkers</span>
              </button>
            )}`;
code = code.replace(oldBiomarkersButton, '');

// Also remove from props
code = code.replace(/onOpenBiomarkers\?: \(\) => void;/g, '');
code = code.replace(/onOpenBiomarkers,/g, '');

fs.writeFileSync('src/components/HeroSection.tsx', code);
