sed -i "/{ id: 'forensic_report', label: 'Defense'/c\    { id: 'forensic_report', label: 'Forensic', icon: FileSearch }," src/components/Navbar.tsx
sed -i "/{ id: 'forensic_report', label: 'Biomarkers'/d" src/components/Navbar.tsx
