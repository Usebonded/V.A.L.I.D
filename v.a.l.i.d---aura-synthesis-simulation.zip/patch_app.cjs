const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// Replace imports
code = code.replace(/import \{ NeuralBiomarkerTrackingView \} from '\.\/components\/NeuralBiomarkerTrackingView';\n/, "import { ForensicReportView } from './components/ForensicReportView';\n");
code = code.replace(/import \{ ReinforcementLearningDefenseView \} from '\.\/components\/ReinforcementLearningDefenseView';\n/, "");
code = code.replace(/import \{ MultiFeatureDetectionView \} from '\.\/components\/MultiFeatureDetectionView';\n/, "");
code = code.replace(/import \{ AcousticTelemetryView \} from '\.\/components\/AcousticTelemetryView';\n/, "");

// Add state for reports history and ForensicReportEntry type
code = code.replace(/import \{ AcousticTelemetry, VishingScenario \} from '\.\/types';/, "import { AcousticTelemetry, VishingScenario, ForensicReportEntry } from './types';");
code = code.replace(/const \[activeTab, setActiveTab\] = useState<string>\('overview'\);/, "const [activeTab, setActiveTab] = useState<string>('overview');\n  const [reportsHistory, setReportsHistory] = useState<ForensicReportEntry[]>([]);");

fs.writeFileSync('src/App.tsx', code);
