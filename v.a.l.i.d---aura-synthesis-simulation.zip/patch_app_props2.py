import re
with open('src/App.tsx', 'r') as f:
    code = f.read()

code = code.replace("""<AudioUploaderTester
                    onTelemetryUpdate={setTelemetry}
                    isLiveMicActive={isLiveMicActive}
                    onToggleMic={handleToggleMic}
                    onNavigateToTab={(tab) => setActiveTab(tab)}
                  />""", """<AudioUploaderTester
                    onTelemetryUpdate={setTelemetry}
                    isLiveMicActive={isLiveMicActive}
                    onToggleMic={handleToggleMic}
                    onNavigateToTab={(tab) => setActiveTab(tab)}
                    onReportGenerated={(report) => setReportsHistory(prev => [report, ...prev])}
                  />""")

with open('src/App.tsx', 'w') as f:
    f.write(code)
